# Reproduction source and original evidence

Original capture date: 2026-10-15. Original reviewed commit: 1e3266d79dcef0ce24b0a87fce10189143bc5886. The recorded app/client was run before and after the suggested fix on that revision. Fresh branch-level tests are published separately; these captures were not rerun on the latest upstream revision.

Replace test_REPLACE_WITH_YOUR_PUBLIC_TEST_STORE_KEY in the client configuration with your public RevenueCat Test Store SDK key before running.
