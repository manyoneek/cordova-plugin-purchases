# iOS silently ignores null subscriber-attribute deletions

**Repository:** RevenueCat/cordova-plugin-purchases 8.2.4, commit `1e3266d79dcef0ce24b0a87fce10189143bc5886`.
**Reproduced on:** native Cordova iOS 8.0.1 / iOS 27.1 simulator, PurchasesHybridCommon 19.12.0 and RevenueCat iOS 5.95.0.

`setDisplayName(null)` leaves the previous name stored, despite its documented deletion behavior. A `null` value in the typed `setAttributes()` map rejects the entire map, including valid sibling updates. These void JavaScript methods provide no error callback, so the rejection is silent to the caller.

## Reproduce

1. Launch the included CordovaRepro app with a fresh synthetic Test Store user.
2. Call `setDisplayName("QA original name")` and `setAttributes({qa_null_delete:"original", qa_keep:"control"})`.
3. Call `setDisplayName(null)` and `setAttributes({qa_null_delete:null, qa_keep:"updated"})`.
4. Inspect the SDK's persisted attributes using the included read-only native observer. Repeat deletion with empty strings as a control.

**Expected:** both deleted values become the SDK's empty-string deletion marker; `qa_keep` becomes `"updated"`.
**Actual:** the old name and custom value remain; `qa_keep` stays `"control"`. Empty-string deletion succeeds.

Apps using the advertised null input fail to clear stored values, and mixed attribute batches lose their valid updates too.

## Cause and solution

`PurchasesPlugin+Attribution.swift` accepts only `NSString` in `setSubscriberAttribute` and only `[String: String]` in `setAttributes`. JSON null arrives as `NSNull` and fails these guards. Accept strings and nulls, normalize a scalar null to the supported empty-string deletion marker, and pass the validated `[String: Any]` map to the shared library, which already normalizes null values. The included patch preserves rejection of other input types.

## Evidence

`python3 run-native-regression.py before`: three null-deletion/mixed-update assertions fail; string-set and empty-string-delete controls pass. With the patch, `python3 run-native-regression.py fixed` passes all five attribute assertions. Overall: **4 passed / 5 failed → 9 passed / 0 failed**. Existing `npm test -- --runInBand`: **54 passed** before and with fixes.

See [app source](../app/www/js/repro.js), [read-only observer](../evidence-plugin/QAEvidence.m), [before screenshot](../evidence/before.png), [after screenshot](../evidence/fixed.png), [before video](../evidence/before.mp4), [after video](../evidence/fixed.mp4), [test logs](../native-before.log), [fixed logs](../native-fixed.log), and [solution](../suggested-fixes.patch).

App: **CordovaRepro**, bundle `com.revenuecat.sdkbugreporter.cordova`; RevenueCat **SDK Bug Reporter** (`proj602cc762`), **Test Store** (`app4ca00b430f`). [Dashboard](https://app.revenuecat.com/projects/602cc762/apps/app4ca00b430f).

**Limits:** real native setter execution and persisted SDK values; the observer never changes SDK state. Server-side attribute deletion is not asserted. Only display name and custom attributes were exercised; other setters sharing the helper and Android were not executed.
