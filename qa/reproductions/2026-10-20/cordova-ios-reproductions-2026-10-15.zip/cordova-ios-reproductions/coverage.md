# Review coverage — 2026-10-15

## Inventory and rotation

Refreshed GitHub's public RevenueCat org inventory, including forks and archived repositories. All 77 repositories have valid local git clones under `<local-user>/repos/revenuecat`; no missing clones or failures. Preserved the complete API inventory and clone checks in this run. Fetched default branches into isolated detached worktrees; original clones were not reset or modified.

Primary review: `cordova-plugin-purchases` at `1e3266d79dcef0ce24b0a87fce10189143bc5886`. Inspected public JS inputs/callbacks and native purchasing, users, attributes, cache, error, and virtual currency routes. Compared the exact pinned PurchasesHybridCommon 19.12.0 source (`a3d5cc0cfd80d75f4e2eebb3012deb05c13a77f4`) and RevenueCat iOS 5.95.0 (`95ad250230efa7fc3e811c158ed264832aed2e79`). Android return paths were read as a contract cross-check, not executed.

Unity and CLI default branches were fetched as rotation candidates. Only their repository instructions/test setup were read; no functional coverage is claimed. The CLI baseline command `go test ./...` could not start because `go` is absent from PATH (exit 127). No CLI defect is inferred. Stop after two confirmed Cordova defects; next rotation remains **purchases-unity**.

## Confirmed findings

- RC-CORDOVA-20261015-001: `cordova-ios:virtual-currency-cache:nil-coalesced-empty-dictionary`.
- RC-CORDOVA-20261015-002: `cordova-ios:subscriber-attributes:null-rejected-by-string-only-guards`.

Both are distinct from the four existing RN/Flutter fingerprints. Public issue searches (`null`, `null attributes`, `virtual currencies null`) and the latest 100 PRs found no matching report/fix; this was a bounded check, not an exhaustive history audit. An initial combined-query gh search failed; retried successfully with `--repo`. Prior reports and publication history were left unchanged.

## Tests and native app

- Existing Jest: **54 passed** before fixes; **54 passed** with diagnostic fixes.
- Real iOS app: **4 passed / 5 failed** before; **9 passed / 0 failed** with fixes.
- Test Store synthetic-user initialization and actual empty-currency fetch pass in both versions.
- Empty cache after configure/invalidation is `{}` before and `null` with fix; fetched cache is `{"all":{}}` in both.
- Real SDK storage preserves old display/custom values and drops a valid sibling map update after null input; all three cases pass with the guard/normalization fix.
- String setter and empty-string deletion controls pass before and after.

The app uses the unmodified public JS implementation and compiled native production Swift source; before-source hashes match the pinned review checkout. Cordova runtime and PHC/RevenueCat dependencies are real. The evidence plugin only reads actual persisted attributes and writes result JSON; no callback fixtures, mocked transport, or replacement SDK logic. Normal service calls target only dedicated project `proj602cc762`, Test Store `app4ca00b430f`, with unique `sdk-bug-reporter-cordova-*` users. No purchases were made. Official CLI 0.1.4 verified app type and produced the dashboard URL; no backend configuration change was necessary.

## Evidence, limits, and recovery

App source, focused executable regression runner, screenshots, ~21-second before and ~23-second fixed videos, reports, fix patch, exact versions, test commands/results, and source restoration checks are retained. Video frames were visually inspected. The two reports share one app/video sequence covering both actual flows.

Executed iOS 27.1 simulator only. No physical-device or Android run. Attribute assertions inspect native persisted values/deletion markers; server-side deletion is not asserted. The currency control uses an empty returned collection, not a nonzero balance.

Harness/setup failures are preserved separately and are not findings:

- CocoaPods required UTF-8 locale; rebuilt the disposable app with `LANG`/`LC_ALL` set.
- Xcode 27 rejects an iOS 13 simulator target; used a build-only iOS 15 override without changing SDK support metadata.
- The first read-only observer looked in standard defaults; corrected it to the actual SDK suite `com.revenuecat.user_defaults`, then reran from string-set controls.
- Foldable simulator default capture selected an inactive black display; recaptured both complete flows on active display 1. Black captures remain under `evidence/inactive-display` and are excluded from delivery.
- First nullable-dictionary fix did not compile against Cordova 8's nonnull dictionary API. A multipart-null trial hit Cordova's null-unaware multipart decoder. The final simple `CDVPluginResult(status: .ok)` uses the runtime's verified nil-to-null serialization and passes the full native flow. Failed diagnostic fixes are retained and excluded from delivery.

Temporary production changes were restored in `finally` and checked byte-for-byte. The original clone and review worktree have no tracked modifications. No GitHub writes, support requests, schedule changes, or direct Discord sends.

## Source artifact verification

The delivery source was rebuilt independently in a fresh staging directory with `bash delivery/build-repro.sh` (exit 0). Running its own `run-native-regression.py packaged-source` again produced **4 passed / 5 failed**, confirming the packaged original source reproduces both defects. This extra run is retained separately from the canonical before/after evidence.
