# Cordova iOS null-handling reproductions

Two defects in RevenueCat/cordova-plugin-purchases 8.2.4 at `1e3266d79dcef0ce24b0a87fce10189143bc5886`:

- [Absent virtual currency cache becomes an empty object](reports/01-empty-currency-cache.md).
- [Null attribute deletion is silently rejected](reports/02-null-attribute-deletion.md).

## Run the app

Requires macOS, Xcode with an iOS simulator, Node/npm, Python 3, and CocoaPods on PATH. The archive includes the actual reviewed SDK source and a minimal Cordova app. Native dependencies are pinned in the plugin to PurchasesHybridCommon 19.12.0 / RevenueCat 5.95.0.

```sh
export QA_SIMULATOR='<booted simulator UDID from xcrun simctl list devices>'
export QA_DISPLAY=1
bash build-repro.sh
python3 run-native-regression.py reproduced
```

The runner installs and launches the app, captures its real flow to video and screenshot, prints each assertion, and exits 1 for regression failures or 0 when all pass. On the unmodified source, expect **4 pass / 5 fail**. Check `xcrun simctl io "$QA_SIMULATOR" enumerate` if the simulator uses a different active display. Captures must show the app; a black inactive display is not evidence.

The app also runs automatically on manual launch and provides a Run again button. Each launch creates a new synthetic user prefixed `sdk-bug-reporter-cordova-`. The read-only evidence plugin inspects the SDK's own UserDefaults suite and writes `Documents/results.json`; it does not inject SDK callbacks, replace transport, or implement SDK behavior.

## Validate the suggested fixes

```sh
patch -d worktrees/cordova-plugin-purchases -p1 < suggested-fixes.patch
bash build-repro.sh
python3 run-native-regression.py reproduced-fixed
patch -R -d worktrees/cordova-plugin-purchases -p1 < suggested-fixes.patch
bash build-repro.sh
```

Expected with the fixes: **9 pass / 0 fail**. The source supplied here is restored to the original implementation. `suggested-fixes.patch` contains both small changes. Existing SDK tests are runnable with `cd worktrees/cordova-plugin-purchases && npm test -- --runInBand` (54 passed before/with fixes).

## Test setup and evidence

RevenueCat project **SDK Bug Reporter** (`proj602cc762`), app **Test Store** (`app4ca00b430f`): https://app.revenuecat.com/projects/602cc762/apps/app4ca00b430f

The included configuration contains only that Test Store app's public SDK key. No account credentials are needed. No purchase is made. The app fetches customer information and virtual currencies and changes only synthetic-user attributes.

`evidence/before.mp4` and `evidence/fixed.mp4` are real-time simulator recordings of the same app before and after the diagnostic patch. Screenshots and JSON results sit alongside them. `native-before.log`, `native-fixed.log`, and the two Jest logs contain the final test results. Detailed provenance and source-restoration checks are included.

Tested on iOS 27.1 simulator with Xcode 27.0; the build command's iOS 15 deployment override accommodates this Xcode. No Android or physical-device execution. Attribute checks establish local SDK persistence and deletion markers, not a server-side deletion assertion.
