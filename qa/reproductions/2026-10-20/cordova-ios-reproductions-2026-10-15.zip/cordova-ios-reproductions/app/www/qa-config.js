window.QA_CONFIG = {"apiKey": "test_REPLACE_WITH_YOUR_PUBLIC_TEST_STORE_KEY", "projectId": "proj602cc762"};
