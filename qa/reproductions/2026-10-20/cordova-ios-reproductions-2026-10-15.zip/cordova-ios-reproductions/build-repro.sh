#!/bin/bash
set -euo pipefail
cd "$(dirname "$0")"
export LANG=en_US.UTF-8 LC_ALL=en_US.UTF-8
: "${QA_SIMULATOR:?Set QA_SIMULATOR to a booted iOS simulator UDID}"
command -v pod >/dev/null || { echo 'CocoaPods must be on PATH.' >&2; exit 2; }
(cd worktrees/cordova-plugin-purchases && npm ci --no-audit --no-fund)
npm install --prefix tooling cordova@13.0.0 --no-audit --no-fund
if [ ! -d app/platforms/ios ]; then
  (cd app && ../tooling/node_modules/.bin/cordova platform add ios@8.0.1)
fi
(cd app && ../tooling/node_modules/.bin/cordova prepare ios)
cp worktrees/cordova-plugin-purchases/src/ios/*.swift app/platforms/ios/App/Plugins/cordova-plugin-purchases/
xcodebuild -workspace app/platforms/ios/App.xcworkspace -scheme App -configuration Debug \
  -sdk iphonesimulator -destination "platform=iOS Simulator,id=$QA_SIMULATOR" \
  -derivedDataPath derived IPHONEOS_DEPLOYMENT_TARGET=15.0 CODE_SIGNING_ALLOWED=NO build
