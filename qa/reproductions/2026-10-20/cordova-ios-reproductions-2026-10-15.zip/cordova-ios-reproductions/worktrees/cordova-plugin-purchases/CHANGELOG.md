## 8.2.4
## RevenueCat SDK
### 🐞 Bugfixes
* Fix iOS startup customer info callback registration (#1082) via Antonio Pallares (@ajpallares)
### 📦 Dependency Updates
* [AUTOMATIC BUMP] Updates purchases-hybrid-common to 19.10.0 (#1087) via RevenueCat Git Bot (@RCGitBot)
  * [Android 10.26.0](https://github.com/RevenueCat/purchases-android/releases/tag/10.26.0)
  * [Android 10.25.0](https://github.com/RevenueCat/purchases-android/releases/tag/10.25.0)
  * [Android 10.24.2](https://github.com/RevenueCat/purchases-android/releases/tag/10.24.2)
  * [Android 10.24.1](https://github.com/RevenueCat/purchases-android/releases/tag/10.24.1)
  * [Android 10.24.0](https://github.com/RevenueCat/purchases-android/releases/tag/10.24.0)
  * [Android 10.23.4](https://github.com/RevenueCat/purchases-android/releases/tag/10.23.4)
  * [Android 10.23.3](https://github.com/RevenueCat/purchases-android/releases/tag/10.23.3)
  * [Android 10.23.2](https://github.com/RevenueCat/purchases-android/releases/tag/10.23.2)
  * [Android 10.23.1](https://github.com/RevenueCat/purchases-android/releases/tag/10.23.1)
  * [Android 10.23.0](https://github.com/RevenueCat/purchases-android/releases/tag/10.23.0)
  * [iOS 5.94.0](https://github.com/RevenueCat/purchases-ios/releases/tag/5.94.0)
  * [iOS 5.93.0](https://github.com/RevenueCat/purchases-ios/releases/tag/5.93.0)
  * [iOS 5.92.0](https://github.com/RevenueCat/purchases-ios/releases/tag/5.92.0)
  * [iOS 5.91.0](https://github.com/RevenueCat/purchases-ios/releases/tag/5.91.0)
* [AUTOMATIC BUMP] Updates purchases-hybrid-common to 19.8.0 (#1084) via RevenueCat Git Bot (@RCGitBot)
* [AUTOMATIC BUMP] Updates purchases-hybrid-common to 19.6.0 (#1080) via RevenueCat Git Bot (@RCGitBot)
* [AUTOMATIC BUMP] Updates purchases-hybrid-common to 19.5.0 (#1079) via RevenueCat Git Bot (@RCGitBot)
* [RENOVATE] Update dependency revenuecat to v4.6.2 (#1077) via RevenueCat Git Bot (@RCGitBot)
* [AUTOMATIC BUMP] Updates purchases-hybrid-common to 19.4.1 (#1076) via RevenueCat Git Bot (@RCGitBot)
* [AUTOMATIC BUMP] Updates purchases-hybrid-common to 19.4.0 (#1074) via RevenueCat Git Bot (@RCGitBot)

### 🔄 Other Changes
* Bump CI to Ruby 3.3 (#1085) via Josh Holtz (@joshdholtz)
* Bump fastlane-plugin-revenuecat_internal from `9f7a03e` to `4c49d48` (#1083) via dependabot[bot] (@dependabot[bot])

## 8.2.3
## RevenueCat SDK
### 📦 Dependency Updates
* [AUTOMATIC BUMP] Updates purchases-hybrid-common to 19.3.1 (#1071) via RevenueCat Git Bot (@RCGitBot)
  * [Android 10.22.1](https://github.com/RevenueCat/purchases-android/releases/tag/10.22.1)
  * [Android 10.22.0](https://github.com/RevenueCat/purchases-android/releases/tag/10.22.0)
  * [iOS 5.90.2](https://github.com/RevenueCat/purchases-ios/releases/tag/5.90.2)
  * [iOS 5.90.1](https://github.com/RevenueCat/purchases-ios/releases/tag/5.90.1)
  * [iOS 5.90.0](https://github.com/RevenueCat/purchases-ios/releases/tag/5.90.0)
* [AUTOMATIC BUMP] Updates purchases-hybrid-common to 19.3.0 (#1065) via RevenueCat Git Bot (@RCGitBot)
* [AUTOMATIC BUMP] Updates purchases-hybrid-common to 19.2.0 (#1063) via RevenueCat Git Bot (@RCGitBot)

### 🔄 Other Changes
* Bump fastlane-plugin-revenuecat_internal from `fc64a1a` to `9f7a03e` (#1070) via dependabot[bot] (@dependabot[bot])
* Auto-merge PHC bump PRs (#1069) via Álvaro Brey (@AlvaroBrey)
* Bump fastlane-plugin-revenuecat_internal from `6db1da0` to `fc64a1a` (#1068) via dependabot[bot] (@dependabot[bot])
* Bump fastlane from 2.240.0 to 2.240.1 (#1067) via dependabot[bot] (@dependabot[bot])
* Bump fastlane from 2.239.0 to 2.240.0 (#1064) via dependabot[bot] (@dependabot[bot])
* ci: approve the release hold automatically when the release PR is approved (#1061) via Álvaro Brey (@AlvaroBrey)

## 8.2.2
## RevenueCat SDK
### 📦 Dependency Updates
* [AUTOMATIC BUMP] Updates purchases-hybrid-common to 19.0.0 (#1059) via RevenueCat Git Bot (@RCGitBot)
  * [Android 10.21.1](https://github.com/RevenueCat/purchases-android/releases/tag/10.21.1)
  * [Android 10.21.0](https://github.com/RevenueCat/purchases-android/releases/tag/10.21.0)
  * [iOS 5.89.0](https://github.com/RevenueCat/purchases-ios/releases/tag/5.89.0)
* [AUTOMATIC BUMP] Updates purchases-hybrid-common to 18.38.0 (#1058) via RevenueCat Git Bot (@RCGitBot)

## 8.2.1
## RevenueCat SDK
### 📦 Dependency Updates
* [AUTOMATIC BUMP] Updates purchases-hybrid-common to 18.36.1 (#1054) via RevenueCat Git Bot (@RCGitBot)
  * [Android 10.20.0](https://github.com/RevenueCat/purchases-android/releases/tag/10.20.0)
  * [iOS 5.88.0](https://github.com/RevenueCat/purchases-ios/releases/tag/5.88.0)
* [AUTOMATIC BUMP] Updates purchases-hybrid-common to 18.36.0 (#1053) via RevenueCat Git Bot (@RCGitBot)
* [AUTOMATIC BUMP] Updates purchases-hybrid-common to 18.35.0 (#1050) via RevenueCat Git Bot (@RCGitBot)
* [AUTOMATIC BUMP] Updates purchases-hybrid-common to 18.34.0 (#1049) via RevenueCat Git Bot (@RCGitBot)

### 🔄 Other Changes
* Bump fastlane from 2.238.0 to 2.239.0 (#1055) via dependabot[bot] (@dependabot[bot])
* ci: bump external PR notifications workflow to v8 (#1052) via Álvaro Brey (@AlvaroBrey)
* ci: notify external PRs feed on PRs from outside the org (#1051) via Álvaro Brey (@AlvaroBrey)

## 8.2.0
## RevenueCat SDK
### ✨ New Features
* feat(singular): add setSingularDeviceID (#1041) via Guillem Corominas (@guillemcorominas)
### 📦 Dependency Updates
* [AUTOMATIC BUMP] Updates purchases-hybrid-common to 18.33.1 (#1043) via RevenueCat Git Bot (@RCGitBot)
  * [Android 10.19.1](https://github.com/RevenueCat/purchases-android/releases/tag/10.19.1)
  * [Android 10.19.0](https://github.com/RevenueCat/purchases-android/releases/tag/10.19.0)
  * [iOS 5.87.1](https://github.com/RevenueCat/purchases-ios/releases/tag/5.87.1)
  * [iOS 5.87.0](https://github.com/RevenueCat/purchases-ios/releases/tag/5.87.0)
  * [iOS 5.86.0](https://github.com/RevenueCat/purchases-ios/releases/tag/5.86.0)

### 🔄 Other Changes
* Ship consumer ProGuard rules for PurchasesPlugin (Android) (#1047) via Toni Rico (@tonidero)
* Bump fastlane-plugin-revenuecat_internal from `7dd9ab9` to `6db1da0` (#1046) via dependabot[bot] (@dependabot[bot])

## 8.1.0
## RevenueCat SDK
### ✨ New Features
* feat: add setOnesignalUserID for OneSignal v11+ (#1020) via Cesar de la Vega (@vegaro)
### 📦 Dependency Updates
* [AUTOMATIC BUMP] Updates purchases-hybrid-common to 18.32.1 (#1036) via RevenueCat Git Bot (@RCGitBot)
  * [Android 10.18.1](https://github.com/RevenueCat/purchases-android/releases/tag/10.18.1)
  * [Android 10.18.0](https://github.com/RevenueCat/purchases-android/releases/tag/10.18.0)
  * [Android 10.17.0](https://github.com/RevenueCat/purchases-android/releases/tag/10.17.0)
  * [Android 10.16.2](https://github.com/RevenueCat/purchases-android/releases/tag/10.16.2)
  * [Android 10.16.1](https://github.com/RevenueCat/purchases-android/releases/tag/10.16.1)
  * [Android 10.16.0](https://github.com/RevenueCat/purchases-android/releases/tag/10.16.0)
  * [iOS 5.85.0](https://github.com/RevenueCat/purchases-ios/releases/tag/5.85.0)
  * [iOS 5.84.0](https://github.com/RevenueCat/purchases-ios/releases/tag/5.84.0)
  * [iOS 5.83.2](https://github.com/RevenueCat/purchases-ios/releases/tag/5.83.2)
  * [iOS 5.83.1](https://github.com/RevenueCat/purchases-ios/releases/tag/5.83.1)
  * [iOS 5.83.0](https://github.com/RevenueCat/purchases-ios/releases/tag/5.83.0)
* [AUTOMATIC BUMP] Updates purchases-hybrid-common to 18.31.0 (#1033) via RevenueCat Git Bot (@RCGitBot)
* [RENOVATE] Update dependency revenuecat to v4.6.0 (#1031) via RevenueCat Git Bot (@RCGitBot)
* [AUTOMATIC BUMP] Updates purchases-hybrid-common to 18.30.1 (#1030) via RevenueCat Git Bot (@RCGitBot)
* [AUTOMATIC BUMP] Updates purchases-hybrid-common to 18.30.0 (#1029) via RevenueCat Git Bot (@RCGitBot)
* [AUTOMATIC BUMP] Updates purchases-hybrid-common to 18.29.0 (#1022) via RevenueCat Git Bot (@RCGitBot)

### 🔄 Other Changes
* Update sdks-common-config orb to v4.6.1 (#1037) via Antonio Pallares (@ajpallares)
* Bump fastlane-plugin-revenuecat_internal from `7fbbe66` to `7dd9ab9` (#1034) via dependabot[bot] (@dependabot[bot])
* Bump fastlane from 2.237.0 to 2.238.0 (#1032) via dependabot[bot] (@dependabot[bot])
* Bump fastlane-plugin-revenuecat_internal from `b4e1e7f` to `7fbbe66` (#1028) via dependabot[bot] (@dependabot[bot])

## 8.0.14
## RevenueCat SDK
### 📦 Dependency Updates
* [AUTOMATIC BUMP] Updates purchases-hybrid-common to 18.27.0 (#1019) via RevenueCat Git Bot (@RCGitBot)
  * [iOS 5.82.0](https://github.com/RevenueCat/purchases-ios/releases/tag/5.82.0)

### 🔄 Other Changes
* Bump fastlane-plugin-revenuecat_internal from `dd577ee` to `b4e1e7f` (#1026) via dependabot[bot] (@dependabot[bot])
* Bump fastlane-plugin-revenuecat_internal from `3421c88` to `dd577ee` (#1023) via dependabot[bot] (@dependabot[bot])
* Bump danger from 9.6.0 to 9.6.1 (#1024) via dependabot[bot] (@dependabot[bot])

## 8.0.13
## RevenueCat SDK
### 📦 Dependency Updates
* [AUTOMATIC BUMP] Updates purchases-hybrid-common to 18.26.0 (#1016) via RevenueCat Git Bot (@RCGitBot)
  * [Android 10.15.1](https://github.com/RevenueCat/purchases-android/releases/tag/10.15.1)
  * [Android 10.15.0](https://github.com/RevenueCat/purchases-android/releases/tag/10.15.0)
  * [iOS 5.81.3](https://github.com/RevenueCat/purchases-ios/releases/tag/5.81.3)
  * [iOS 5.81.2](https://github.com/RevenueCat/purchases-ios/releases/tag/5.81.2)
* [AUTOMATIC BUMP] Updates purchases-hybrid-common to 18.25.0 (#1015) via RevenueCat Git Bot (@RCGitBot)
* [RENOVATE] Update dependency revenuecat to v4.5.1 (#1014) via RevenueCat Git Bot (@RCGitBot)

### 🔄 Other Changes
* Bump fastlane-plugin-revenuecat_internal from `d392939` to `3421c88` (#1017) via dependabot[bot] (@dependabot[bot])
* Bump fastlane-plugin-revenuecat_internal from `b52fca5` to `d392939` (#1012) via dependabot[bot] (@dependabot[bot])

## 8.0.12
## RevenueCat SDK
### 📦 Dependency Updates
* [AUTOMATIC BUMP] Updates purchases-hybrid-common to 18.22.2 (#1007) via RevenueCat Git Bot (@RCGitBot)
  * [Android 10.14.1](https://github.com/RevenueCat/purchases-android/releases/tag/10.14.1)
  * [Android 10.14.0](https://github.com/RevenueCat/purchases-android/releases/tag/10.14.0)
  * [Android 10.13.0](https://github.com/RevenueCat/purchases-android/releases/tag/10.13.0)
  * [iOS 5.81.1](https://github.com/RevenueCat/purchases-ios/releases/tag/5.81.1)
  * [iOS 5.81.0](https://github.com/RevenueCat/purchases-ios/releases/tag/5.81.0)
  * [iOS 5.80.3](https://github.com/RevenueCat/purchases-ios/releases/tag/5.80.3)
* [RENOVATE] Update dependency revenuecat to v4.5.0 (#1008) via RevenueCat Git Bot (@RCGitBot)

### 🔄 Other Changes
* Bump fastlane-plugin-revenuecat_internal from `9b928b6` to `b52fca5` (#1009) via dependabot[bot] (@dependabot[bot])
* chore: bump fastlane-plugin-revenuecat_internal to unblock hybrid bumps (#1006) via Antonio Pallares (@ajpallares)

## 8.0.11
## RevenueCat SDK
### 📦 Dependency Updates
* [RENOVATE] Update dependency revenuecat to v4 (#1002) via RevenueCat Git Bot (@RCGitBot)
* [AUTOMATIC BUMP] Updates purchases-hybrid-common to 18.21.0 (#1000) via RevenueCat Git Bot (@RCGitBot)
  * [Android 10.13.0](https://github.com/RevenueCat/purchases-android/releases/tag/10.13.0)
  * [iOS 5.80.3](https://github.com/RevenueCat/purchases-ios/releases/tag/5.80.3)
* [AUTOMATIC BUMP] Updates purchases-hybrid-common to 18.19.1 (#996) via RevenueCat Git Bot (@RCGitBot)

### 🔄 Other Changes
* Bump xcodeproj from 1.27.0 to 1.28.1 (#1001) via dependabot[bot] (@dependabot[bot])
* Bump fastlane from 2.236.1 to 2.237.0 (#997) via dependabot[bot] (@dependabot[bot])

## 8.0.10
## RevenueCat SDK
### 📦 Dependency Updates
* [AUTOMATIC BUMP] Updates purchases-hybrid-common to 18.19.0 (#994) via RevenueCat Git Bot (@RCGitBot)
  * [Android 10.12.0](https://github.com/RevenueCat/purchases-android/releases/tag/10.12.0)
  * [iOS 5.80.2](https://github.com/RevenueCat/purchases-ios/releases/tag/5.80.2)
  * [iOS 5.80.1](https://github.com/RevenueCat/purchases-ios/releases/tag/5.80.1)
* [AUTOMATIC BUMP] Updates purchases-hybrid-common to 18.18.0 (#990) via RevenueCat Git Bot (@RCGitBot)

## 8.0.9
## RevenueCat SDK
### 📦 Dependency Updates
* [AUTOMATIC BUMP] Updates purchases-hybrid-common to 18.17.0 (#989) via RevenueCat Git Bot (@RCGitBot)
  * [Android 10.11.0](https://github.com/RevenueCat/purchases-android/releases/tag/10.11.0)
  * [Android 10.10.0](https://github.com/RevenueCat/purchases-android/releases/tag/10.10.0)
  * [iOS 5.80.0](https://github.com/RevenueCat/purchases-ios/releases/tag/5.80.0)
  * [iOS 5.79.0](https://github.com/RevenueCat/purchases-ios/releases/tag/5.79.0)

### 🔄 Other Changes
* Bump faraday from 1.10.5 to 1.10.6 (#992) via dependabot[bot] (@dependabot[bot])
* Bump fastlane-plugin-revenuecat_internal from `70bf5c7` to `dab6765` (#991) via dependabot[bot] (@dependabot[bot])
* Use mise for JDK management (#986) via Álvaro Brey (@AlvaroBrey)
* Bump nokogiri from 1.19.3 to 1.19.4 (#985) via dependabot[bot] (@dependabot[bot])
* Bump danger from 9.5.3 to 9.6.0 (#984) via dependabot[bot] (@dependabot[bot])
* Update sdks-common-config orb to 3.21.2 (#983) via Antonio Pallares (@ajpallares)

## 8.0.8
## RevenueCat SDK
### 📦 Dependency Updates
* [AUTOMATIC BUMP] Updates purchases-hybrid-common to 18.15.1 (#980) via RevenueCat Git Bot (@RCGitBot)
  * [Android 10.9.1](https://github.com/RevenueCat/purchases-android/releases/tag/10.9.1)
  * [Android 10.9.0](https://github.com/RevenueCat/purchases-android/releases/tag/10.9.0)
  * [iOS 5.78.0](https://github.com/RevenueCat/purchases-ios/releases/tag/5.78.0)
  * [iOS 5.77.0](https://github.com/RevenueCat/purchases-ios/releases/tag/5.77.0)

### 🔄 Other Changes
* chore: Add 3-day Dependabot cooldown, excluding fastlane plugin (#981) via Toni Rico (@tonidero)
* Bump fastlane-plugin-revenuecat_internal from `ce6a7ef` to `70bf5c7` (#978) via dependabot[bot] (@dependabot[bot])
* Fix plugin-installation-test hang by using preinstalled CocoaPods (#979) via Antonio Pallares (@ajpallares)
* Bump fastlane from 2.236.0 to 2.236.1 (#974) via dependabot[bot] (@dependabot[bot])
* Bump fastlane from 2.235.0 to 2.236.0 (#972) via dependabot[bot] (@dependabot[bot])

## 8.0.7
## RevenueCat SDK
### 📦 Dependency Updates
* [AUTOMATIC BUMP] Updates purchases-hybrid-common to 18.10.0 (#969) via RevenueCat Git Bot (@RCGitBot)
  * [Android 10.8.0](https://github.com/RevenueCat/purchases-android/releases/tag/10.8.0)
  * [iOS 5.76.0](https://github.com/RevenueCat/purchases-ios/releases/tag/5.76.0)

## 8.0.6
## RevenueCat SDK
### 📦 Dependency Updates
* [AUTOMATIC BUMP] Updates purchases-hybrid-common to 18.9.1 (#965) via RevenueCat Git Bot (@RCGitBot)
  * [Android 10.7.0](https://github.com/RevenueCat/purchases-android/releases/tag/10.7.0)
  * [iOS 5.75.0](https://github.com/RevenueCat/purchases-ios/releases/tag/5.75.0)

### 🔄 Other Changes
* Bump fastlane-plugin-revenuecat_internal from `af7bb5c` to `ce6a7ef` (#967) via dependabot[bot] (@dependabot[bot])

## 8.0.5
## RevenueCat SDK
### 📦 Dependency Updates
* [AUTOMATIC BUMP] Updates purchases-hybrid-common to 18.8.0 (#961) via RevenueCat Git Bot (@RCGitBot)
  * [Android 10.6.1](https://github.com/RevenueCat/purchases-android/releases/tag/10.6.1)
  * [iOS 5.74.0](https://github.com/RevenueCat/purchases-ios/releases/tag/5.74.0)
  * [iOS 5.73.1](https://github.com/RevenueCat/purchases-ios/releases/tag/5.73.1)
* [AUTOMATIC BUMP] Updates purchases-hybrid-common to 18.7.1 (#960) via RevenueCat Git Bot (@RCGitBot)

### 🔄 Other Changes
* Bump fastlane from 2.234.0 to 2.235.0 (#962) via dependabot[bot] (@dependabot[bot])

## 8.0.4
## RevenueCat SDK
### 📦 Dependency Updates
* [AUTOMATIC BUMP] Updates purchases-hybrid-common to 18.7.0 (#958) via RevenueCat Git Bot (@RCGitBot)
  * [Android 10.6.0](https://github.com/RevenueCat/purchases-android/releases/tag/10.6.0)
  * [iOS 5.73.0](https://github.com/RevenueCat/purchases-ios/releases/tag/5.73.0)

## 8.0.3
## RevenueCat SDK
### 📦 Dependency Updates
* [AUTOMATIC BUMP] Updates purchases-hybrid-common to 18.6.0 (#954) via RevenueCat Git Bot (@RCGitBot)
  * [Android 10.5.0](https://github.com/RevenueCat/purchases-android/releases/tag/10.5.0)
  * [Android 10.4.0](https://github.com/RevenueCat/purchases-android/releases/tag/10.4.0)
  * [iOS 5.72.0](https://github.com/RevenueCat/purchases-ios/releases/tag/5.72.0)
  * [iOS 5.71.0](https://github.com/RevenueCat/purchases-ios/releases/tag/5.71.0)
* [AUTOMATIC BUMP] Updates purchases-hybrid-common to 18.5.0 (#953) via RevenueCat Git Bot (@RCGitBot)
* [AUTOMATIC BUMP] Updates purchases-hybrid-common to 18.4.0 (#951) via RevenueCat Git Bot (@RCGitBot)

### 🔄 Other Changes
* Remove update_fastlane from before_all (#956) via Antonio Pallares (@ajpallares)
* Bump fastlane from 2.233.1 to 2.234.0 (#955) via dependabot[bot] (@dependabot[bot])

## 8.0.2
## RevenueCat SDK
### 📦 Dependency Updates
* [AUTOMATIC BUMP] Updates purchases-hybrid-common to 18.3.0 (#948) via RevenueCat Git Bot (@RCGitBot)
  * [Android 10.3.1](https://github.com/RevenueCat/purchases-android/releases/tag/10.3.1)
  * [Android 10.3.0](https://github.com/RevenueCat/purchases-android/releases/tag/10.3.0)
  * [Android 10.2.1](https://github.com/RevenueCat/purchases-android/releases/tag/10.2.1)
  * [iOS 5.70.0](https://github.com/RevenueCat/purchases-ios/releases/tag/5.70.0)
  * [iOS 5.69.0](https://github.com/RevenueCat/purchases-ios/releases/tag/5.69.0)
* [AUTOMATIC BUMP] Updates purchases-hybrid-common to 18.2.0 (#946) via RevenueCat Git Bot (@RCGitBot)

### 🔄 Other Changes
* Bump fastlane-plugin-revenuecat_internal from `21e02ec` to `af7bb5c` (#950) via dependabot[bot] (@dependabot[bot])
* Bump fastlane-plugin-revenuecat_internal from `2d11430` to `21e02ec` (#949) via dependabot[bot] (@dependabot[bot])
* Bump fastlane-plugin-revenuecat_internal from `d24ab26` to `2d11430` (#947) via dependabot[bot] (@dependabot[bot])
* Replace unauthenticated SDKMAN install with SHA-pinned orb command (#944) via Rick (@rickvdl)
* Bump fastlane from 2.233.0 to 2.233.1 (#945) via dependabot[bot] (@dependabot[bot])
* Bump fastlane-plugin-revenuecat_internal from `b822f01` to `d24ab26` (#943) via dependabot[bot] (@dependabot[bot])
* Bump fastlane-plugin-revenuecat_internal from `e348913` to `b822f01` (#941) via dependabot[bot] (@dependabot[bot])
* Skip test cases list in maestro tests using launch arguments (#919) via Antonio Pallares (@ajpallares)
* Add CircleCI job for maestro E2E tests (#859) via Antonio Pallares (@ajpallares)
* Add maestro E2E test for purchase through paywall (#858) via Antonio Pallares (@ajpallares)
* Add maestro E2E test app (#857) via Antonio Pallares (@ajpallares)

## 8.0.1
## RevenueCat SDK
### 📦 Dependency Updates
* [AUTOMATIC BUMP] Updates purchases-hybrid-common to 18.1.0 (#936) via RevenueCat Git Bot (@RCGitBot)
  * [Android 10.2.0](https://github.com/RevenueCat/purchases-android/releases/tag/10.2.0)
  * [iOS 5.68.0](https://github.com/RevenueCat/purchases-ios/releases/tag/5.68.0)

### 🔄 Other Changes
* Bump fastlane-plugin-revenuecat_internal from `a1eed48` to `e348913` (#938) via dependabot[bot] (@dependabot[bot])
* Bump fastlane from 2.232.2 to 2.233.0 (#939) via dependabot[bot] (@dependabot[bot])
* Bump fastlane-plugin-revenuecat_internal from `20911d1` to `a1eed48` (#935) via dependabot[bot] (@dependabot[bot])

## 8.0.0
## RevenueCat SDK
> [!WARNING]  
> If you don't have any login system in your app, please make sure your one-time purchase products have been correctly configured in the RevenueCat dashboard as either consumable or non-consumable. If they're incorrect as consumables, RevenueCat will consume these purchases. This means that customers won't be able to restore them from version 8.0.0 onward.
> Non-consumables are products that are meant to be bought only once, for example, lifetime subscriptions. Please see more information in our [docs](https://www.revenuecat.com/docs/known-store-issues/play-billing-library/restore-consumable-purchases-bc8)

### 💥 Breaking Changes
This release updates to Billing Library 8.3.0 with min SDK supported of Android 6 (API 23), previously min was 21. It also removes a previous workaround used to be able to restore consumed one time products which is not available anymore.

* [AUTOMATIC BUMP] Updates purchases-hybrid-common to 18.0.0 (#932) via RevenueCat Git Bot (@RCGitBot)
  * [Android 10.1.2](https://github.com/RevenueCat/purchases-android/releases/tag/10.1.2)
  * [Android 10.1.1](https://github.com/RevenueCat/purchases-android/releases/tag/10.1.1)
  * [Android 10.1.0](https://github.com/RevenueCat/purchases-android/releases/tag/10.1.0)
  * [Android 10.0.2](https://github.com/RevenueCat/purchases-android/releases/tag/10.0.2)
  * [Android 10.0.1](https://github.com/RevenueCat/purchases-android/releases/tag/10.0.1)
  * [Android 9.29.1](https://github.com/RevenueCat/purchases-android/releases/tag/9.29.1)
  * [Android 10.0.0](https://github.com/RevenueCat/purchases-android/releases/tag/10.0.0)
  * [iOS 5.67.2](https://github.com/RevenueCat/purchases-ios/releases/tag/5.67.2)

### 🔄 Other Changes
* Bump fastlane-plugin-revenuecat_internal from `894bb1b` to `20911d1` (#931) via dependabot[bot] (@dependabot[bot])
* Update CODEOWNERS default owner to @RevenueCat/sdk (#929) via Antonio Pallares (@ajpallares)
* Bump fastlane-plugin-revenuecat_internal from `ceecf91` to `894bb1b` (#930) via dependabot[bot] (@dependabot[bot])
* Enable the use of `all-tests-succeeded` as the only required status check for merging PRs (#928) via Antonio Pallares (@ajpallares)
* Skip danger on non-PR pipelines and run-all-tests on bump (#927) via Antonio Pallares (@ajpallares)

## 7.3.6
## RevenueCat SDK
### 🐞 Bugfixes
* Fix CDVPluginResult compilation errors with cordova-ios 8 (#920) via Antonio Pallares (@ajpallares)
* fix: replace cordova-plugin-add-swift-support dependency with conditional hook (#910) via Antonio Pallares (@ajpallares)

### 🔄 Other Changes
* Restructure CI into run-all-tests, release, and deploy workflows (#924) via Antonio Pallares (@ajpallares)
* Run iOS integration tests on cordova-ios 6, 7, and 8 (#921) via Antonio Pallares (@ajpallares)
* Remove explicit git-based CocoaPods source from plugin.xml (#923) via Antonio Pallares (@ajpallares)
* Add plugin-installation-test CI job (#911) via Antonio Pallares (@ajpallares)
* Bump addressable from 2.8.9 to 2.9.0 (#918) via dependabot[bot] (@dependabot[bot])
* Bump fastlane-plugin-revenuecat_internal from `6289be1` to `ceecf91` (#917) via dependabot[bot] (@dependabot[bot])
* Consolidate api-tester into build-test workflow (#913) via Antonio Pallares (@ajpallares)

## 7.3.5
## RevenueCat SDK
### 📦 Dependency Updates
* [AUTOMATIC BUMP] Updates purchases-hybrid-common to 17.55.1 (#915) via RevenueCat Git Bot (@RCGitBot)
  * [Android 9.29.0](https://github.com/RevenueCat/purchases-android/releases/tag/9.29.0)
  * [iOS 5.67.1](https://github.com/RevenueCat/purchases-ios/releases/tag/5.67.1)
* [AUTOMATIC BUMP] Updates purchases-hybrid-common to 17.55.0 (#912) via RevenueCat Git Bot (@RCGitBot)

### 🔄 Other Changes
* Bump fastlane-plugin-revenuecat_internal from `5d6e93f` to `6289be1` (#909) via dependabot[bot] (@dependabot[bot])
* Bump fastlane-plugin-revenuecat_internal from `f11fe40` to `5d6e93f` (#908) via dependabot[bot] (@dependabot[bot])

## 7.3.4
## RevenueCat SDK
### 📦 Dependency Updates
* [AUTOMATIC BUMP] Updates purchases-hybrid-common to 17.54.0 (#906) via RevenueCat Git Bot (@RCGitBot)
  * [Android 9.28.1](https://github.com/RevenueCat/purchases-android/releases/tag/9.28.1)
  * [Android 9.28.0](https://github.com/RevenueCat/purchases-android/releases/tag/9.28.0)
  * [Android 9.27.0](https://github.com/RevenueCat/purchases-android/releases/tag/9.27.0)
  * [Android 9.26.1](https://github.com/RevenueCat/purchases-android/releases/tag/9.26.1)
  * [Android 9.26.0](https://github.com/RevenueCat/purchases-android/releases/tag/9.26.0)
  * [Android 9.25.0](https://github.com/RevenueCat/purchases-android/releases/tag/9.25.0)
  * [Android 9.24.0](https://github.com/RevenueCat/purchases-android/releases/tag/9.24.0)
  * [iOS 5.67.0](https://github.com/RevenueCat/purchases-ios/releases/tag/5.67.0)
  * [iOS 5.66.0](https://github.com/RevenueCat/purchases-ios/releases/tag/5.66.0)
  * [iOS 5.65.0](https://github.com/RevenueCat/purchases-ios/releases/tag/5.65.0)
  * [iOS 5.64.0](https://github.com/RevenueCat/purchases-ios/releases/tag/5.64.0)
  * [iOS 5.63.0](https://github.com/RevenueCat/purchases-ios/releases/tag/5.63.0)
  * [iOS 5.62.0](https://github.com/RevenueCat/purchases-ios/releases/tag/5.62.0)

### 🔄 Other Changes
* Bump fastlane-plugin-revenuecat_internal from `9a6911b` to `f11fe40` (#904) via dependabot[bot] (@dependabot[bot])
* security: pin GitHub Actions to SHA hashes (#901) via Alfonso Embid-Desmet (@alfondotnet)
* Bump activesupport from 8.0.2.1 to 8.0.4.1 (#897) via dependabot[bot] (@dependabot[bot])
* Fix deprecated TypeScript compiler options in apiTester (#899) via Toni Rico (@tonidero)
* Merge release PR after deploy (#896) via Antonio Pallares (@ajpallares)
* Require PR approval before release tagging (#895) via Antonio Pallares (@ajpallares)
* Bump json from 2.18.1 to 2.19.2 (#893) via dependabot[bot] (@dependabot[bot])
* Bump fastlane-plugin-revenuecat_internal from `3e8c384` to `9a6911b` (#889) via dependabot[bot] (@dependabot[bot])
* Bump fastlane-plugin-revenuecat_internal from `e146447` to `3e8c384` (#883) via dependabot[bot] (@dependabot[bot])
* Add galaxy to store docs (#880) via Will Taylor (@fire-at-will)

## 7.3.3
## RevenueCat SDK
### 📦 Dependency Updates
* [AUTOMATIC BUMP] Updates purchases-hybrid-common to 17.46.1 (#875) via RevenueCat Git Bot (@RCGitBot)
  * [Android 9.23.1](https://github.com/RevenueCat/purchases-android/releases/tag/9.23.1)
  * [Android 9.23.0](https://github.com/RevenueCat/purchases-android/releases/tag/9.23.0)
  * [iOS 5.61.0](https://github.com/RevenueCat/purchases-ios/releases/tag/5.61.0)
* [AUTOMATIC BUMP] Updates purchases-hybrid-common to 17.46.0 (#873) via RevenueCat Git Bot (@RCGitBot)
  * [Android 9.23.1](https://github.com/RevenueCat/purchases-android/releases/tag/9.23.1)
  * [Android 9.23.0](https://github.com/RevenueCat/purchases-android/releases/tag/9.23.0)
  * [iOS 5.61.0](https://github.com/RevenueCat/purchases-ios/releases/tag/5.61.0)
* [AUTOMATIC BUMP] Updates purchases-hybrid-common to 17.45.0 (#870) via RevenueCat Git Bot (@RCGitBot)
  * [Android 9.23.1](https://github.com/RevenueCat/purchases-android/releases/tag/9.23.1)
  * [Android 9.23.0](https://github.com/RevenueCat/purchases-android/releases/tag/9.23.0)
  * [iOS 5.61.0](https://github.com/RevenueCat/purchases-ios/releases/tag/5.61.0)
* [AUTOMATIC BUMP] Updates purchases-hybrid-common to 17.44.0 (#868) via RevenueCat Git Bot (@RCGitBot)
  * [Android 9.23.1](https://github.com/RevenueCat/purchases-android/releases/tag/9.23.1)
  * [Android 9.23.0](https://github.com/RevenueCat/purchases-android/releases/tag/9.23.0)
  * [iOS 5.61.0](https://github.com/RevenueCat/purchases-ios/releases/tag/5.61.0)

### 🔄 Other Changes
* Bump fastlane-plugin-revenuecat_internal from `f5c099b` to `e146447` (#872) via dependabot[bot] (@dependabot[bot])
* Bump fastlane-plugin-revenuecat_internal from `8cd957f` to `f5c099b` (#866) via dependabot[bot] (@dependabot[bot])

## 7.3.2
## RevenueCat SDK
### 📦 Dependency Updates
* [AUTOMATIC BUMP] Updates purchases-hybrid-common to 17.42.0 (#863) via RevenueCat Git Bot (@RCGitBot)
  * [Android 9.22.2](https://github.com/RevenueCat/purchases-android/releases/tag/9.22.2)
  * [iOS 5.60.0](https://github.com/RevenueCat/purchases-ios/releases/tag/5.60.0)

### 🔄 Other Changes
* Fix docs-deploy by using SSH URL instead of HTTPS (#862) via Antonio Pallares (@ajpallares)
* Update sdks-common-config orb to 3.13.0 (#861) via Cesar de la Vega (@vegaro)
* Bump fastlane from 2.232.1 to 2.232.2 (#860) via dependabot[bot] (@dependabot[bot])
* Bump fastlane-plugin-revenuecat_internal from `ea6276c` to `8cd957f` (#856) via dependabot[bot] (@dependabot[bot])

## 7.3.1
## RevenueCat SDK
### 📦 Dependency Updates
* [AUTOMATIC BUMP] Updates purchases-hybrid-common to 17.41.1 (#853) via RevenueCat Git Bot (@RCGitBot)
  * [Android 9.22.1](https://github.com/RevenueCat/purchases-android/releases/tag/9.22.1)
  * [iOS 5.59.2](https://github.com/RevenueCat/purchases-ios/releases/tag/5.59.2)
  * [iOS 5.59.1](https://github.com/RevenueCat/purchases-ios/releases/tag/5.59.1)
* [AUTOMATIC BUMP] Updates purchases-hybrid-common to 17.41.0 (#849) via RevenueCat Git Bot (@RCGitBot)
  * [Android 9.22.1](https://github.com/RevenueCat/purchases-android/releases/tag/9.22.1)
  * [iOS 5.59.2](https://github.com/RevenueCat/purchases-ios/releases/tag/5.59.2)
  * [iOS 5.59.1](https://github.com/RevenueCat/purchases-ios/releases/tag/5.59.1)

### 🔄 Other Changes
* Fix formatting of version 7.1.2 entry in VERSIONS.md (#854) via Cesar de la Vega (@vegaro)
* Bump fastlane-plugin-revenuecat_internal from `afc9219` to `ea6276c` (#852) via dependabot[bot] (@dependabot[bot])

## 7.3.0
## RevenueCat SDK
### ✨ New Features
* [SDK-4250] Add webCheckoutUrl to PurchasesPackage and PurchasesOffering (#837) via Toni Rico (@tonidero)
### 📦 Dependency Updates
* [AUTOMATIC BUMP] Updates purchases-hybrid-common to 17.40.0 (#847) via RevenueCat Git Bot (@RCGitBot)
  * [Android 9.22.0](https://github.com/RevenueCat/purchases-android/releases/tag/9.22.0)
  * [Android 9.21.0](https://github.com/RevenueCat/purchases-android/releases/tag/9.21.0)
  * [iOS 5.59.0](https://github.com/RevenueCat/purchases-ios/releases/tag/5.59.0)
  * [iOS 5.58.1](https://github.com/RevenueCat/purchases-ios/releases/tag/5.58.1)
  * [iOS 5.58.0](https://github.com/RevenueCat/purchases-ios/releases/tag/5.58.0)

### 🔄 Other Changes
* Bump fastlane-plugin-revenuecat_internal from `e6454e3` to `afc9219` (#845) via dependabot[bot] (@dependabot[bot])
* Bump faraday from 1.10.4 to 1.10.5 (#842) via dependabot[bot] (@dependabot[bot])

## 7.2.17
## RevenueCat SDK
### 📦 Dependency Updates
* Updates purchases-hybrid-common to 17.33.1 (#835) via RevenueCat Git Bot (@RCGitBot)
  * [Android 9.20.2](https://github.com/RevenueCat/purchases-android/releases/tag/9.20.2)
  * [Android 9.20.1](https://github.com/RevenueCat/purchases-android/releases/tag/9.20.1)
  * [iOS 5.57.2](https://github.com/RevenueCat/purchases-ios/releases/tag/5.57.2)
  * [iOS 5.57.1](https://github.com/RevenueCat/purchases-ios/releases/tag/5.57.1)
* [AUTOMATIC BUMP] Updates purchases-hybrid-common to 17.32.0 (#832) via RevenueCat Git Bot (@RCGitBot)
  * [Android 9.20.2](https://github.com/RevenueCat/purchases-android/releases/tag/9.20.2)
  * [Android 9.20.1](https://github.com/RevenueCat/purchases-android/releases/tag/9.20.1)
  * [iOS 5.57.2](https://github.com/RevenueCat/purchases-ios/releases/tag/5.57.2)
  * [iOS 5.57.1](https://github.com/RevenueCat/purchases-ios/releases/tag/5.57.1)

### 🔄 Other Changes
* Bump fastlane from 2.232.0 to 2.232.1 (#836) via dependabot[bot] (@dependabot[bot])
* Bump fastlane from 2.231.1 to 2.232.0 (#834) via dependabot[bot] (@dependabot[bot])

## 7.2.16
## RevenueCat SDK
### 📦 Dependency Updates
* [AUTOMATIC BUMP] Updates purchases-hybrid-common to 17.31.0 (#830) via RevenueCat Git Bot (@RCGitBot)
  * [Android 9.20.0](https://github.com/RevenueCat/purchases-android/releases/tag/9.20.0)
  * [Android 9.19.4](https://github.com/RevenueCat/purchases-android/releases/tag/9.19.4)
  * [iOS 5.57.0](https://github.com/RevenueCat/purchases-ios/releases/tag/5.57.0)
  * [iOS 5.56.1](https://github.com/RevenueCat/purchases-ios/releases/tag/5.56.1)

## 7.2.15
## RevenueCat SDK
### 📦 Dependency Updates
* [AUTOMATIC BUMP] Updates purchases-hybrid-common to 17.30.0 (#824) via RevenueCat Git Bot (@RCGitBot)
  * [Android 9.19.3](https://github.com/RevenueCat/purchases-android/releases/tag/9.19.3)
  * [Android 9.19.2](https://github.com/RevenueCat/purchases-android/releases/tag/9.19.2)
  * [iOS 5.56.0](https://github.com/RevenueCat/purchases-ios/releases/tag/5.56.0)
  * [iOS 5.55.3](https://github.com/RevenueCat/purchases-ios/releases/tag/5.55.3)

### 🔄 Other Changes
* Updated CircleCI resources class from M1 to M4 (#825) via Rick (@rickvdl)

## 7.2.14
## RevenueCat SDK
### 📦 Dependency Updates
* [AUTOMATIC BUMP] Updates purchases-hybrid-common to 17.28.1 (#819) via RevenueCat Git Bot (@RCGitBot)
  * [Android 9.19.1](https://github.com/RevenueCat/purchases-android/releases/tag/9.19.1)
  * [Android 9.19.0](https://github.com/RevenueCat/purchases-android/releases/tag/9.19.0)
  * [iOS 5.55.2](https://github.com/RevenueCat/purchases-ios/releases/tag/5.55.2)
  * [iOS 5.55.1](https://github.com/RevenueCat/purchases-ios/releases/tag/5.55.1)
  * [iOS 5.55.0](https://github.com/RevenueCat/purchases-ios/releases/tag/5.55.0)
  * [iOS 5.54.1](https://github.com/RevenueCat/purchases-ios/releases/tag/5.54.1)
  * [iOS 5.54.0](https://github.com/RevenueCat/purchases-ios/releases/tag/5.54.0)
  * [iOS 5.53.0](https://github.com/RevenueCat/purchases-ios/releases/tag/5.53.0)
* [AUTOMATIC BUMP] Updates purchases-hybrid-common to 17.28.0 (#817) via RevenueCat Git Bot (@RCGitBot)
  * [Android 9.19.1](https://github.com/RevenueCat/purchases-android/releases/tag/9.19.1)
  * [Android 9.19.0](https://github.com/RevenueCat/purchases-android/releases/tag/9.19.0)
  * [iOS 5.55.2](https://github.com/RevenueCat/purchases-ios/releases/tag/5.55.2)
  * [iOS 5.55.1](https://github.com/RevenueCat/purchases-ios/releases/tag/5.55.1)
  * [iOS 5.55.0](https://github.com/RevenueCat/purchases-ios/releases/tag/5.55.0)
  * [iOS 5.54.1](https://github.com/RevenueCat/purchases-ios/releases/tag/5.54.1)
  * [iOS 5.54.0](https://github.com/RevenueCat/purchases-ios/releases/tag/5.54.0)
  * [iOS 5.53.0](https://github.com/RevenueCat/purchases-ios/releases/tag/5.53.0)

### 🔄 Other Changes
* Bump fastlane from 2.231.0 to 2.231.1 (#820) via dependabot[bot] (@dependabot[bot])
* Bump fastlane from 2.230.0 to 2.231.0 (#818) via dependabot[bot] (@dependabot[bot])

## 7.2.13
## RevenueCat SDK
### 📦 Dependency Updates
* [AUTOMATIC BUMP] Updates purchases-hybrid-common to 17.26.1 (#813) via RevenueCat Git Bot (@RCGitBot)
  * [Android 9.18.1](https://github.com/RevenueCat/purchases-android/releases/tag/9.18.1)
  * [iOS 5.52.1](https://github.com/RevenueCat/purchases-ios/releases/tag/5.52.1)

## 7.2.12
## RevenueCat SDK
### 📦 Dependency Updates
* [AUTOMATIC BUMP] Updates purchases-hybrid-common to 17.26.0 (#810) via RevenueCat Git Bot (@RCGitBot)
  * [iOS 5.52.0](https://github.com/RevenueCat/purchases-ios/releases/tag/5.52.0)

### 🔄 Other Changes
* Bump uri from 1.0.3 to 1.0.4 (#811) via dependabot[bot] (@dependabot[bot])

## 7.2.11
## RevenueCat SDK
### 📦 Dependency Updates
* [AUTOMATIC BUMP] Updates purchases-hybrid-common to 17.25.0 (#807) via RevenueCat Git Bot (@RCGitBot)
  * [Android 9.18.0](https://github.com/RevenueCat/purchases-android/releases/tag/9.18.0)
  * [Android 9.17.1](https://github.com/RevenueCat/purchases-android/releases/tag/9.17.1)
  * [Android 9.17.0](https://github.com/RevenueCat/purchases-android/releases/tag/9.17.0)
  * [Android 9.16.0](https://github.com/RevenueCat/purchases-android/releases/tag/9.16.0)
  * [iOS 5.51.1](https://github.com/RevenueCat/purchases-ios/releases/tag/5.51.1)
  * [iOS 5.51.0](https://github.com/RevenueCat/purchases-ios/releases/tag/5.51.0)

### 🔄 Other Changes
* Bump fastlane-plugin-revenuecat_internal from `76a3a08` to `e6454e3` (#808) via dependabot[bot] (@dependabot[bot])
* Bump fastlane from 2.229.1 to 2.230.0 (#806) via dependabot[bot] (@dependabot[bot])

## 7.2.10
> [!WARNING]  
> If you don't have any login system in your app, please make sure your one-time purchase products have been correctly configured in the RevenueCat dashboard as either consumable or non-consumable. If they're incorrectly configured as consumables, RevenueCat will consume these purchases. This means that users won't be able to restore them from version 7.0.0 onward.
> Non-consumables are products that are meant to be bought only once, for example, lifetime subscriptions.


## RevenueCat SDK
### 📦 Dependency Updates
* [AUTOMATIC BUMP] Updates purchases-hybrid-common to 17.24.0 (#803) via RevenueCat Git Bot (@RCGitBot)
  * [Android 9.15.5](https://github.com/RevenueCat/purchases-android/releases/tag/9.15.5)
  * [Android 9.15.4](https://github.com/RevenueCat/purchases-android/releases/tag/9.15.4)
  * [iOS 5.50.1](https://github.com/RevenueCat/purchases-ios/releases/tag/5.50.1)

## 7.2.9
> [!WARNING]  
> If you don't have any login system in your app, please make sure your one-time purchase products have been correctly configured in the RevenueCat dashboard as either consumable or non-consumable. If they're incorrectly configured as consumables, RevenueCat will consume these purchases. This means that users won't be able to restore them from version 7.0.0 onward.
> Non-consumables are products that are meant to be bought only once, for example, lifetime subscriptions.


## RevenueCat SDK
### 📦 Dependency Updates
* [AUTOMATIC BUMP] Updates purchases-hybrid-common to 17.23.0 (#800) via RevenueCat Git Bot (@RCGitBot)
  * [Android 9.15.3](https://github.com/RevenueCat/purchases-android/releases/tag/9.15.3)
  * [Android 9.15.2](https://github.com/RevenueCat/purchases-android/releases/tag/9.15.2)
  * [iOS 5.50.0](https://github.com/RevenueCat/purchases-ios/releases/tag/5.50.0)
  * [iOS 5.49.3](https://github.com/RevenueCat/purchases-ios/releases/tag/5.49.3)
  * [iOS 5.49.2](https://github.com/RevenueCat/purchases-ios/releases/tag/5.49.2)

### 🔄 Other Changes
* Bump fastlane-plugin-revenuecat_internal from `efca663` to `76a3a08` (#801) via dependabot[bot] (@dependabot[bot])

## 7.2.8
> [!WARNING]  
> If you don't have any login system in your app, please make sure your one-time purchase products have been correctly configured in the RevenueCat dashboard as either consumable or non-consumable. If they're incorrectly configured as consumables, RevenueCat will consume these purchases. This means that users won't be able to restore them from version 7.0.0 onward.
> Non-consumables are products that are meant to be bought only once, for example, lifetime subscriptions.


## RevenueCat SDK
### 📦 Dependency Updates
* [AUTOMATIC BUMP] Updates purchases-hybrid-common to 17.21.1 (#794) via RevenueCat Git Bot (@RCGitBot)
  * [Android 9.15.1](https://github.com/RevenueCat/purchases-android/releases/tag/9.15.1)
  * [iOS 5.49.1](https://github.com/RevenueCat/purchases-ios/releases/tag/5.49.1)

### 🔄 Other Changes
* Update jobs xcode to 16.4 (#797) via Toni Rico (@tonidero)

## 7.2.7
> [!WARNING]  
> If you don't have any login system in your app, please make sure your one-time purchase products have been correctly configured in the RevenueCat dashboard as either consumable or non-consumable. If they're incorrectly configured as consumables, RevenueCat will consume these purchases. This means that users won't be able to restore them from version 7.0.0 onward.
> Non-consumables are products that are meant to be bought only once, for example, lifetime subscriptions.


## RevenueCat SDK
### 📦 Dependency Updates
* [AUTOMATIC BUMP] Updates purchases-hybrid-common to 17.21.0 (#792) via RevenueCat Git Bot (@RCGitBot)
  * [Android 9.15.0](https://github.com/RevenueCat/purchases-android/releases/tag/9.15.0)
  * [Android 9.14.1](https://github.com/RevenueCat/purchases-android/releases/tag/9.14.1)
  * [iOS 5.49.0](https://github.com/RevenueCat/purchases-ios/releases/tag/5.49.0)
* [AUTOMATIC BUMP] Updates purchases-hybrid-common to 17.20.0 (#790) via RevenueCat Git Bot (@RCGitBot)
  * [Android 9.15.0](https://github.com/RevenueCat/purchases-android/releases/tag/9.15.0)
  * [Android 9.14.1](https://github.com/RevenueCat/purchases-android/releases/tag/9.14.1)
  * [iOS 5.49.0](https://github.com/RevenueCat/purchases-ios/releases/tag/5.49.0)

### 🔄 Other Changes
* Bump fastlane from 2.229.0 to 2.229.1 (#791) via dependabot[bot] (@dependabot[bot])
* Bump fastlane-plugin-revenuecat_internal from `083ced9` to `efca663` (#788) via dependabot[bot] (@dependabot[bot])
* Bump fastlane from 2.228.0 to 2.229.0 (#789) via dependabot[bot] (@dependabot[bot])

## 7.2.6
> [!WARNING]  
> If you don't have any login system in your app, please make sure your one-time purchase products have been correctly configured in the RevenueCat dashboard as either consumable or non-consumable. If they're incorrectly configured as consumables, RevenueCat will consume these purchases. This means that users won't be able to restore them from version 7.0.0 onward.
> Non-consumables are products that are meant to be bought only once, for example, lifetime subscriptions.


## RevenueCat SDK
### 📦 Dependency Updates
* [AUTOMATIC BUMP] Updates purchases-hybrid-common to 17.19.1 (#785) via RevenueCat Git Bot (@RCGitBot)
  * [Android 9.14.1](https://github.com/RevenueCat/purchases-android/releases/tag/9.14.1)
  * [Android 9.14.0](https://github.com/RevenueCat/purchases-android/releases/tag/9.14.0)
  * [iOS 5.48.0](https://github.com/RevenueCat/purchases-ios/releases/tag/5.48.0)
  * [iOS 5.47.1](https://github.com/RevenueCat/purchases-ios/releases/tag/5.47.1)
* [AUTOMATIC BUMP] Updates purchases-hybrid-common to 17.19.0 (#784) via RevenueCat Git Bot (@RCGitBot)
  * [Android 9.14.1](https://github.com/RevenueCat/purchases-android/releases/tag/9.14.1)
  * [Android 9.14.0](https://github.com/RevenueCat/purchases-android/releases/tag/9.14.0)
  * [iOS 5.48.0](https://github.com/RevenueCat/purchases-ios/releases/tag/5.48.0)
  * [iOS 5.47.1](https://github.com/RevenueCat/purchases-ios/releases/tag/5.47.1)

## 7.2.5
> [!WARNING]  
> If you don't have any login system in your app, please make sure your one-time purchase products have been correctly configured in the RevenueCat dashboard as either consumable or non-consumable. If they're incorrectly configured as consumables, RevenueCat will consume these purchases. This means that users won't be able to restore them from version 7.0.0 onward.
> Non-consumables are products that are meant to be bought only once, for example, lifetime subscriptions.


## RevenueCat SDK
### 📦 Dependency Updates
* [AUTOMATIC BUMP] Updates purchases-hybrid-common to 17.18.1 (#782) via RevenueCat Git Bot (@RCGitBot)
  * [Android 9.14.1](https://github.com/RevenueCat/purchases-android/releases/tag/9.14.1)
  * [Android 9.14.0](https://github.com/RevenueCat/purchases-android/releases/tag/9.14.0)
  * [iOS 5.48.0](https://github.com/RevenueCat/purchases-ios/releases/tag/5.48.0)
  * [iOS 5.47.1](https://github.com/RevenueCat/purchases-ios/releases/tag/5.47.1)
* [AUTOMATIC BUMP] Updates purchases-hybrid-common to 17.18.0 (#780) via RevenueCat Git Bot (@RCGitBot)
  * [Android 9.14.1](https://github.com/RevenueCat/purchases-android/releases/tag/9.14.1)
  * [Android 9.14.0](https://github.com/RevenueCat/purchases-android/releases/tag/9.14.0)
  * [iOS 5.48.0](https://github.com/RevenueCat/purchases-ios/releases/tag/5.48.0)
  * [iOS 5.47.1](https://github.com/RevenueCat/purchases-ios/releases/tag/5.47.1)

### 🔄 Other Changes
* Bump fastlane-plugin-revenuecat_internal from `1e3e3fd` to `083ced9` (#781) via dependabot[bot] (@dependabot[bot])
* Bump fastlane-plugin-revenuecat_internal from `9362b21` to `1e3e3fd` (#779) via dependabot[bot] (@dependabot[bot])

## 7.2.4
> [!WARNING]  
> If you don't have any login system in your app, please make sure your one-time purchase products have been correctly configured in the RevenueCat dashboard as either consumable or non-consumable. If they're incorrectly configured as consumables, RevenueCat will consume these purchases. This means that users won't be able to restore them from version 7.0.0 onward.
> Non-consumables are products that are meant to be bought only once, for example, lifetime subscriptions.


## RevenueCat SDK
### 📦 Dependency Updates
* [AUTOMATIC BUMP] Updates purchases-hybrid-common to 17.17.0 (#776) via RevenueCat Git Bot (@RCGitBot)
  * [Android 9.13.0](https://github.com/RevenueCat/purchases-android/releases/tag/9.13.0)
  * [iOS 5.47.0](https://github.com/RevenueCat/purchases-ios/releases/tag/5.47.0)
  * [iOS 5.46.3](https://github.com/RevenueCat/purchases-ios/releases/tag/5.46.3)
  * [iOS 5.46.2](https://github.com/RevenueCat/purchases-ios/releases/tag/5.46.2)
* [AUTOMATIC BUMP] Updates purchases-hybrid-common to 17.16.1 (#775) via RevenueCat Git Bot (@RCGitBot)
  * [Android 9.13.0](https://github.com/RevenueCat/purchases-android/releases/tag/9.13.0)
  * [iOS 5.47.0](https://github.com/RevenueCat/purchases-ios/releases/tag/5.47.0)
  * [iOS 5.46.3](https://github.com/RevenueCat/purchases-ios/releases/tag/5.46.3)
  * [iOS 5.46.2](https://github.com/RevenueCat/purchases-ios/releases/tag/5.46.2)

### 🔄 Other Changes
* Bump fastlane-plugin-revenuecat_internal from `525d48c` to `9362b21` (#777) via dependabot[bot] (@dependabot[bot])

## 7.2.3
> [!WARNING]  
> If you don't have any login system in your app, please make sure your one-time purchase products have been correctly configured in the RevenueCat dashboard as either consumable or non-consumable. If they're incorrectly configured as consumables, RevenueCat will consume these purchases. This means that users won't be able to restore them from version 7.0.0 onward.
> Non-consumables are products that are meant to be bought only once, for example, lifetime subscriptions.


## RevenueCat SDK
### 📦 Dependency Updates
* [AUTOMATIC BUMP] Updates purchases-hybrid-common to 17.16.0 (#773) via RevenueCat Git Bot (@RCGitBot)
  * [Android 9.12.2](https://github.com/RevenueCat/purchases-android/releases/tag/9.12.2)
  * [iOS 5.46.1](https://github.com/RevenueCat/purchases-ios/releases/tag/5.46.1)

## 7.2.2
> [!WARNING]  
> If you don't have any login system in your app, please make sure your one-time purchase products have been correctly configured in the RevenueCat dashboard as either consumable or non-consumable. If they're incorrectly configured as consumables, RevenueCat will consume these purchases. This means that users won't be able to restore them from version 7.0.0 onward.
> Non-consumables are products that are meant to be bought only once, for example, lifetime subscriptions.


## RevenueCat SDK
### 📦 Dependency Updates
* [AUTOMATIC BUMP] Updates purchases-hybrid-common to 17.13.0 (#766) via RevenueCat Git Bot (@RCGitBot)
  * [Android 9.12.1](https://github.com/RevenueCat/purchases-android/releases/tag/9.12.1)
  * [Android 9.12.0](https://github.com/RevenueCat/purchases-android/releases/tag/9.12.0)
  * [iOS 5.46.0](https://github.com/RevenueCat/purchases-ios/releases/tag/5.46.0)
  * [iOS 5.45.1](https://github.com/RevenueCat/purchases-ios/releases/tag/5.45.1)
  * [iOS 5.45.0](https://github.com/RevenueCat/purchases-ios/releases/tag/5.45.0)
* [AUTOMATIC BUMP] Updates purchases-hybrid-common to 17.12.0 (#764) via RevenueCat Git Bot (@RCGitBot)
  * [Android 9.12.1](https://github.com/RevenueCat/purchases-android/releases/tag/9.12.1)
  * [Android 9.12.0](https://github.com/RevenueCat/purchases-android/releases/tag/9.12.0)
  * [iOS 5.46.0](https://github.com/RevenueCat/purchases-ios/releases/tag/5.46.0)
  * [iOS 5.45.1](https://github.com/RevenueCat/purchases-ios/releases/tag/5.45.1)
  * [iOS 5.45.0](https://github.com/RevenueCat/purchases-ios/releases/tag/5.45.0)

## 7.2.1
> [!WARNING]  
> If you don't have any login system in your app, please make sure your one-time purchase products have been correctly configured in the RevenueCat dashboard as either consumable or non-consumable. If they're incorrectly configured as consumables, RevenueCat will consume these purchases. This means that users won't be able to restore them from version 7.0.0 onward.
> Non-consumables are products that are meant to be bought only once, for example, lifetime subscriptions.


## RevenueCat SDK
### 📦 Dependency Updates
* [AUTOMATIC BUMP] Updates purchases-hybrid-common to 17.11.0 (#762) via RevenueCat Git Bot (@RCGitBot)
  * [Android 9.11.0](https://github.com/RevenueCat/purchases-android/releases/tag/9.11.0)
  * [Android 9.10.0](https://github.com/RevenueCat/purchases-android/releases/tag/9.10.0)
  * [iOS 5.44.1](https://github.com/RevenueCat/purchases-ios/releases/tag/5.44.1)
  * [iOS 5.44.0](https://github.com/RevenueCat/purchases-ios/releases/tag/5.44.0)

### 🔄 Other Changes
* Bump fastlane-plugin-revenuecat_internal from `25c7fb8` to `525d48c` (#761) via dependabot[bot] (@dependabot[bot])
* Update Xcode versions to avoid CircleCI deprecation (#760) via Antonio Pallares (@ajpallares)

## 7.2.0
> [!WARNING]  
> If you don't have any login system in your app, please make sure your one-time purchase products have been correctly configured in the RevenueCat dashboard as either consumable or non-consumable. If they're incorrectly configured as consumables, RevenueCat will consume these purchases. This means that users won't be able to restore them from version 7.0.0 onward.
> Non-consumables are products that are meant to be bought only once, for example, lifetime subscriptions.


## RevenueCat SDK
### ✨ New Features
* [AUTOMATIC BUMP] Updates purchases-hybrid-common to 17.10.0 (#758) via RevenueCat Git Bot (@RCGitBot)
  * [Android 9.9.0](https://github.com/RevenueCat/purchases-android/releases/tag/9.9.0)
  * [Android 9.8.1](https://github.com/RevenueCat/purchases-android/releases/tag/9.8.1)
  * [iOS 5.43.0](https://github.com/RevenueCat/purchases-ios/releases/tag/5.43.0)
  * [iOS 5.42.0](https://github.com/RevenueCat/purchases-ios/releases/tag/5.42.0)
* [AUTOMATIC BUMP] Updates purchases-hybrid-common to 17.9.1 (#756) via RevenueCat Git Bot (@RCGitBot)
  * [Android 9.9.0](https://github.com/RevenueCat/purchases-android/releases/tag/9.9.0)
  * [Android 9.8.1](https://github.com/RevenueCat/purchases-android/releases/tag/9.8.1)
  * [iOS 5.43.0](https://github.com/RevenueCat/purchases-ios/releases/tag/5.43.0)
  * [iOS 5.42.0](https://github.com/RevenueCat/purchases-ios/releases/tag/5.42.0)

### 🔄 Other Changes
* Bump fastlane-plugin-revenuecat_internal from `3f7fffc` to `25c7fb8` (#757) via dependabot[bot] (@dependabot[bot])

## 7.1.5
> [!WARNING]  
> If you don't have any login system in your app, please make sure your one-time purchase products have been correctly configured in the RevenueCat dashboard as either consumable or non-consumable. If they're incorrectly configured as consumables, RevenueCat will consume these purchases. This means that users won't be able to restore them from version 7.0.0 onward.
> Non-consumables are products that are meant to be bought only once, for example, lifetime subscriptions.


## RevenueCat SDK
### 📦 Dependency Updates
* [AUTOMATIC BUMP] Updates purchases-hybrid-common to 17.9.0 (#745) via RevenueCat Git Bot (@RCGitBot)
  * [Android 9.8.0](https://github.com/RevenueCat/purchases-android/releases/tag/9.8.0)
  * [iOS 5.41.0](https://github.com/RevenueCat/purchases-ios/releases/tag/5.41.0)

### 🔄 Other Changes
* Bump fastlane-plugin-revenuecat_internal from `b35cae0` to `3f7fffc` (#754) via dependabot[bot] (@dependabot[bot])
* Bump fastlane-plugin-revenuecat_internal from `a8770fd` to `b35cae0` (#749) via dependabot[bot] (@dependabot[bot])
* Bump fastlane-plugin-revenuecat_internal from `e555afb` to `a8770fd` (#748) via dependabot[bot] (@dependabot[bot])
* Update fastlane-plugin-revenuecat_internal to e555afb (#744) via Cesar de la Vega (@vegaro)

## 7.1.4
> [!WARNING]  
> If you don't have any login system in your app, please make sure your one-time purchase products have been correctly configured in the RevenueCat dashboard as either consumable or non-consumable. If they're incorrectly configured as consumables, RevenueCat will consume these purchases. This means that users won't be able to restore them from version 7.0.0 onward.
> Non-consumables are products that are meant to be bought only once, for example, lifetime subscriptions.


## RevenueCat SDK
### 📦 Dependency Updates
* [AUTOMATIC BUMP] Updates purchases-hybrid-common to 17.8.0 (#736) via RevenueCat Git Bot (@RCGitBot)
  * [Android 9.7.2](https://github.com/RevenueCat/purchases-android/releases/tag/9.7.2)
  * [Android 9.7.1](https://github.com/RevenueCat/purchases-android/releases/tag/9.7.1)
  * [iOS 5.40.0](https://github.com/RevenueCat/purchases-ios/releases/tag/5.40.0)
  * [iOS 5.39.3](https://github.com/RevenueCat/purchases-ios/releases/tag/5.39.3)
  * [iOS 5.39.2](https://github.com/RevenueCat/purchases-ios/releases/tag/5.39.2)
  * [iOS 5.39.1](https://github.com/RevenueCat/purchases-ios/releases/tag/5.39.1)

### 🔄 Other Changes
* Add CODEOWNERS (#741) via Antonio Pallares (@ajpallares)
* Bump fastlane-plugin-revenuecat_internal from `1593f78` to `7508f17` (#742) via dependabot[bot] (@dependabot[bot])
* Bump fastlane-plugin-revenuecat_internal from `e1c0e04` to `1593f78` (#738) via dependabot[bot] (@dependabot[bot])
* Bump fastlane-plugin-revenuecat_internal from `6d539b3` to `e1c0e04` (#737) via dependabot[bot] (@dependabot[bot])
* Bump fastlane-plugin-revenuecat_internal from `a6dc551` to `6d539b3` (#735) via dependabot[bot] (@dependabot[bot])

## 7.1.3
> [!WARNING]  
> If you don't have any login system in your app, please make sure your one-time purchase products have been correctly configured in the RevenueCat dashboard as either consumable or non-consumable. If they're incorrectly configured as consumables, RevenueCat will consume these purchases. This means that users won't be able to restore them from version 7.0.0 onward.
> Non-consumables are products that are meant to be bought only once, for example, lifetime subscriptions.


## RevenueCat SDK
### 📦 Dependency Updates
* [AUTOMATIC BUMP] Updates purchases-hybrid-common to 17.7.0 (#732) via RevenueCat Git Bot (@RCGitBot)

## 7.1.2
> [!WARNING]  
> If you don't have any login system in your app, please make sure your one-time purchase products have been correctly configured in the RevenueCat dashboard as either consumable or non-consumable. If they're incorrectly configured as consumables, RevenueCat will consume these purchases. This means that users won't be able to restore them from version 7.0.0 onward.
> Non-consumables are products that are meant to be bought only once, for example, lifetime subscriptions.


## RevenueCat SDK
### 📦 Dependency Updates
* [AUTOMATIC BUMP] Updates purchases-hybrid-common to 17.6.0 (#724) via RevenueCat Git Bot (@RCGitBot)
  * [Android 9.6.0](https://github.com/RevenueCat/purchases-android/releases/tag/9.6.0)
  * [Android 9.5.0](https://github.com/RevenueCat/purchases-android/releases/tag/9.5.0)
  * [Android 9.4.0](https://github.com/RevenueCat/purchases-android/releases/tag/9.4.0)
  * [iOS 5.38.2](https://github.com/RevenueCat/purchases-ios/releases/tag/5.38.2)
  * [iOS 5.38.1](https://github.com/RevenueCat/purchases-ios/releases/tag/5.38.1)
  * [iOS 5.38.0](https://github.com/RevenueCat/purchases-ios/releases/tag/5.38.0)
  * [iOS 5.37.0](https://github.com/RevenueCat/purchases-ios/releases/tag/5.37.0)
  * [iOS 5.36.0](https://github.com/RevenueCat/purchases-ios/releases/tag/5.36.0)
* [AUTOMATIC BUMP] Updates purchases-hybrid-common to 17.5.1 (#723) via RevenueCat Git Bot (@RCGitBot)
  * [Android 9.6.0](https://github.com/RevenueCat/purchases-android/releases/tag/9.6.0)
  * [Android 9.5.0](https://github.com/RevenueCat/purchases-android/releases/tag/9.5.0)
  * [Android 9.4.0](https://github.com/RevenueCat/purchases-android/releases/tag/9.4.0)
  * [iOS 5.38.2](https://github.com/RevenueCat/purchases-ios/releases/tag/5.38.2)
  * [iOS 5.38.1](https://github.com/RevenueCat/purchases-ios/releases/tag/5.38.1)
  * [iOS 5.38.0](https://github.com/RevenueCat/purchases-ios/releases/tag/5.38.0)
  * [iOS 5.37.0](https://github.com/RevenueCat/purchases-ios/releases/tag/5.37.0)
  * [iOS 5.36.0](https://github.com/RevenueCat/purchases-ios/releases/tag/5.36.0)
* [AUTOMATIC BUMP] Updates purchases-hybrid-common to 17.5.0 (#722) via RevenueCat Git Bot (@RCGitBot)
  * [Android 9.6.0](https://github.com/RevenueCat/purchases-android/releases/tag/9.6.0)
  * [Android 9.5.0](https://github.com/RevenueCat/purchases-android/releases/tag/9.5.0)
  * [Android 9.4.0](https://github.com/RevenueCat/purchases-android/releases/tag/9.4.0)
  * [iOS 5.38.2](https://github.com/RevenueCat/purchases-ios/releases/tag/5.38.2)
  * [iOS 5.38.1](https://github.com/RevenueCat/purchases-ios/releases/tag/5.38.1)
  * [iOS 5.38.0](https://github.com/RevenueCat/purchases-ios/releases/tag/5.38.0)
  * [iOS 5.37.0](https://github.com/RevenueCat/purchases-ios/releases/tag/5.37.0)
  * [iOS 5.36.0](https://github.com/RevenueCat/purchases-ios/releases/tag/5.36.0)
* [AUTOMATIC BUMP] Updates purchases-hybrid-common to 17.2.0 (#716) via RevenueCat Git Bot (@RCGitBot)
  * [Android 9.6.0](https://github.com/RevenueCat/purchases-android/releases/tag/9.6.0)
  * [Android 9.5.0](https://github.com/RevenueCat/purchases-android/releases/tag/9.5.0)
  * [Android 9.4.0](https://github.com/RevenueCat/purchases-android/releases/tag/9.4.0)
  * [iOS 5.38.2](https://github.com/RevenueCat/purchases-ios/releases/tag/5.38.2)
  * [iOS 5.38.1](https://github.com/RevenueCat/purchases-ios/releases/tag/5.38.1)
  * [iOS 5.38.0](https://github.com/RevenueCat/purchases-ios/releases/tag/5.38.0)
  * [iOS 5.37.0](https://github.com/RevenueCat/purchases-ios/releases/tag/5.37.0)
  * [iOS 5.36.0](https://github.com/RevenueCat/purchases-ios/releases/tag/5.36.0)

### 🔄 Other Changes
* Update fastlane-plugin-revenuecat_internal revision (#730) via Cesar de la Vega (@vegaro)
* Fix make-release and tagging of branch (#728) via Cesar de la Vega (@vegaro)
* Set ruby version in automatic-bump (#726) via Cesar de la Vega (@vegaro)
* Update bundle dependencies (#725) via Cesar de la Vega (@vegaro)
* Change ruby version in `update-hybrid-common-versions` job (#720) via Toni Rico (@tonidero)
* Add warning with 7.x issues to all versions since 7.0.0 in CHANGELOG (#719) via Toni Rico (@tonidero)
* Bump ruby (#718) via Cesar de la Vega (@vegaro)

## 7.1.1
## RevenueCat SDK
> [!WARNING]
> If you don't have any login system in your app, please make sure your one-time purchase products have been correctly configured in the RevenueCat dashboard as either consumable or non-consumable. If they're incorrectly configured as consumables, RevenueCat will consume these purchases. This means that users won't be able to restore them from version 7.0.0 onward.
> Non-consumables are products that are meant to be bought only once, for example, lifetime subscriptions.

### 📦 Dependency Updates
* [AUTOMATIC BUMP] Updates purchases-hybrid-common to 17.0.0 (#713) via RevenueCat Git Bot (@RCGitBot)
  * [Android 9.3.2](https://github.com/RevenueCat/purchases-android/releases/tag/9.3.2)
  * [Android 9.3.1](https://github.com/RevenueCat/purchases-android/releases/tag/9.3.1)
  * [Android 9.3.0](https://github.com/RevenueCat/purchases-android/releases/tag/9.3.0)
  * [iOS 5.35.1](https://github.com/RevenueCat/purchases-ios/releases/tag/5.35.1)
  * [iOS 5.35.0](https://github.com/RevenueCat/purchases-ios/releases/tag/5.35.0)

## 7.1.0
## RevenueCat SDK
> [!WARNING]
> If you don't have any login system in your app, please make sure your one-time purchase products have been correctly configured in the RevenueCat dashboard as either consumable or non-consumable. If they're incorrectly configured as consumables, RevenueCat will consume these purchases. This means that users won't be able to restore them from version 7.0.0 onward.
> Non-consumables are products that are meant to be bought only once, for example, lifetime subscriptions.

### ✨ New Features
* Add VC Support (#705) via Will Taylor (@fire-at-will)

### 🔄 Other Changes
* Add Virtual Currency Unit Tests (#709) via Will Taylor (@fire-at-will)
* Fix Gemfile.lock (#707) via Toni Rico (@tonidero)

## 7.0.1
## RevenueCat SDK
> [!WARNING]
> If you don't have any login system in your app, please make sure your one-time purchase products have been correctly configured in the RevenueCat dashboard as either consumable or non-consumable. If they're incorrectly configured as consumables, RevenueCat will consume these purchases. This means that users won't be able to restore them from version 7.0.0 onward.
> Non-consumables are products that are meant to be bought only once, for example, lifetime subscriptions.

### 📦 Dependency Updates
* [AUTOMATIC BUMP] Updates purchases-hybrid-common to 16.2.0 (#704) via RevenueCat Git Bot (@RCGitBot)
  * [Android 9.2.0](https://github.com/RevenueCat/purchases-android/releases/tag/9.2.0)
  * [Android 9.1.2](https://github.com/RevenueCat/purchases-android/releases/tag/9.1.2)
  * [Android 9.1.1](https://github.com/RevenueCat/purchases-android/releases/tag/9.1.1)
  * [iOS 5.34.0](https://github.com/RevenueCat/purchases-ios/releases/tag/5.34.0)
  * [iOS 5.33.1](https://github.com/RevenueCat/purchases-ios/releases/tag/5.33.1)

### 🔄 Other Changes
* Bump fastlane from 2.227.2 to 2.228.0 (#673) via dependabot[bot] (@dependabot[bot])
* Add warning on CHANGELOG (#703) via Toni Rico (@tonidero)
* Improve 7.0.0 changelog (#701) via Toni Rico (@tonidero)
* Bump fastlane-plugin-revenuecat_internal from `05ef095` to `7d97553` (#680) via dependabot[bot] (@dependabot[bot])
* Bump nokogiri from 1.18.8 to 1.18.9 (#696) via dependabot[bot] (@dependabot[bot])

## 7.0.0
## RevenueCat SDK

> [!WARNING]
> If you don't have any login system in your app, please make sure your one-time purchase products have been correctly configured in the RevenueCat dashboard as either consumable or non-consumable. If they're incorrectly configured as consumables, RevenueCat will consume these purchases. This means that users won't be able to restore them from version 7.0.0 onward.
> Non-consumables are products that are meant to be bought only once, for example, lifetime subscriptions.

This release updates the SDK to use Google Play Billing Library 8. This version of the Billing Library removed APIs to query for expired subscriptions and consumed one-time products, aside from other improvements. You can check the full list of changes here: https://developer.android.com/google/play/billing/release-notes#8-0-0

Additionally, we've also updated Kotlin to 2.0.21 and our new minimum version is Kotlin 1.8.0+. If you were using an older version of Kotlin, you will need to update it.

#### Play Billing Library 8: No expired subscriptions or consumed one-time products
Play Billing Library 8 removed the ability to query for expired subscriptions and consumed one-time products. This means that the RevenueCat SDK will no longer be able to send purchase information from these purchases. There are 2 cases where this can have an impact:
- If you have consumed one time purchases in Google Play that need to be restored (for example, in order to grant a lifetime entitlement). In these cases, the SDK will not be able to find these purchases and will not be able to restore them and grant the entitlements. This can especially be a problem if you're using anonymous ids and don't have your own account system. Please make sure your products are correctly configured as non-consumables in the RevenueCat dashboard to avoid consuming them in the first place if you intend to make them behave as lifetime purchases.
- (Only relevant if you recently integrated RevenueCat before upgrading to v9, and do not (yet) have all your transactions imported). The SDK will not be able to send purchase information from these expired subscriptions and consumed one time purchases to our backend, so we might miss this data in our customer profile/targeting. We can still ingest historical data from these purchases through a backend historical import. See [docs](https://www.revenuecat.com/docs/migrating-to-revenuecat/migrating-existing-subscriptions). This case doesn't affect developers that have all transactions in RevenueCat, which is true for the vast majority.

#### Using the SDK with your own IAP code (previously Observer Mode)
Using the SDK with your own IAP code is still supported in v7. Other than updating the SDK version, there are no changes required. Just make sure the version of the Play Billing Library is also version 8.0.0+.

### 📦 Dependency Updates
* [AUTOMATIC BUMP] Updates purchases-hybrid-common to 15.0.0 (#693)
  * [Android 9.1.0](https://github.com/RevenueCat/purchases-android/releases/tag/9.1.0)
  * [Android 9.0.1](https://github.com/RevenueCat/purchases-android/releases/tag/9.0.1)
  * [Android 9.0.0](https://github.com/RevenueCat/purchases-android/releases/tag/9.0.0)
  * [iOS 5.33.0](https://github.com/RevenueCat/purchases-ios/releases/tag/5.33.0)

### 🔄 Other Changes
* Bump danger from 9.5.1 to 9.5.3 (#687) via dependabot[bot]
(@dependabot[bot]) via RevenueCat Git Bot

## 6.2.13
## RevenueCat SDK
### 📦 Dependency Updates
* [AUTOMATIC BUMP] Updates purchases-hybrid-common to 14.2.0 (#690) via RevenueCat Git Bot (@RCGitBot)
  * [Android 8.22.0](https://github.com/RevenueCat/purchases-android/releases/tag/8.22.0)
  * [Android 8.21.0](https://github.com/RevenueCat/purchases-android/releases/tag/8.21.0)
  * [iOS 5.32.0](https://github.com/RevenueCat/purchases-ios/releases/tag/5.32.0)
  * [iOS 5.31.0](https://github.com/RevenueCat/purchases-ios/releases/tag/5.31.0)
* [AUTOMATIC BUMP] Updates purchases-hybrid-common to 14.1.0 (#688) via RevenueCat Git Bot (@RCGitBot)
  * [Android 8.22.0](https://github.com/RevenueCat/purchases-android/releases/tag/8.22.0)
  * [Android 8.21.0](https://github.com/RevenueCat/purchases-android/releases/tag/8.21.0)
  * [iOS 5.32.0](https://github.com/RevenueCat/purchases-ios/releases/tag/5.32.0)
  * [iOS 5.31.0](https://github.com/RevenueCat/purchases-ios/releases/tag/5.31.0)

### 🔄 Other Changes
* Bump danger from 9.5.1 to 9.5.3 (#687) via dependabot[bot] (@dependabot[bot])

## 6.2.12
## RevenueCat SDK
### 📦 Dependency Updates
* [AUTOMATIC BUMP] Updates purchases-hybrid-common to 14.0.2 (#685) via RevenueCat Git Bot (@RCGitBot)
  * [iOS 5.30.0](https://github.com/RevenueCat/purchases-ios/releases/tag/5.30.0)

### 🔄 Other Changes
* Update workflows/issue-notifications.yml@v2 (#684) via Josh Holtz (@joshdholtz)
* Add GitHub Issue Action Ack (#683) via Josh Holtz (@joshdholtz)

## 6.2.11
## RevenueCat SDK
### 📦 Dependency Updates
* [AUTOMATIC BUMP] Updates purchases-hybrid-common to 13.38.1 (#681) via RevenueCat Git Bot (@RCGitBot)
  * [Android 8.20.0](https://github.com/RevenueCat/purchases-android/releases/tag/8.20.0)
  * [iOS 5.29.0](https://github.com/RevenueCat/purchases-ios/releases/tag/5.29.0)
* [AUTOMATIC BUMP] Updates purchases-hybrid-common to 13.37.0 (#677) via RevenueCat Git Bot (@RCGitBot)
  * [Android 8.20.0](https://github.com/RevenueCat/purchases-android/releases/tag/8.20.0)
  * [iOS 5.29.0](https://github.com/RevenueCat/purchases-ios/releases/tag/5.29.0)

## 6.2.10
## RevenueCat SDK
### 📦 Dependency Updates
* [AUTOMATIC BUMP] Updates purchases-hybrid-common to 13.36.0 (#674) via RevenueCat Git Bot (@RCGitBot)
  * [Android 8.19.2](https://github.com/RevenueCat/purchases-android/releases/tag/8.19.2)
  * [Android 8.19.1](https://github.com/RevenueCat/purchases-android/releases/tag/8.19.1)
  * [iOS 5.28.1](https://github.com/RevenueCat/purchases-ios/releases/tag/5.28.1)
  * [iOS 5.28.0](https://github.com/RevenueCat/purchases-ios/releases/tag/5.28.0)
  * [iOS 5.27.1](https://github.com/RevenueCat/purchases-ios/releases/tag/5.27.1)

## 6.2.9
## RevenueCat SDK
### 📦 Dependency Updates
* [AUTOMATIC BUMP] Updates purchases-hybrid-common to 13.33.0 (#669) via RevenueCat Git Bot (@RCGitBot)
  * [Android 8.19.0](https://github.com/RevenueCat/purchases-android/releases/tag/8.19.0)
  * [Android 8.18.0](https://github.com/RevenueCat/purchases-android/releases/tag/8.18.0)
  * [iOS 5.26.0](https://github.com/RevenueCat/purchases-ios/releases/tag/5.26.0)
  * [iOS 5.25.3](https://github.com/RevenueCat/purchases-ios/releases/tag/5.25.3)
  * [iOS 5.25.2](https://github.com/RevenueCat/purchases-ios/releases/tag/5.25.2)
  * [iOS 5.25.1](https://github.com/RevenueCat/purchases-ios/releases/tag/5.25.1)
  * [iOS 5.25.0](https://github.com/RevenueCat/purchases-ios/releases/tag/5.25.0)

### 🔄 Other Changes
* Bump fastlane from 2.227.0 to 2.227.2 (#663) via dependabot[bot] (@dependabot[bot])

## 6.2.8
## RevenueCat SDK
### 📦 Dependency Updates
* [AUTOMATIC BUMP] Updates purchases-hybrid-common to 13.32.0 (#667) via RevenueCat Git Bot (@RCGitBot)
  * [Android 8.17.1](https://github.com/RevenueCat/purchases-android/releases/tag/8.17.1)
  * [Android 8.17.0](https://github.com/RevenueCat/purchases-android/releases/tag/8.17.0)
  * [Android 8.16.1](https://github.com/RevenueCat/purchases-android/releases/tag/8.16.1)
  * [iOS 5.24.0](https://github.com/RevenueCat/purchases-ios/releases/tag/5.24.0)
  * [iOS 5.23.0](https://github.com/RevenueCat/purchases-ios/releases/tag/5.23.0)
  * [iOS 5.22.2](https://github.com/RevenueCat/purchases-ios/releases/tag/5.22.2)
  * [iOS 5.22.1](https://github.com/RevenueCat/purchases-ios/releases/tag/5.22.1)
  * [iOS 5.22.0](https://github.com/RevenueCat/purchases-ios/releases/tag/5.22.0)
  * [iOS 5.21.2](https://github.com/RevenueCat/purchases-ios/releases/tag/5.21.2)
  * [iOS 5.21.1](https://github.com/RevenueCat/purchases-ios/releases/tag/5.21.1)
* [AUTOMATIC BUMP] Updates purchases-hybrid-common to 13.29.1 (#661) via RevenueCat Git Bot (@RCGitBot)
  * [Android 8.17.1](https://github.com/RevenueCat/purchases-android/releases/tag/8.17.1)
  * [Android 8.17.0](https://github.com/RevenueCat/purchases-android/releases/tag/8.17.0)
  * [Android 8.16.1](https://github.com/RevenueCat/purchases-android/releases/tag/8.16.1)
  * [iOS 5.24.0](https://github.com/RevenueCat/purchases-ios/releases/tag/5.24.0)
  * [iOS 5.23.0](https://github.com/RevenueCat/purchases-ios/releases/tag/5.23.0)
  * [iOS 5.22.2](https://github.com/RevenueCat/purchases-ios/releases/tag/5.22.2)
  * [iOS 5.22.1](https://github.com/RevenueCat/purchases-ios/releases/tag/5.22.1)
  * [iOS 5.22.0](https://github.com/RevenueCat/purchases-ios/releases/tag/5.22.0)
  * [iOS 5.21.2](https://github.com/RevenueCat/purchases-ios/releases/tag/5.21.2)
  * [iOS 5.21.1](https://github.com/RevenueCat/purchases-ios/releases/tag/5.21.1)
* [AUTOMATIC BUMP] Updates purchases-hybrid-common to 13.28.1 (#656) via RevenueCat Git Bot (@RCGitBot)
  * [Android 8.17.1](https://github.com/RevenueCat/purchases-android/releases/tag/8.17.1)
  * [Android 8.17.0](https://github.com/RevenueCat/purchases-android/releases/tag/8.17.0)
  * [Android 8.16.1](https://github.com/RevenueCat/purchases-android/releases/tag/8.16.1)
  * [iOS 5.24.0](https://github.com/RevenueCat/purchases-ios/releases/tag/5.24.0)
  * [iOS 5.23.0](https://github.com/RevenueCat/purchases-ios/releases/tag/5.23.0)
  * [iOS 5.22.2](https://github.com/RevenueCat/purchases-ios/releases/tag/5.22.2)
  * [iOS 5.22.1](https://github.com/RevenueCat/purchases-ios/releases/tag/5.22.1)
  * [iOS 5.22.0](https://github.com/RevenueCat/purchases-ios/releases/tag/5.22.0)
  * [iOS 5.21.2](https://github.com/RevenueCat/purchases-ios/releases/tag/5.21.2)
  * [iOS 5.21.1](https://github.com/RevenueCat/purchases-ios/releases/tag/5.21.1)

### 🔄 Other Changes
* Bump nokogiri from 1.18.4 to 1.18.8 (#658) via dependabot[bot] (@dependabot[bot])

## 6.2.7
## RevenueCat SDK
### 📦 Dependency Updates
* [AUTOMATIC BUMP] Updates purchases-hybrid-common to 13.28.0 (#653) via RevenueCat Git Bot (@RCGitBot)
  * [Android 8.16.0](https://github.com/RevenueCat/purchases-android/releases/tag/8.16.0)
  * [Android 8.15.1](https://github.com/RevenueCat/purchases-android/releases/tag/8.15.1)
  * [Android 8.15.0](https://github.com/RevenueCat/purchases-android/releases/tag/8.15.0)
  * [Android 8.14.3](https://github.com/RevenueCat/purchases-android/releases/tag/8.14.3)
  * [Android 8.14.2](https://github.com/RevenueCat/purchases-android/releases/tag/8.14.2)
  * [iOS 5.21.0](https://github.com/RevenueCat/purchases-ios/releases/tag/5.21.0)
  * [iOS 5.20.3](https://github.com/RevenueCat/purchases-ios/releases/tag/5.20.3)
  * [iOS 5.20.2](https://github.com/RevenueCat/purchases-ios/releases/tag/5.20.2)
  * [iOS 5.20.1](https://github.com/RevenueCat/purchases-ios/releases/tag/5.20.1)
  * [iOS 5.20.0](https://github.com/RevenueCat/purchases-ios/releases/tag/5.20.0)
* [AUTOMATIC BUMP] Updates purchases-hybrid-common to 13.27.0 (#652) via RevenueCat Git Bot (@RCGitBot)
  * [Android 8.16.0](https://github.com/RevenueCat/purchases-android/releases/tag/8.16.0)
  * [Android 8.15.1](https://github.com/RevenueCat/purchases-android/releases/tag/8.15.1)
  * [Android 8.15.0](https://github.com/RevenueCat/purchases-android/releases/tag/8.15.0)
  * [Android 8.14.3](https://github.com/RevenueCat/purchases-android/releases/tag/8.14.3)
  * [Android 8.14.2](https://github.com/RevenueCat/purchases-android/releases/tag/8.14.2)
  * [iOS 5.21.0](https://github.com/RevenueCat/purchases-ios/releases/tag/5.21.0)
  * [iOS 5.20.3](https://github.com/RevenueCat/purchases-ios/releases/tag/5.20.3)
  * [iOS 5.20.2](https://github.com/RevenueCat/purchases-ios/releases/tag/5.20.2)
  * [iOS 5.20.1](https://github.com/RevenueCat/purchases-ios/releases/tag/5.20.1)
  * [iOS 5.20.0](https://github.com/RevenueCat/purchases-ios/releases/tag/5.20.0)
* [AUTOMATIC BUMP] Updates purchases-hybrid-common to 13.26.1 (#650) via RevenueCat Git Bot (@RCGitBot)
  * [Android 8.16.0](https://github.com/RevenueCat/purchases-android/releases/tag/8.16.0)
  * [Android 8.15.1](https://github.com/RevenueCat/purchases-android/releases/tag/8.15.1)
  * [Android 8.15.0](https://github.com/RevenueCat/purchases-android/releases/tag/8.15.0)
  * [Android 8.14.3](https://github.com/RevenueCat/purchases-android/releases/tag/8.14.3)
  * [Android 8.14.2](https://github.com/RevenueCat/purchases-android/releases/tag/8.14.2)
  * [iOS 5.21.0](https://github.com/RevenueCat/purchases-ios/releases/tag/5.21.0)
  * [iOS 5.20.3](https://github.com/RevenueCat/purchases-ios/releases/tag/5.20.3)
  * [iOS 5.20.2](https://github.com/RevenueCat/purchases-ios/releases/tag/5.20.2)
  * [iOS 5.20.1](https://github.com/RevenueCat/purchases-ios/releases/tag/5.20.1)
  * [iOS 5.20.0](https://github.com/RevenueCat/purchases-ios/releases/tag/5.20.0)

### 🔄 Other Changes
* Fix API tests (#651) via Toni Rico (@tonidero)
* Bump nokogiri from 1.18.3 to 1.18.4 (#649) via dependabot[bot] (@dependabot[bot])

## 6.2.6
## RevenueCat SDK
### 📦 Dependency Updates
* [AUTOMATIC BUMP] Updates purchases-hybrid-common to 13.25.0 (#642) via RevenueCat Git Bot (@RCGitBot)
  * [Android 8.14.1](https://github.com/RevenueCat/purchases-android/releases/tag/8.14.1)
  * [Android 8.14.0](https://github.com/RevenueCat/purchases-android/releases/tag/8.14.0)
* Bump nokogiri from 1.16.7 to 1.18.3 (#632) via dependabot[bot] (@dependabot[bot])

### 🔄 Other Changes
* Bump fastlane from 2.226.0 to 2.227.0 (#646) via dependabot[bot] (@dependabot[bot])
* Update fastlane plugin (#645) via Toni Rico (@tonidero)
* Add missing 6.2.2 changelog (#644) via Toni Rico (@tonidero)

## 6.2.5
## RevenueCat SDK
### 📦 Dependency Updates
* [AUTOMATIC BUMP] Updates purchases-hybrid-common to 13.24.0 (#641) via RevenueCat Git Bot (@RCGitBot)

## 6.2.4
## RevenueCat SDK
### 🐞 Bugfixes
* Document PREPAID periodType (#635) via Will Taylor (@fire-at-will)
### 📦 Dependency Updates
* Updates purchases-hybrid-common to 13.19.0 (#634) via RevenueCat Git Bot (@RCGitBot)

## 6.2.3
## RevenueCat SDK
### 📦 Dependency Updates
* [AUTOMATIC BUMP] Updates purchases-hybrid-common to 13.17.1 (#628) via RevenueCat Git Bot (@RCGitBot)

## 6.2.2
## RevenueCat SDK
### 📦 Dependency Updates
* [AUTOMATIC BUMP] Updates purchases-hybrid-common to 13.16.2 (#625) via RevenueCat Git Bot (@RCGitBot)

## 6.2.1
## RevenueCat SDK
### 📦 Dependency Updates
* Updates purchases-hybrid-common to 13.15.2 (#622) via RevenueCat Git Bot (@RCGitBot)

## 6.2.0
## RevenueCat SDK
### 📦 Dependency Updates
* Bump fastlane from 2.225.0 to 2.226.0 (#620) via dependabot[bot] (@dependabot[bot])
### Win-back Offers
#### ✨ New Features
* Support Fetching and Redeeming Win-Back Offers on Custom Paywall (#614) via Will Taylor (@fire-at-will)

## 6.1.4
## RevenueCat SDK
### 📦 Dependency Updates
* [AUTOMATIC BUMP] Updates purchases-hybrid-common to 13.13.0 (#615) via RevenueCat Git Bot (@RCGitBot)

## 6.1.3
## RevenueCat SDK
### 📦 Dependency Updates
* [AUTOMATIC BUMP] Updates purchases-hybrid-common to 13.12.0 (#611) via RevenueCat Git Bot (@RCGitBot)
* [AUTOMATIC BUMP] Updates purchases-hybrid-common to 13.11.0 (#609) via RevenueCat Git Bot (@RCGitBot)
* [AUTOMATIC BUMP] Updates purchases-hybrid-common to 13.10.0 (#608) via RevenueCat Git Bot (@RCGitBot)

## 6.1.2
## RevenueCat SDK
### 📦 Dependency Updates
* [AUTOMATIC BUMP] Updates purchases-hybrid-common to 13.9.0 (#606) via RevenueCat Git Bot (@RCGitBot)

## 6.1.1
## RevenueCat SDK
### 📦 Dependency Updates
* [AUTOMATIC BUMP] Updates purchases-hybrid-common to 13.8.0 (#604) via RevenueCat Git Bot (@RCGitBot)
* Bump xcodeproj from 1.25.1 to 1.27.0 (#603) via dependabot[bot] (@dependabot[bot])

## 6.1.0
## RevenueCat SDK
### 📦 Dependency Updates
* [AUTOMATIC BUMP] Updates purchases-hybrid-common to 13.7.0 (#601) via RevenueCat Git Bot (@RCGitBot)
* Bump fastlane from 2.224.0 to 2.225.0 (#596) via dependabot[bot] (@dependabot[bot])
* Bump danger from 9.5.0 to 9.5.1 (#597) via dependabot[bot] (@dependabot[bot])
* Bump fastlane from 2.223.1 to 2.224.0 (#591) via dependabot[bot] (@dependabot[bot])
* Bump xcodeproj from 1.25.0 to 1.25.1 (#590) via dependabot[bot] (@dependabot[bot])
* [AUTOMATIC BUMP] Updates purchases-hybrid-common to 13.5.0 (#592) via RevenueCat Git Bot (@RCGitBot)
* Bump fastlane from 2.222.0 to 2.223.1 (#587) via dependabot[bot] (@dependabot[bot])
### Win-back Offers
#### ✨ New Features
* Support displaying deferred win-back StoreKit messages (#600) via Will Taylor (@fire-at-will)

## 6.0.2
## RevenueCat SDK
### 📦 Dependency Updates
* [AUTOMATIC BUMP] Updates purchases-hybrid-common to 13.3.0 (#584) via RevenueCat Git Bot (@RCGitBot)

## 6.0.1
## RevenueCat SDK
### 📦 Dependency Updates
* [AUTOMATIC BUMP] Updates purchases-hybrid-common to 13.2.1 (#581) via RevenueCat Git Bot (@RCGitBot)
  * [Android 8.7.2](https://github.com/RevenueCat/purchases-android/releases/tag/8.7.2)
  * [Android 8.7.1](https://github.com/RevenueCat/purchases-android/releases/tag/8.7.1)
  * [Android 8.7.0](https://github.com/RevenueCat/purchases-android/releases/tag/8.7.0)
  * [Android 8.6.0](https://github.com/RevenueCat/purchases-android/releases/tag/8.6.0)
  * [Android 8.5.0](https://github.com/RevenueCat/purchases-android/releases/tag/8.5.0)
  * [iOS 5.3.3](https://github.com/RevenueCat/purchases-ios/releases/tag/5.3.3)
  * [iOS 5.3.2](https://github.com/RevenueCat/purchases-ios/releases/tag/5.3.2)
  * [iOS 5.3.1](https://github.com/RevenueCat/purchases-ios/releases/tag/5.3.1)
  * [iOS 5.3.0](https://github.com/RevenueCat/purchases-ios/releases/tag/5.3.0)
* Bump rexml from 3.3.4 to 3.3.6 (#575) via dependabot[bot] (@dependabot[bot])

### 🔄 Other Changes
* Bump fastlane-plugin-revenuecat_internal from 5140dbc to 55a0455 (#582) via Cesar de la Vega (@vegaro)
* Update fastlane-plugin-revenuecat_internal (#579) via Cesar de la Vega (@vegaro)
* Update SDK expiration date (#572) via Toni Rico (@tonidero)

## 6.0.0
This release updates the Android SDK dependency from v7 to [v8](https://github.com/RevenueCat/purchases-android/releases/tag/6.0.0) to use BillingClient 7 and updates the iOS SDK dependency from v4 to v5 to use StoreKit 2 by default in the SDK.

### Migration Guides

- See [Android Native - V8 API Migration Guide](https://github.com/RevenueCat/purchases-android/blob/main/migrations/v8-MIGRATION.md) for a more thorough explanation of the Android changes.
- See [iOS Native - V5 Migration Guide](https://github.com/RevenueCat/purchases-ios/blob/main/Sources/DocCDocumentation/DocCDocumentation.docc/V5_API_Migration_guide.md) for a more thorough explanation of the iOS changes. Notably, this version uses StoreKit 2 to process purchases by default.

### New Minimum OS Versions

This release raises the minumum required OS versions to the following:

- iOS 13.0
- tvOS 13.0
- watchOS 6.2
- macOS 10.15
- Android: SDK 21 (Android 5.0)

### In-App Purchase Key Required for StoreKit 2

In order to use StoreKit 2, you must configure your In-App Purchase Key in the RevenueCat dashboard. You can find instructions describing how to do this [here](https://www.revenuecat.com/docs/in-app-purchase-key-configuration).

### `usesStoreKit2IfAvailable` is now `storeKitVersion`

When configuring the SDK, the `usesStoreKit2IfAvailable` parameter has been replaced by an optional `storeKitVersion: STOREKIT_VERSION` parameter. It defaults to letting the iOS SDK determine the most appropriate version of StoreKit at runtime. If you'd like to use a specific version of StoreKit, you may provide a value for `storeKitVersion` like so:

```typescript
Purchases.configureWith({
    apiKey,
    storeKitVersion: STOREKIT_VERSION.STOREKIT_1,
});
```

### Observer Mode is now PurchasesAreCompletedBy

Version 6.0 of the SDK deprecates the term "Observer Mode" (and the APIs where this term was used), and replaces it with `PurchasesAreCompletedBy` (either RevenueCat or your app). When specifying that your app will complete purchases, you must provide the StoreKit version that your app is using to make purchases on iOS. If your app is only available on Android, you may provide any value since the native Android SDK ignores this value.

You can enable it when configuring the SDK:

```typescript
Purchases.configure({
    apiKey,
    purchasesAreCompletedBy: {a
	type: PURCHASES_ARE_COMPLETED_BY_TYPE.MY_APP,
        storeKitVersion: STOREKIT_VERSION.STOREKIT_2,
    },
});
```

#### ⚠️ Observing Purchases Completed by Your App on macOS

By default, when purchases are completed by your app using StoreKit 2 on macOS, the SDK does not detect a user's purchase until after the user foregrounds the app after the purchase has been made. If you'd like RevenueCat to immediately detect the user's purchase, call `Purchases.recordPurchase(productID)` for any new purchases, like so:

```typescript
Purchases.recordPurchase(productID, (transaction: PurchasesStoreTransaction) => {}, (error: PurchasesError) => {});
```

#### Observing Purchases Completed by Your App with StoreKit 1

If purchases are completed by your app using StoreKit 1, you will need to explicitly configure the SDK to use StoreKit 1:

```typescript
Purchases.configure({
    apiKey,
    purchasesAreCompletedBy: {a
        type: PURCHASES_ARE_COMPLETED_BY_TYPE.MY_APP,
        storeKitVersion: STOREKIT_VERSION.STOREKIT_1,
    },
});
```

### Dependency Updates
* Bump xcodeproj from 1.24.0 to 1.25.0 (#566) via dependabot[bot] (@dependabot[bot])
* Bump danger from 9.4.3 to 9.5.0 (#563) via dependabot[bot] (@dependabot[bot])
* Bump fastlane from 2.221.1 to 2.222.0 (#558) via dependabot[bot] (@dependabot[bot])
* Bump fastlane from 2.221.0 to 2.221.1 (#548) via dependabot[bot] (@dependabot[bot])
* Bump fastlane from 2.220.0 to 2.221.0 (#546) via dependabot[bot] (@dependabot[bot])
### Other Changes
* Fix ios integration tests (#570) via Toni Rico (@tonidero)
* Add deprecation note in README (#564) via Toni Rico (@tonidero)
* Update android executor (#549) via Toni Rico (@tonidero)

Full migration guide to V6: [Cordova Plugin purchases - V6 API Migration Guide](migrations/v6-MIGRATION.md)

## 5.7.8
### Dependency Updates
* [AUTOMATIC BUMP] Updates purchases-hybrid-common to 10.9.0 (#543) via RevenueCat Git Bot (@RCGitBot)
  * [Android 7.11.1](https://github.com/RevenueCat/purchases-android/releases/tag/7.11.1)
  * [iOS 4.43.0](https://github.com/RevenueCat/purchases-ios/releases/tag/4.43.0)
### Other Changes
* Update RELEASING.md (#511) via Cesar de la Vega (@vegaro)
* Fix cordova ios integration tests (#542) via Toni Rico (@tonidero)

## 5.7.7
### Dependency Updates
* [AUTOMATIC BUMP] Updates purchases-hybrid-common to 10.8.0 (#540) via RevenueCat Git Bot (@RCGitBot)
  * [Android 7.11.0](https://github.com/RevenueCat/purchases-android/releases/tag/7.11.0)
  * [Android 7.10.1](https://github.com/RevenueCat/purchases-android/releases/tag/7.10.1)
  * [Android 7.10.0](https://github.com/RevenueCat/purchases-android/releases/tag/7.10.0)
  * [Android 7.9.0](https://github.com/RevenueCat/purchases-android/releases/tag/7.9.0)
  * [iOS 4.42.0](https://github.com/RevenueCat/purchases-ios/releases/tag/4.42.0)
  * [iOS 4.41.2](https://github.com/RevenueCat/purchases-ios/releases/tag/4.41.2)
  * [iOS 4.41.1](https://github.com/RevenueCat/purchases-ios/releases/tag/4.41.1)
  * [iOS 4.41.0](https://github.com/RevenueCat/purchases-ios/releases/tag/4.41.0)
* Bump rexml from 3.2.6 to 3.2.8 (#538) via dependabot[bot] (@dependabot[bot])
### Other Changes
* Update fastlane plugin (#535) via Toni Rico (@tonidero)
* Only update docs index on latest stable releases (#525) via Toni Rico (@tonidero)

## 5.7.6
### Dependency Updates
* [AUTOMATIC BUMP] Updates purchases-hybrid-common to 10.4.1 (#524) via RevenueCat Git Bot (@RCGitBot)
  * [Android 7.8.2](https://github.com/RevenueCat/purchases-android/releases/tag/7.8.2)
  * [iOS 4.40.1](https://github.com/RevenueCat/purchases-ios/releases/tag/4.40.1)

## 5.7.5
### Dependency Updates
* Bump fastlane from 2.219.0 to 2.220.0 (#521) via dependabot[bot] (@dependabot[bot])
* [AUTOMATIC BUMP] Updates purchases-hybrid-common to 10.4.0 (#522) via RevenueCat Git Bot (@RCGitBot)
  * [iOS 4.40.0](https://github.com/RevenueCat/purchases-ios/releases/tag/4.40.0)

## 5.7.4
### Dependency Updates
* [AUTOMATIC BUMP] Updates purchases-hybrid-common to 10.3.2 (#519) via RevenueCat Git Bot (@RCGitBot)
  * [Android 7.8.1](https://github.com/RevenueCat/purchases-android/releases/tag/7.8.1)
  * [Android 7.8.0](https://github.com/RevenueCat/purchases-android/releases/tag/7.8.0)
  * [Android 7.7.3](https://github.com/RevenueCat/purchases-android/releases/tag/7.7.3)
  * [Android 7.7.2](https://github.com/RevenueCat/purchases-android/releases/tag/7.7.2)
  * [iOS 4.39.1](https://github.com/RevenueCat/purchases-ios/releases/tag/4.39.1)
  * [iOS 4.39.0](https://github.com/RevenueCat/purchases-ios/releases/tag/4.39.0)
  * [iOS 4.38.1](https://github.com/RevenueCat/purchases-ios/releases/tag/4.38.1)
  * [iOS 4.38.0](https://github.com/RevenueCat/purchases-ios/releases/tag/4.38.0)
* [AUTOMATIC BUMP] Updates purchases-hybrid-common to 10.2.0 (#514) via RevenueCat Git Bot (@RCGitBot)
  * [Android 7.8.1](https://github.com/RevenueCat/purchases-android/releases/tag/7.8.1)
  * [Android 7.8.0](https://github.com/RevenueCat/purchases-android/releases/tag/7.8.0)
  * [Android 7.7.3](https://github.com/RevenueCat/purchases-android/releases/tag/7.7.3)
  * [Android 7.7.2](https://github.com/RevenueCat/purchases-android/releases/tag/7.7.2)
  * [iOS 4.39.1](https://github.com/RevenueCat/purchases-ios/releases/tag/4.39.1)
  * [iOS 4.39.0](https://github.com/RevenueCat/purchases-ios/releases/tag/4.39.0)
  * [iOS 4.38.1](https://github.com/RevenueCat/purchases-ios/releases/tag/4.38.1)
  * [iOS 4.38.0](https://github.com/RevenueCat/purchases-ios/releases/tag/4.38.0)
### Other Changes
* Add 4.9.1 to changelog (#510) via Cesar de la Vega (@vegaro)

## 5.7.3
### Dependency Updates
* [AUTOMATIC BUMP] Updates purchases-hybrid-common to 9.9.0 (#505) via RevenueCat Git Bot (@RCGitBot)
  * [Android 7.7.1](https://github.com/RevenueCat/purchases-android/releases/tag/7.7.1)
  * [Android 7.7.0](https://github.com/RevenueCat/purchases-android/releases/tag/7.7.0)
  * [Android 7.6.0](https://github.com/RevenueCat/purchases-android/releases/tag/7.6.0)
  * [Android 7.5.2](https://github.com/RevenueCat/purchases-android/releases/tag/7.5.2)
  * [iOS 4.37.0](https://github.com/RevenueCat/purchases-ios/releases/tag/4.37.0)
  * [iOS 4.36.3](https://github.com/RevenueCat/purchases-ios/releases/tag/4.36.3)
  * [iOS 4.36.2](https://github.com/RevenueCat/purchases-ios/releases/tag/4.36.2)
* [AUTOMATIC BUMP] Updates purchases-hybrid-common to 9.8.0 (#503) via RevenueCat Git Bot (@RCGitBot)
  * [Android 7.7.1](https://github.com/RevenueCat/purchases-android/releases/tag/7.7.1)
  * [Android 7.7.0](https://github.com/RevenueCat/purchases-android/releases/tag/7.7.0)
  * [Android 7.6.0](https://github.com/RevenueCat/purchases-android/releases/tag/7.6.0)
  * [Android 7.5.2](https://github.com/RevenueCat/purchases-android/releases/tag/7.5.2)
  * [iOS 4.37.0](https://github.com/RevenueCat/purchases-ios/releases/tag/4.37.0)
  * [iOS 4.36.3](https://github.com/RevenueCat/purchases-ios/releases/tag/4.36.3)
  * [iOS 4.36.2](https://github.com/RevenueCat/purchases-ios/releases/tag/4.36.2)

## 5.7.2
### Dependency Updates
* [AUTOMATIC BUMP] Updates purchases-hybrid-common to 9.7.0 (#499) via RevenueCat Git Bot (@RCGitBot)
  * [Android 7.5.1](https://github.com/RevenueCat/purchases-android/releases/tag/7.5.1)
  * [iOS 4.36.1](https://github.com/RevenueCat/purchases-ios/releases/tag/4.36.1)
  * [iOS 4.36.0](https://github.com/RevenueCat/purchases-ios/releases/tag/4.36.0)

## 5.7.1
### Dependency Updates
* [AUTOMATIC BUMP] Updates purchases-hybrid-common to 9.6.0 (#497) via RevenueCat Git Bot (@RCGitBot)
  * [Android 7.5.0](https://github.com/RevenueCat/purchases-android/releases/tag/7.5.0)
  * [iOS 4.35.0](https://github.com/RevenueCat/purchases-ios/releases/tag/4.35.0)
  * [iOS 4.34.0](https://github.com/RevenueCat/purchases-ios/releases/tag/4.34.0)
* [AUTOMATIC BUMP] Updates purchases-hybrid-common to 9.5.0 (#496) via RevenueCat Git Bot (@RCGitBot)
  * [Android 7.5.0](https://github.com/RevenueCat/purchases-android/releases/tag/7.5.0)
  * [iOS 4.35.0](https://github.com/RevenueCat/purchases-ios/releases/tag/4.35.0)
  * [iOS 4.34.0](https://github.com/RevenueCat/purchases-ios/releases/tag/4.34.0)
* Bump danger from 9.4.2 to 9.4.3 (#494) via dependabot[bot] (@dependabot[bot])

## 5.7.0
### Dependency Updates
* [AUTOMATIC BUMP] Updates purchases-hybrid-common to 9.3.0 (#490) via RevenueCat Git Bot (@RCGitBot)
  * [Android 7.4.1](https://github.com/RevenueCat/purchases-android/releases/tag/7.4.1)
  * [Android 7.4.0](https://github.com/RevenueCat/purchases-android/releases/tag/7.4.0)
  * [Android 7.3.6](https://github.com/RevenueCat/purchases-android/releases/tag/7.3.6)
  * [Android 7.3.5](https://github.com/RevenueCat/purchases-android/releases/tag/7.3.5)
  * [Android 7.3.4](https://github.com/RevenueCat/purchases-android/releases/tag/7.3.4)
  * [Android 7.3.3](https://github.com/RevenueCat/purchases-android/releases/tag/7.3.3)
  * [iOS 4.33.0](https://github.com/RevenueCat/purchases-ios/releases/tag/4.33.0)
  * [iOS 4.32.4](https://github.com/RevenueCat/purchases-ios/releases/tag/4.32.4)
  * [iOS 4.32.3](https://github.com/RevenueCat/purchases-ios/releases/tag/4.32.3)
  * [iOS 4.32.2](https://github.com/RevenueCat/purchases-ios/releases/tag/4.32.2)
  * [iOS 4.32.1](https://github.com/RevenueCat/purchases-ios/releases/tag/4.32.1)
  * [iOS 4.32.0](https://github.com/RevenueCat/purchases-ios/releases/tag/4.32.0)
  * [iOS 4.31.9](https://github.com/RevenueCat/purchases-ios/releases/tag/4.31.9)
  * [iOS 4.31.8](https://github.com/RevenueCat/purchases-ios/releases/tag/4.31.8)
* [AUTOMATIC BUMP] Updates purchases-hybrid-common to 9.2.1 (#489) via RevenueCat Git Bot (@RCGitBot)
* Bump xcodeproj from 1.23.0 to 1.24.0 (#488) via dependabot[bot] (@dependabot[bot])
* [AUTOMATIC BUMP] Updates purchases-hybrid-common to 9.2.0 (#487) via RevenueCat Git Bot (@RCGitBot)
* [AUTOMATIC BUMP] Updates purchases-hybrid-common to 9.1.0 (#486) via RevenueCat Git Bot (@RCGitBot)
* [AUTOMATIC BUMP] Updates purchases-hybrid-common to 9.0.1 (#485) via RevenueCat Git Bot (@RCGitBot)
* [AUTOMATIC BUMP] Updates purchases-hybrid-common to 9.0.0 (#484) via RevenueCat Git Bot (@RCGitBot)
* [AUTOMATIC BUMP] Updates purchases-hybrid-common to 8.12.0 (#483) via RevenueCat Git Bot (@RCGitBot)
### Other Changes
* Update `fastlane-plugin-revenuecat_internal` (#491) via NachoSoto (@NachoSoto)

## 5.6.1
### Dependency Updates
* [AUTOMATIC BUMP] Updates purchases-hybrid-common to 8.2.2 (#480) via RevenueCat Git Bot (@RCGitBot)
  * [Android 7.3.2](https://github.com/RevenueCat/purchases-android/releases/tag/7.3.2)
  * [iOS 4.31.7](https://github.com/RevenueCat/purchases-ios/releases/tag/4.31.7)
* Bump fastlane from 2.218.0 to 2.219.0 (#478) via dependabot[bot] (@dependabot[bot])
* Bump fastlane from 2.217.0 to 2.218.0 (#476) via dependabot[bot] (@dependabot[bot])

## 5.6.0
### Dependency Updates
* [AUTOMATIC BUMP] Updates purchases-hybrid-common to 8.2.1 (#473) via RevenueCat Git Bot (@RCGitBot)
  * [Android 7.3.1](https://github.com/RevenueCat/purchases-android/releases/tag/7.3.1)
  * [Android 7.3.0](https://github.com/RevenueCat/purchases-android/releases/tag/7.3.0)
  * [Android 7.2.9](https://github.com/RevenueCat/purchases-android/releases/tag/7.2.9)
  * [Android 7.2.8](https://github.com/RevenueCat/purchases-android/releases/tag/7.2.8)
  * [iOS 4.31.6](https://github.com/RevenueCat/purchases-ios/releases/tag/4.31.6)
  * [iOS 4.31.5](https://github.com/RevenueCat/purchases-ios/releases/tag/4.31.5)
  * [iOS 4.31.4](https://github.com/RevenueCat/purchases-ios/releases/tag/4.31.4)
  * [iOS 4.31.3](https://github.com/RevenueCat/purchases-ios/releases/tag/4.31.3)
* Bump danger from 9.4.0 to 9.4.2 (#468) via dependabot[bot] (@dependabot[bot])

## 5.5.1
### Dependency Updates
* [AUTOMATIC BUMP] Updates purchases-hybrid-common to 8.1.1 (#465) via RevenueCat Git Bot (@RCGitBot)
  * [Android 7.2.7](https://github.com/RevenueCat/purchases-android/releases/tag/7.2.7)
  * [iOS 4.31.2](https://github.com/RevenueCat/purchases-ios/releases/tag/4.31.2)

## 5.5.0
### Dependency Updates
* [AUTOMATIC BUMP] Updates purchases-hybrid-common to 8.1.0 (#463) via RevenueCat Git Bot (@RCGitBot)
  * [Android 7.2.6](https://github.com/RevenueCat/purchases-android/releases/tag/7.2.6)
  * [Android 7.2.5](https://github.com/RevenueCat/purchases-android/releases/tag/7.2.5)
  * [iOS 4.31.1](https://github.com/RevenueCat/purchases-ios/releases/tag/4.31.1)
  * [iOS 4.31.0](https://github.com/RevenueCat/purchases-ios/releases/tag/4.31.0)

## 5.4.1
### Other Changes
* Fix some docs (#460) via Cesar de la Vega (@vegaro)

## 5.4.0
### Dependency Updates
* [AUTOMATIC BUMP] Updates purchases-hybrid-common to 8.0.0 (#456) via RevenueCat Git Bot (@RCGitBot)
  * [Android 7.2.4](https://github.com/RevenueCat/purchases-android/releases/tag/7.2.4)
* [AUTOMATIC BUMP] Updates purchases-hybrid-common to 7.4.0 (#455) via RevenueCat Git Bot (@RCGitBot)
  * [Android 7.2.4](https://github.com/RevenueCat/purchases-android/releases/tag/7.2.4)
### Other Changes
* `CI`: disable `prepare-next-version` (#454) via NachoSoto (@NachoSoto)

## 5.3.1
### Dependency Updates
* [AUTOMATIC BUMP] Updates purchases-hybrid-common to 7.3.3 (#449) via RevenueCat Git Bot (@RCGitBot)
  * [Android 7.2.3](https://github.com/RevenueCat/purchases-android/releases/tag/7.2.3)
  * [Android 7.2.2](https://github.com/RevenueCat/purchases-android/releases/tag/7.2.2)
  * [Android 7.2.1](https://github.com/RevenueCat/purchases-android/releases/tag/7.2.1)
  * [iOS 4.30.5](https://github.com/RevenueCat/purchases-ios/releases/tag/4.30.5)
  * [iOS 4.30.4](https://github.com/RevenueCat/purchases-ios/releases/tag/4.30.4)
  * [iOS 4.30.3](https://github.com/RevenueCat/purchases-ios/releases/tag/4.30.3)
* Bump fastlane from 2.216.0 to 2.217.0 (#451) via dependabot[bot] (@dependabot[bot])
* Bump danger from 9.3.2 to 9.4.0 (#450) via dependabot[bot] (@dependabot[bot])
* [AUTOMATIC BUMP] Updates purchases-hybrid-common to 7.3.2 (#448) via RevenueCat Git Bot (@RCGitBot)
* [AUTOMATIC BUMP] Updates purchases-hybrid-common to 7.3.1 (#443) via RevenueCat Git Bot (@RCGitBot)
### Other Changes
* Add `2.4.3` to `VERSIONS` (#447) via NachoSoto (@NachoSoto)

## 5.3.0
### Dependency Updates
* [AUTOMATIC BUMP] Updates purchases-hybrid-common to 7.3.0 (#441) via RevenueCat Git Bot (@RCGitBot)
  * [Android 7.2.0](https://github.com/RevenueCat/purchases-android/releases/tag/7.2.0)
  * [Android 7.1.1](https://github.com/RevenueCat/purchases-android/releases/tag/7.1.1)
  * [Android 7.1.0](https://github.com/RevenueCat/purchases-android/releases/tag/7.1.0)
  * [Android 7.1.0-beta.2](https://github.com/RevenueCat/purchases-android/releases/tag/7.1.0-beta.2)
  * [Android 7.1.0-beta.1](https://github.com/RevenueCat/purchases-android/releases/tag/7.1.0-beta.1)
  * [iOS 4.30.2](https://github.com/RevenueCat/purchases-ios/releases/tag/4.30.2)
  * [iOS 4.30.1](https://github.com/RevenueCat/purchases-ios/releases/tag/4.30.1)
  * [iOS 4.30.0](https://github.com/RevenueCat/purchases-ios/releases/tag/4.30.0)

## 5.2.0
### Dependency Updates
* [AUTOMATIC BUMP] Updates purchases-hybrid-common to 7.2.0 (#438) via RevenueCat Git Bot (@RCGitBot)
  * [iOS 4.29.0](https://github.com/RevenueCat/purchases-ios/releases/tag/4.29.0)
  * [iOS 4.28.1](https://github.com/RevenueCat/purchases-ios/releases/tag/4.28.1)
* [AUTOMATIC BUMP] Updates purchases-hybrid-common to 7.1.1 (#437) via RevenueCat Git Bot (@RCGitBot)
  * [iOS 4.29.0](https://github.com/RevenueCat/purchases-ios/releases/tag/4.29.0)
  * [iOS 4.28.1](https://github.com/RevenueCat/purchases-ios/releases/tag/4.28.1)
* Bump xcodeproj from 1.22.0 to 1.23.0 (#424) via dependabot[bot] (@dependabot[bot])

## 5.1.0
### Dependency Updates
* [AUTOMATIC BUMP] Updates purchases-hybrid-common to 7.1.0 (#433) via RevenueCat Git Bot (@RCGitBot)
  * [Android 7.0.1](https://github.com/RevenueCat/purchases-android/releases/tag/7.0.1)
  * [iOS 4.28.0](https://github.com/RevenueCat/purchases-ios/releases/tag/4.28.0)
  * [iOS 4.27.2](https://github.com/RevenueCat/purchases-ios/releases/tag/4.27.2)
  * [iOS 4.27.1](https://github.com/RevenueCat/purchases-ios/releases/tag/4.27.1)

## 5.0.0
**RevenueCat Cordova SDK v5** is here!! 😻

This latest release updates the SDK to use BillingClient 6 in Android. This version of BillingClient brings little change compared with BillingClient 5 which brought an entire new subscription model which resulted in large changes across the entire SDK.

The only modification at the API level involves replacing "ProrationMode" with "ReplacementMode". The specific replacement modes remain unchanged.

If your app doesn't currently use DEFERRED replacement modes, then you should be safe to upgrade to this version without changes in behavior.

If your app supports product changes using [DEFERRED replacement mode](https://www.revenuecat.com/docs/managing-subscriptions#google-play), then you can either stick with the previous major version until support for DEFERRED is re-introduced in this major version, or you can remove DEFERRED replacement options from your app.

If you are using the SDK in observer mode, you should only use v5 in Android if you're using BillingClient 6.

See the [Android Native - 6.x to 7.x Migration](https://github.com/RevenueCat/purchases-android/blob/main/migrations/v7-MIGRATION.md) for more details.

If you come from an older version of the RevenueCat SDK, see [Android Native - 5.x to 6.x Migration](https://www.revenuecat.com/docs/android-native-5x-to-6x-migration) for a more thorough explanation of the new Google subscription model announced with BillingClient 5 and how to take advantage of it.

### Bumped minimum Android SDK version

RevenueCat SDK v5 bumps minimum Android SDK version from Android 4.0 (API level 16) to Android 4.4 (API level 19).

### Support for InApp Messages

We've added new APIs to support InApp messages both in Android and iOS. You can read more about:
* [Google Play InApp Messages](https://rev.cat/googleplayinappmessaging) which will show users a snackbar message during grace period and account hold once per day and provide them an opportunity to fix their payment without leaving the app.
* [App Store InApp messages](https://rev.cat/storekit-message) which will show a modal during grace period once per subscription.

InApp Messages are shown by default in both platforms. If you want to disable this behaviour during configuration of the RevenueCat SDK, setup the `shouldShowInAppMessagesAutomatically` property during configuration to `false`:

```typescript
  Purchases.configureWith({
    apiKey,
    appUserID,
    observerMode,
    userDefaultsSuiteName,
    useAmazon,
    shouldShowInAppMessagesAutomatically
  });
```

### Dependency Updates
* [AUTOMATIC BUMP] Updates purchases-hybrid-common to 7.0.0 (#429) via RevenueCat Git Bot (@RCGitBot)
  * [Android 7.0.0](https://github.com/RevenueCat/purchases-android/releases/tag/7.0.0)
  * [iOS 4.27.0](https://github.com/RevenueCat/purchases-ios/releases/tag/4.27.0)
  * [iOS 4.26.2](https://github.com/RevenueCat/purchases-ios/releases/tag/4.26.2)

## 4.9.1
### Dependency Updates
* [AUTOMATIC BUMP] Updates purchases-hybrid-common to 6.3.2 (#933) via RevenueCat Git Bot (@RCGitBot)
  * [Android 6.9.7](https://github.com/RevenueCat/purchases-android/releases/tag/6.9.7)

## 4.9.0
### Dependency Updates
* [AUTOMATIC BUMP] Updates purchases-hybrid-common to 6.3.0 (#426) via RevenueCat Git Bot (@RCGitBot)
  * [Android 6.9.5](https://github.com/RevenueCat/purchases-android/releases/tag/6.9.5)
  * [iOS 4.26.1](https://github.com/RevenueCat/purchases-ios/releases/tag/4.26.1)

## 4.8.0
### Dependency Updates
* Bump fastlane from 2.214.0 to 2.216.0 (#421) via dependabot[bot] (@dependabot[bot])
* Bump danger from 9.3.1 to 9.3.2 (#420) via dependabot[bot] (@dependabot[bot])
* [AUTOMATIC BUMP] Updates purchases-hybrid-common to 6.2.0 (#419) via RevenueCat Git Bot (@RCGitBot)
  * [iOS 4.26.0](https://github.com/RevenueCat/purchases-ios/releases/tag/4.26.0)
  * [iOS 4.25.10](https://github.com/RevenueCat/purchases-ios/releases/tag/4.25.10)
  * [iOS 4.26.0-beta.4](https://github.com/RevenueCat/purchases-ios/releases/tag/4.26.0-beta.4)
  * [iOS 4.26.0-beta.3](https://github.com/RevenueCat/purchases-ios/releases/tag/4.26.0-beta.3)
  * [iOS 4.26.0-beta.2](https://github.com/RevenueCat/purchases-ios/releases/tag/4.26.0-beta.2)
  * [iOS 4.26.0-beta.1](https://github.com/RevenueCat/purchases-ios/releases/tag/4.26.0-beta.1)

## 4.7.1
### Dependency Updates
* [AUTOMATIC BUMP] Updates purchases-hybrid-common to 6.1.2 (#414) via RevenueCat Git Bot (@RCGitBot)
  * [Android 6.9.4](https://github.com/RevenueCat/purchases-android/releases/tag/6.9.4)
  * [iOS 4.25.9](https://github.com/RevenueCat/purchases-ios/releases/tag/4.25.9)
  * [iOS 4.25.8](https://github.com/RevenueCat/purchases-ios/releases/tag/4.25.8)

## 4.7.0
### Dependency Updates
* [AUTOMATIC BUMP] Updates purchases-hybrid-common to 6.1.0 (#410) via RevenueCat Git Bot (@RCGitBot)
  * [Android 6.9.3](https://github.com/RevenueCat/purchases-android/releases/tag/6.9.3)
  * [iOS 4.25.7](https://github.com/RevenueCat/purchases-ios/releases/tag/4.25.7)
* [AUTOMATIC BUMP] Updates purchases-hybrid-common to 6.0.0 (#408) via RevenueCat Git Bot (@RCGitBot)
  * [Android 6.9.3](https://github.com/RevenueCat/purchases-android/releases/tag/6.9.3)
  * [iOS 4.25.7](https://github.com/RevenueCat/purchases-ios/releases/tag/4.25.7)
* [AUTOMATIC BUMP] Updates purchases-hybrid-common to 5.6.4 (#407) via RevenueCat Git Bot (@RCGitBot)
  * [Android 6.9.3](https://github.com/RevenueCat/purchases-android/releases/tag/6.9.3)
  * [iOS 4.25.7](https://github.com/RevenueCat/purchases-ios/releases/tag/4.25.7)

## 4.6.1
### Dependency Updates
* [AUTOMATIC BUMP] Updates purchases-hybrid-common to 5.6.3 (#404) via RevenueCat Git Bot (@RCGitBot)
  * [Android 6.9.2](https://github.com/RevenueCat/purchases-android/releases/tag/6.9.2)
  * [Android 6.9.1](https://github.com/RevenueCat/purchases-android/releases/tag/6.9.1)
  * [iOS 4.25.6](https://github.com/RevenueCat/purchases-ios/releases/tag/4.25.6)
  * [iOS 4.25.5](https://github.com/RevenueCat/purchases-ios/releases/tag/4.25.5)
  * [iOS 4.25.4](https://github.com/RevenueCat/purchases-ios/releases/tag/4.25.4)
  * [iOS 4.25.3](https://github.com/RevenueCat/purchases-ios/releases/tag/4.25.3)
* [AUTOMATIC BUMP] Updates purchases-hybrid-common to 5.6.2 (#403) via RevenueCat Git Bot (@RCGitBot)
  * [Android 6.9.2](https://github.com/RevenueCat/purchases-android/releases/tag/6.9.2)
  * [Android 6.9.1](https://github.com/RevenueCat/purchases-android/releases/tag/6.9.1)
  * [iOS 4.25.6](https://github.com/RevenueCat/purchases-ios/releases/tag/4.25.6)
  * [iOS 4.25.5](https://github.com/RevenueCat/purchases-ios/releases/tag/4.25.5)
  * [iOS 4.25.4](https://github.com/RevenueCat/purchases-ios/releases/tag/4.25.4)
  * [iOS 4.25.3](https://github.com/RevenueCat/purchases-ios/releases/tag/4.25.3)
* [AUTOMATIC BUMP] Updates purchases-hybrid-common to 5.6.1 (#401) via RevenueCat Git Bot (@RCGitBot)
  * [Android 6.9.2](https://github.com/RevenueCat/purchases-android/releases/tag/6.9.2)
  * [Android 6.9.1](https://github.com/RevenueCat/purchases-android/releases/tag/6.9.1)
  * [iOS 4.25.6](https://github.com/RevenueCat/purchases-ios/releases/tag/4.25.6)
  * [iOS 4.25.5](https://github.com/RevenueCat/purchases-ios/releases/tag/4.25.5)
  * [iOS 4.25.4](https://github.com/RevenueCat/purchases-ios/releases/tag/4.25.4)
  * [iOS 4.25.3](https://github.com/RevenueCat/purchases-ios/releases/tag/4.25.3)
* Bump fastlane from 2.213.0 to 2.214.0 (#386) via dependabot[bot] (@dependabot[bot])

## 4.6.0
### Dependency Updates
* [AUTOMATIC BUMP] Updates purchases-hybrid-common to 5.6.0 (#398) via RevenueCat Git Bot (@RCGitBot)
  * [Android 6.9.0](https://github.com/RevenueCat/purchases-android/releases/tag/6.9.0)
### Other Changes
* Update offering metadata documentation with a usage example (#397) via Toni Rico (@tonidero)

## 4.5.0
### Bugfixes
* Use correct type for offering metadata (#394) via Toni Rico (@tonidero)
### Dependency Updates
* [AUTOMATIC BUMP] Updates purchases-hybrid-common to 5.5.0 (#393) via RevenueCat Git Bot (@RCGitBot)
  * [Android 6.8.0](https://github.com/RevenueCat/purchases-android/releases/tag/6.8.0)
  * [iOS 4.25.2](https://github.com/RevenueCat/purchases-ios/releases/tag/4.25.2)

## 4.4.1
### Dependency Updates
* [AUTOMATIC BUMP] Updates purchases-hybrid-common to 5.4.1 (#389) via RevenueCat Git Bot (@RCGitBot)
  * [iOS 4.25.1](https://github.com/RevenueCat/purchases-ios/releases/tag/4.25.1)

## 4.4.0
### Dependency Updates
* [AUTOMATIC BUMP] Updates purchases-hybrid-common to 5.4.0 (#387) via RevenueCat Git Bot (@RCGitBot)
  * [Android 6.7.0](https://github.com/RevenueCat/purchases-android/releases/tag/6.7.0)
  * [Android 6.6.0](https://github.com/RevenueCat/purchases-android/releases/tag/6.6.0)
  * [iOS 4.25.0](https://github.com/RevenueCat/purchases-ios/releases/tag/4.25.0)

## 4.3.0
### Bugfixes
* `presentCodeRedemptionSheet`: disabled on Catalyst (#381) via NachoSoto (@NachoSoto)
### Dependency Updates
* [AUTOMATIC BUMP] Updates purchases-hybrid-common to 5.3.0 (#383) via RevenueCat Git Bot (@RCGitBot)
  * [iOS 4.24.1](https://github.com/RevenueCat/purchases-ios/releases/tag/4.24.1)
  * [iOS 4.24.0](https://github.com/RevenueCat/purchases-ios/releases/tag/4.24.0)

## 4.2.3
### Dependency Updates
* [AUTOMATIC BUMP] Updates purchases-hybrid-common to 5.2.4 (#378) via RevenueCat Git Bot (@RCGitBot)

## 4.2.2
### Dependency Updates
* [AUTOMATIC BUMP] Updates purchases-hybrid-common to 5.2.3 (#375) via RevenueCat Git Bot (@RCGitBot)

## 4.2.1
### Dependency Updates
* [AUTOMATIC BUMP] Updates purchases-hybrid-common to 5.2.2 (#372) via RevenueCat Git Bot (@RCGitBot)
  * [Android 6.5.2](https://github.com/RevenueCat/purchases-android/releases/tag/6.5.2)
  * [iOS 4.23.1](https://github.com/RevenueCat/purchases-ios/releases/tag/4.23.1)

## 4.2.0
### Dependency Updates
* [AUTOMATIC BUMP] Updates purchases-hybrid-common to 5.2.0 (#368) via RevenueCat Git Bot (@RCGitBot)
  * [Android 6.5.1](https://github.com/RevenueCat/purchases-android/releases/tag/6.5.1)
  * [iOS 4.23.0](https://github.com/RevenueCat/purchases-ios/releases/tag/4.23.0)
  * [iOS 4.22.1](https://github.com/RevenueCat/purchases-ios/releases/tag/4.22.1)

## 4.1.0
### Bugfixes
* Remove api key (#363) via Mark Villacampa (@MarkVillacampa)
### Dependency Updates
* [AUTOMATIC BUMP] Updates purchases-hybrid-common to 5.1.0 (#365) via RevenueCat Git Bot (@RCGitBot)
  * [Android 6.5.0](https://github.com/RevenueCat/purchases-android/releases/tag/6.5.0)
  * [iOS 4.22.0](https://github.com/RevenueCat/purchases-ios/releases/tag/4.22.0)
  * [iOS 4.21.1](https://github.com/RevenueCat/purchases-ios/releases/tag/4.21.1)

## 4.0.0
**RevenueCat Purchases Cordova v4** is here!! 😻

This latest release updates the Android SDK dependency from v5 to [v6](https://github.com/RevenueCat/purchases-android/releases/tag/6.0.0) to use BillingClient 5. This version of BillingClient brings an entire new subscription model which has resulted in large changes across the entire SDK.

### Migration Guides
- See [Android Native - 5.x to 6.x Migration](https://www.revenuecat.com/docs/android-native-5x-to-6x-migration) for a more thorough explanation of the new Google subscription model announced with BillingClient 5 and how to take advantage of it in V6. This guide includes tips on product setup with the new model.

### New `SubscriptionOption` concept

#### Purchasing
In v3, a Google Play Android `Package` or `StoreProduct` represented a single purchaseable entity, and free trials or intro offers would automatically be applied to the purchase if the user was eligible.

Now, in Cordova v4, an Google Play Android `Package` or `StoreProduct` represents a duration of a subscription and contains all the ways to purchase that duration -- any offers and its base plan. Each of these purchase options are `SubscriptionOption`s.
When passing a `Package` to `purchasePackage()` or `StoreProduct` to `purchaseStoreProduct()`, the SDK will use the following logic to choose which `SubscriptionOption` to purchase:
- Filters out offers with "rc-ignore-offer" tag
- Uses `SubscriptionOption` with the longest free trial or cheapest first phase
    - Only offers the user is eligible will be applied
- Falls back to base plan

For more control, purchase subscription options with the new `purchaseSubscriptionOption()` method.

#### Models

`StoreProduct` now has a few new properties use for Google Play Android:
- `defaultOption`
  - A subscription option that will automatically be applied when purchasing a `Package` or `StoreProduct`
- `subscriptionOptions`
  - A list of subscription options (could be null)

### Observer Mode

Observer mode is still supported in v4. Other than updating the SDK version, there are no changes required.

### Offline Entitlements

✨ With this new feature, even if our main and backup servers are down, the SDK can continue to process purchases. This is enabled transparently to the user, and when the servers come back online, the SDK automatically syncs the information so it can be visible in the dashboard.

### Offering Metadata

✨ Metadata allows attaching arbitrary information as key/value pairs to your Offering to control how to display your products inside your app. The metadata you configure in an Offering is available from the RevenueCat SDK. For example, you could use it to remotely configure strings on your paywall, or even URLs of images shown on the paywall.

See the [metadata documentation](https://www.revenuecat.com/docs/offering-metadata) for more info!

## 3.15.0
### Dependency Updates
* [AUTOMATIC BUMP] Updates purchases-hybrid-common to 4.18.0 (#348) via RevenueCat Git Bot (@RCGitBot)
  * [iOS 4.21.0](https://github.com/RevenueCat/purchases-ios/releases/tag/4.21.0)
  * [iOS 4.19.1](https://github.com/RevenueCat/purchases-ios/releases/tag/4.19.1)
  * [iOS 4.20.0](https://github.com/RevenueCat/purchases-ios/releases/tag/4.20.0)

## 3.14.0
### Dependency Updates
* Bump fastlane from 2.212.2 to 2.213.0 (#343) via dependabot[bot] (@dependabot[bot])
* [AUTOMATIC BUMP] Updates purchases-hybrid-common to 4.16.0 (#341) via RevenueCat Git Bot (@RCGitBot)
  * [iOS 4.19.0](https://github.com/RevenueCat/purchases-ios/releases/tag/4.19.0)
### Other Changes
* Fix iOS integration tests (#344) via Cesar de la Vega (@vegaro)

## 3.13.0
### Dependency Updates
* [AUTOMATIC BUMP] Updates purchases-hybrid-common to 4.15.0 (#334) via RevenueCat Git Bot (@RCGitBot)
  * [iOS 4.18.0](https://github.com/RevenueCat/purchases-ios/releases/tag/4.18.0)
* Bump danger from 9.2.0 to 9.3.0 (#331) via dependabot[bot] (@dependabot[bot])
### Other Changes
* Update fastlane-plugin-revenuecat version (#333) via Cesar de la Vega (@vegaro)

## 3.12.3
### Dependency Updates
* [AUTOMATIC BUMP] Updates purchases-hybrid-common to 4.14.3 (#328) via RevenueCat Git Bot (@RCGitBot)
  * [iOS 4.17.11](https://github.com/RevenueCat/purchases-ios/releases/tag/4.17.11)
  * [iOS 4.17.10](https://github.com/RevenueCat/purchases-ios/releases/tag/4.17.10)
* Bump fastlane from 2.212.1 to 2.212.2 (#326) via dependabot[bot] (@dependabot[bot])

## 3.12.2
### Dependency Updates
* [AUTOMATIC BUMP] Updates purchases-hybrid-common to 4.14.2 (#321) via RevenueCat Git Bot (@RCGitBot)
  * [iOS 4.17.9](https://github.com/RevenueCat/purchases-ios/releases/tag/4.17.9)

## 3.12.1
### Dependency Updates
* [AUTOMATIC BUMP] Updates purchases-hybrid-common to 4.14.1 (#314) via RevenueCat Git Bot (@RCGitBot)
  * [iOS 4.17.8](https://github.com/RevenueCat/purchases-ios/releases/tag/4.17.8)

## 3.12.0
### New Features
* add `immediateAndChargeFullPrice` proration mode (#310) via Andy Boedo (@aboedo)
### Dependency Updates
* [AUTOMATIC BUMP] Updates purchases-hybrid-common to 4.14.0 (#311) via RevenueCat Git Bot (@RCGitBot)
  * [Android 5.8.2](https://github.com/RevenueCat/purchases-android/releases/tag/5.8.2)
### Other Changes
* Deprecate `usesStoreKit2IfAvailable` configuration parameter (#306) via Andy Boedo (@aboedo)

## 3.11.1
### Dependency Updates
* [AUTOMATIC BUMP] Updates purchases-hybrid-common to 4.13.5 (#305) via RevenueCat Git Bot (@RCGitBot)

## 3.11.0
### New Features
* Adds beginRefund functions (#299) via Cesar de la Vega (@vegaro)
### Dependency Updates
* [AUTOMATIC BUMP] Updates purchases-hybrid-common to 4.13.4 (#301) via RevenueCat Git Bot (@RCGitBot)
  * [iOS 4.17.7](https://github.com/RevenueCat/purchases-ios/releases/tag/4.17.7)
* Bump fastlane from 2.212.0 to 2.212.1 (#300) via dependabot[bot] (@dependabot[bot])
### Other Changes
* Fix `canMakePayments` jsdoc (#298) via Cesar de la Vega (@vegaro)

## 3.10.0
### New Features
* Add `syncObserverModeAmazonPurchase` (#288) via Cesar de la Vega (@vegaro)
### Dependency Updates
* [AUTOMATIC BUMP] Updates purchases-hybrid-common to 4.13.2 (#294) via RevenueCat Git Bot (@RCGitBot)
  * [iOS 4.17.6](https://github.com/RevenueCat/purchases-ios/releases/tag/4.17.6)
* Bump fastlane from 2.211.0 to 2.212.0 (#293) via dependabot[bot] (@dependabot[bot])
### Other Changes
* Formats files correctly (#289) via Cesar de la Vega (@vegaro)

## 3.9.1
### Dependency Updates
* [AUTOMATIC BUMP] Updates purchases-hybrid-common to 4.13.1 (#290) via RevenueCat Git Bot (@RCGitBot)
  * [Android 5.7.1](https://github.com/RevenueCat/purchases-android/releases/tag/5.7.1)
  * [iOS 4.17.5](https://github.com/RevenueCat/purchases-ios/releases/tag/4.17.5)

## 3.9.0
### New Features
* setLogHandler support (#275) via Cesar de la Vega (@vegaro)
### Dependency Updates
* [AUTOMATIC BUMP] Updates purchases-hybrid-common to 4.13.0 (#285) via RevenueCat Git Bot (@RCGitBot)
  * [iOS 4.17.4](https://github.com/RevenueCat/purchases-ios/releases/tag/4.17.4)
* [AUTOMATIC BUMP] Updates purchases-hybrid-common to 4.12.1 (#281) via RevenueCat Git Bot (@RCGitBot)
  * [iOS 4.17.4](https://github.com/RevenueCat/purchases-ios/releases/tag/4.17.4)
### Other Changes
* Fix Android integration tests (#284) via Cesar de la Vega (@vegaro)
* Remove req of macOS to avoid confusion (#279) via HaleyRevcat (@HaleyRevcat)

## 3.8.0
### New Features
* Added `Purchases.setLogLevel` (#270) via NachoSoto (@NachoSoto)
### Dependency Updates
* Update gems (#276) via Cesar de la Vega (@vegaro)
* [AUTOMATIC BUMP] Updates purchases-hybrid-common to 4.12.0 (#274) via RevenueCat Git Bot (@RCGitBot)
  * [Android 5.7.0](https://github.com/RevenueCat/purchases-android/releases/tag/5.7.0)
  * [iOS 4.17.3](https://github.com/RevenueCat/purchases-ios/releases/tag/4.17.3)
### Other Changes
* Configures dependabot (#277) via Cesar de la Vega (@vegaro)

## 3.7.0
### New Features
* Add usesStoreKit2IfAvailable to PurchasesConfiguration (#265) via Cesar de la Vega (@vegaro)
* Adds PurchasesStoreProduct.subscriptionPeriod (#264) via Cesar de la Vega (@vegaro)
### Dependency Updates
* [AUTOMATIC BUMP] Updates purchases-hybrid-common to 4.10.0 (#267) via RevenueCat Git Bot (@RCGitBot)
  * [Android 5.6.7](https://github.com/RevenueCat/purchases-android/releases/tag/5.6.7)
  * [iOS 4.17.2](https://github.com/RevenueCat/purchases-ios/releases/tag/4.17.2)
  * [iOS 4.17.1](https://github.com/RevenueCat/purchases-ios/releases/tag/4.17.1)
  * [iOS 4.17.0](https://github.com/RevenueCat/purchases-ios/releases/tag/4.17.0)
### Other Changes
* Ignores www folder and build on prepare (#269) via Cesar de la Vega (@vegaro)
* Update `fastlane-plugin-revenuecat_internal` (#268) via NachoSoto (@NachoSoto)

## 3.6.0
### Dependency Updates
* [AUTOMATIC BUMP] Updates purchases-hybrid-common to 4.8.0 (#259) via RevenueCat Git Bot (@RCGitBot)
### Other Changes
* Update Gemfile.lock (#260) via Cesar de la Vega (@vegaro)

## 3.5.0
### Dependency Updates
* [AUTOMATIC BUMP] Updates purchases-hybrid-common to 4.7.0 (#253) via RevenueCat Git Bot (@RCGitBot)
  * [iOS 4.16.0](https://github.com/RevenueCat/purchases-ios/releases/tag/4.16.0)
### Other Changes
* Adds missing params for better changelogs when bumping (#256) via Cesar de la Vega (@vegaro)
* Update Gemfile.lock (#255) via Cesar de la Vega (@vegaro)
* remove stalebot in favor of SLAs in Zendesk (#252) via Andy Boedo (@aboedo)
* Update fastlane-plugin-revenuecat_internal to latest version (#250) via Cesar de la Vega (@vegaro)
* Fix changelog and VERSIONS.md for 3.4.3 (#249) via Cesar de la Vega (@vegaro)

## 3.4.4
### Other Changes
* [AUTOMATIC BUMP] Updates purchases-hybrid-common to 4.5.4 (#246) via RevenueCat Git Bot (@RCGitBot)

## 3.4.3
Due to a deployment issue, no changes were released in this version

## 3.4.2
### Other Changes
* [AUTOMATIC BUMP] Updates purchases-hybrid-common to 4.5.2 (#240) via RevenueCat Git Bot (@RCGitBot)

## 3.4.1
### Other Changes
* [AUTOMATIC BUMP] Updates purchases-hybrid-common to 4.5.1 (#237) via RevenueCat Git Bot (@RCGitBot)

## 3.4.0
### Other Changes
* [AUTOMATIC BUMP] Updates purchases-hybrid-common to 4.5.0 (#234) via RevenueCat Git Bot (@RCGitBot)

## 3.3.3
### Other Changes
* [AUTOMATIC BUMP] Updates purchases-hybrid-common to 4.4.4 (#231) via RevenueCat Git Bot (@RCGitBot)

## 3.3.2
### Bugfixes
* Fix CDVPlugin class CDVPurchasesPlugin (pluginName: purchasesplugin) does not exist bug (#226) via Cesar de la Vega (@vegaro)
### Other Changes
* [AUTOMATIC BUMP] Updates purchases-hybrid-common to 4.4.3 (#227) via RevenueCat Git Bot (@RCGitBot)
* Setting type of module to `commonjs` (#221) via Toni Rico (@tonidero)

## 3.3.1
### Other Changes
* [AUTOMATIC BUMP] Updates purchases-hybrid-common to 4.4.1 (#222) via RevenueCat Git Bot (@RCGitBot)
* Update Fastlane plugin (#218) via Cesar de la Vega (@vegaro)

## 3.3.0
### Bugfixes
* Untangle configure and delegate (#188) via Andy Boedo (@aboedo)
### Other Changes
* [AUTOMATIC] Updates purchases-hybrid-common to 4.4.0 (#217) via RevenueCat Git Bot (@RCGitBot)
* Makes hold job depend on integration tests (#215) via Cesar de la Vega (@vegaro)
* Adds missing parameter to bump_version_update_changelog_create_pr (#214) via Cesar de la Vega (@vegaro)

## 3.2.1
### Other Changes
* Update fastlane-plugin-revenuecat_internal (#212) via Cesar de la Vega (@vegaro)
* [AUTOMATIC] Updates purchases-hybrid-common to 4.3.6 (#211) via RevenueCat Git Bot (@RCGitBot)

## 3.2.0
### Other Changes
* [AUTOMATIC] Updates purchases-hybrid-common to 4.3.2 (#207) via RevenueCat Git Bot (@RCGitBot)
* Update releasing docs (#205) via Cesar de la Vega (@vegaro)
* Configures release train (#204) via Cesar de la Vega (@vegaro)

## 3.1.0

`Purchases.configure` has been deprecated in favor of `Purchases.configureWith`, which accepts a `PurchasesConfiguration` object.

```
Purchases.configure("api_key", "user_id", true, "user.defaults.suite.name")
```

has been replaced with:

```
Purchases.configureWith({
    apiKey: "api_key",
    appUserID: "user_id",
    observerMode: true,
    userDefaultsSuiteName: "user.defaults.suite.name",
});
```

This allows for more flexibility since some configuration parameters arguments can now be omitted so the defaults are used. For example:

```
Purchases.configureWith({
    apiKey: "api_key",
    appUserID: "user_id",
    userDefaultsSuiteName: "user.defaults.suite.name",
});
```

Or:

```
Purchases.configureWith({
    apiKey: "api_key",
    observerMode: true,
});
```

#### Amazon Appstore Support
We have introduced support for using the Amazon Appstore. We have extensively tested this, and there are some apps using our pre-release Amazon versions in production.

However, we have found some inconsistencies in the way Amazon Appstore prices are reported. We are actively working on patching these inconsistencies.

Please help us help you by reporting any issues you find. [New RevenueCat Issue](https://github.com/RevenueCat/cordova-plugin-purchases/issues/new/).

You can enable Amazon Appstore support by configuring the SDK using the new `configureWith` function:

```
Purchases.configureWith({
    apiKey: "amazon_specific_api_key",
    useAmazon: true,
});
```

For more information around configuration please take a look at the [Amazon Appstore section in our docs](https://docs.revenuecat.com/docs/amazon-platform-resources). The official [Amazon In-App Purchasing docs](https://developer.amazon.com/docs/in-app-purchasing/iap-overview.html) also contains very valuable information, especially around testing and best practices.

### Other Changes
* Update orb to fix deploys (#200) via Cesar de la Vega (@vegaro)
* Update fastlane plugin (#199) via Cesar de la Vega (@vegaro)
* `configure` has been deprecated in favor of `configureWith`, which accepts a `PurchasesConfiguration` object (#110) via Cesar de la Vega (@vegaro)

## 3.0.0

RevenueCat for Cordova v3 is here!!

![Dancing cats](https://media.giphy.com/media/lkbNG2zqzHZUA/giphy.gif)

[Full Changelog](https://github.com/revenuecat/cordova-plugin-purchases/compare/2.4.1...3.0.0)

### Updating plugin for the most recent RevenueCat frameworks released!
#### StoreKit 2 support
This version of the SDK automatically uses StoreKit 2 APIs under the hood only for APIs that the RevenueCat team has determined work better than StoreKit 1.

#### New types and cleaned up naming
New types that wrap native types from Apple, Google and Amazon, and we cleaned up the naming of other types and methods for a more consistent experience.

### Removed APIs
- `identify` and `createAlias` have been removed in favor of `logIn`.
- `reset` has been removed in favor of `logOut`.
- `getEntitlements` has been removed in favor of `getOfferings`.
- `attributionKey` and `Purchases.addAttributionData` have been removed in favor of `set<NetworkID> methods`.
- `setAllowSharingStoreAccount` has been removed. Configure behavior through the RevenueCat dashboard instead.

### Renamed APIs
| 2.x | 3.0.0 |
| :-: | :-: |
| `PurchaserInfo` | `CustomerInfo` |
| `Purchases.getPurchaserInfo` | `Purchases.getCustomerInfo` |
| `Purchases.invalidatePurchaserInfoCache` | `Purchases.invalidateCustomerInfoCache` |
| `PurchasesTransaction` | `PurchasesStoreTransaction` |
| `PurchasesTransaction.revenueCatId` | `PurchasesStoreTransaction.transactionIdentifier` |
| `PurchasesTransaction.productId` | `PurchasesStoreTransaction.productIdentifier` |
| `PurchasesProduct` | `PurchasesStoreProduct` |
| `PurchasesProduct.intro_price` (`number`) | `PurchasesStoreProduct.introPrice` (`PurchasesIntroPrice`) |
| `PurchasesProduct.price_string` | `PurchasesStoreProduct.priceString` |
| `PurchasesProduct.currency_code` | `PurchasesStoreProduct.currencyCode` |
| `Purchases.restoreTransactions` | `Purchases.restorePurchases` |
| `Purchases.updatedPurchaserInfoListener` | `Purchases.updatedCustomerInfoListener` |
| `Purchases.setup` | `Purchases.configure` |

### Bugfixes
* Configure should be called in the current thread and not in a UI thread (#193) via Cesar de la Vega (@vegaro)
### New Features
* Add support for Firebase, Mixpanel, and CleverTap integrations (#177) via Joshua Liebowitz (@taquitos)
* Apple AdServices support (#167)
### Other Changes
* Improve purchase tester (#186) via Andy Boedo (@aboedo)
* cordova-plugin-purchases requires Xcode 13.0+ and minimum targets iOS 11.0+ and macOS 10.13+ (#160) via NachoSoto (@NachoSoto)
* Lots of other under-the-hood improvements. For a full overview of the changes take a look at the [full Changelog](https://github.com/revenuecat/cordova-plugin-purchases/compare/2.4.1...3.0.0)

## 2.4.2

- Setting type of module to `commonjs` https://github.com/RevenueCat/cordova-plugin-purchases/pull/192

## 2.4.1

- Bump`purchases-hybrid-common` to `2.0.1` [Changelog here](https://github.com/RevenueCat/purchases-hybrid-common/releases/tag/2.0.1)
- Bump `purchases-ios` to `3.14.1` ([Changelog here](https://github.com/RevenueCat/purchases-ios/releases/3.14.1))
- Bump `purchases-android` to `4.6.1` ([Changelog here](https://github.com/RevenueCat/purchases-android/releases/4.6.1))

## 2.4.0

- Bump`purchases-hybrid-common` to `1.10.0` [Changelog here](https://github.com/RevenueCat/purchases-hybrid-common/releases/tag/1.10.0)
- Bump `purchases-ios` to `3.13.0` ([Changelog here](https://github.com/RevenueCat/purchases-ios/releases/3.13.0))
- Bump `purchases-android` to `4.4.0` ([Changelog here](https://github.com/RevenueCat/purchases-android/releases/4.4.0))
- Added support for Airship integration via `setAirshipChannelID`
    https://github.com/RevenueCat/cordova-plugin-purchases/pull/113

## 2.3.2

- Bump `purchases-ios` to 3.12.8
    [3.12.8 Changelog here](https://github.com/RevenueCat/purchases-ios/releases/tag/3.12.8)
    [3.12.7 Changelog here](https://github.com/RevenueCat/purchases-ios/releases/tag/3.12.7)
    [3.12.6 Changelog here](https://github.com/RevenueCat/purchases-ios/releases/tag/3.12.6)
    [3.12.5 Changelog here](https://github.com/RevenueCat/purchases-ios/releases/tag/3.12.5)
    [3.12.4 Changelog here](https://github.com/RevenueCat/purchases-ios/releases/tag/3.12.4)
 - Bump `purchases-android` to 4.3.3
    [4.3.3 Changelog here](https://github.com/RevenueCat/purchases-android/releases/tag/4.3.3)
    [4.3.2 Changelog here](https://github.com/RevenueCat/purchases-android/releases/tag/4.3.2)

## 2.3.1

- Bumped purchases-android to 4.3.1 [Changelog here](https://github.com/RevenueCat/purchases-android/releases/4.3.1),
which fixes canMakePayments not returning (see related issue: https://github.com/RevenueCat/purchases-unity/issues/61)
- Bumped purchases-ios to 3.12.3 [Changelog here](https://github.com/RevenueCat/purchases-ios/releases/tag/3.12.3)
- Bumped purchases-hybrid-common to 1.9.1 [Changelog here](https://github.com/RevenueCat/purchases-hybrid-common/releases/tag/1.9.1)

## 2.3.0

### Identity V3:

In this version, we’ve redesigned the way that user identification works.
Detailed docs about the new system are available [here](https://docs.revenuecat.com/v3.2/docs/user-ids).

#### New methods
- Introduces `logIn`, a new way of identifying users, which also returns whether a new user has been registered in the system.
`logIn` uses a new backend endpoint.
- Introduces `logOut`, a replacement for `reset`.

#### Deprecations
- deprecates `createAlias` in favor of `logIn`.
- deprecates `identify` in favor of `logIn`.
- deprecates `reset` in favor of `logOut`.
- deprecates `setAllowSharingStoreAccount` in favor of dashboard-side configuration.
    https://github.com/RevenueCat/cordova-plugin-purchases/pull/80

#### Other
- Fix return type in `canMakePayments` documentation
    https://github.com/RevenueCat/cordova-plugin-purchases/pull/80
- Dependency security updates
    https://github.com/RevenueCat/cordova-plugin-purchases/pull/98
- Bumped purchases-ios to 3.12.2 [Changelog here](https://github.com/RevenueCat/purchases-ios/releases/3.12.2)
- Bumped purchases-android to 4.3.0 [Changelog here](https://github.com/RevenueCat/purchases-android/releases/4.3.0)
- Updated BillingClient to version [4.0.0](https://developer.android.com/google/play/billing/release-notes#4-0).
     https://github.com/RevenueCat/purchases-android/commit/f6554bbf7376c3fd492f0bc67183a9f35889ae78

## 2.2.0

- Add canMakePayments method (https://github.com/RevenueCat/cordova-plugin-purchases/pull/96)
- Update type for availablePackages (https://github.com/RevenueCat/cordova-plugin-purchases/pull/94)
- Cleaned up return types for sync methods (https://github.com/RevenueCat/cordova-plugin-purchases/pull/82)
- Bumped purchases-hybrid-common to 1.7.1 [Changelog here](https://github.com/RevenueCat/purchases-hybrid-common/releases/1.7.1)
- Bumped purchases-ios to 3.11.1 [Changelog here](https://github.com/RevenueCat/purchases-ios/releases/3.11.1)
- Bumped purchases-android to 4.2.1 [Changelog here](https://github.com/RevenueCat/purchases-hybrid-common/releases/4.2.1)

## 2.1.1

- Bumped purchases-hybrid-common to 1.6.2 [Changelog here](https://github.com/RevenueCat/purchases-hybrid-common/releases/1.6.2)
- Bumped purchases-ios to 3.10.7 [Changelog here](https://github.com/RevenueCat/purchases-ios/releases/3.10.7)
- Bumped purchases-android to 4.0.5 [Changelog here](https://github.com/RevenueCat/purchases-hybrid-common/releases/4.0.5)
    https://github.com/RevenueCat/cordova-plugin-purchases/pull/76

## 2.1.0

- iOS:
    - Added a new method `setSimulatesAskToBuyInSandbox`, that allows developers to test deferred purchases easily.
- Bumped purchases-hybrid-common to 1.6.1 [Changelog here](https://github.com/RevenueCat/purchases-hybrid-common/releases/1.6.1)
- Bumped purchases-ios to 3.10.6 [Changelog here](https://github.com/RevenueCat/purchases-ios/releases/3.10.6)
- Bumped purchases-android to 4.0.4 [Changelog here](https://github.com/RevenueCat/purchases-hybrid-common/releases/4.0.4)
    https://github.com/RevenueCat/cordova-plugin-purchases/pull/76

### 2.0.0

- removes deprecated `makePurchase`, replaced by `purchaseProduct`
 - iOS:
     - added new method, `syncPurchases`, that enables syncing the purchases in the local receipt with the backend without risking a password prompt. The method was already available on Android.
     - added a new method, `presentCodeRedemptionSheet`, for offer codes redemption.
- Bumped `purchases-hybrid-common` to 1.5.0 [Changelog here](https://github.com/RevenueCat/purchases-hybrid-common/releases/1.5.0)
- Bumped `purchases-ios` to 3.9.2 [Changelog here](https://github.com/RevenueCat/purchases-ios/releases/3.9.2)
- Bumped `purchases-android` to 4.0.1 [Changelog here](https://github.com/RevenueCat/purchases-android/releases/4.0.1)

### 1.3.2

- Bumped `purchases-hybrid-common` to 1.4.5 [Changelog here](https://github.com/RevenueCat/purchases-hybrid-common/releases/1.4.5)
- Bumped `purchases-ios` to 3.7.5 [Changelog here](https://github.com/RevenueCat/purchases-ios/releases/3.7.5)
- Updates docs for subscriber attributes https://github.com/RevenueCat/cordova-plugin-purchases/pull/57

### 1.3.1

- Bumped `purchases-hybrid-common` to 1.4.4 [Changelog here](https://github.com/RevenueCat/purchases-hybrid-common/releases/1.4.4)
- Bumped `purchases-android` to 3.5.2 [Changelog here](https://github.com/RevenueCat/purchases-android/releases/3.5.2)

### 1.3.0

- Attribution V2:
    - Deprecated `addAttribution` in favor of `setAdjustId`, `setAppsflyerId`, `setFbAnonymousId`, `setMparticleId`.
    - Added support for OneSignal via `setOnesignalId`
    - Added `setMediaSource`, `setCampaign`, `setAdGroup`, `setAd`, `setKeyword`, `setCreative`, and `collectDeviceIdentifiers`
         https://github.com/RevenueCat/purchases-android/pull/184
- Bumped `purchases-hybrid-common` to 1.4.3 [Changelog here](https://github.com/RevenueCat/purchases-hybrid-common/releases/1.4.3)
- Bumped `purchases-ios` to 3.7.2 [Changelog here](https://github.com/RevenueCat/purchases-ios/releases/3.7.2)
- Bumped `purchases-android` to 3.5.0 [Changelog here](https://github.com/RevenueCat/purchases-android/releases/3.5.0)
- Added `PurchasesPlugin.swift` to prevent compiling issues on objective-c projects
- removed `use-frameworks` setting in the sample app to fix linking issues

## 1.2.2

- Adds missing import.

## 1.2.1

- Removed lambda from Android code (https://github.com/RevenueCat/cordova-plugin-purchases/pull/51)

## 1.2.0

- Bumped iOS to 3.4.0 [Changelog here](https://github.com/RevenueCat/purchases-ios/releases)
- Bumped Android to 3.2.0 [Changelog here](https://github.com/RevenueCat/purchases-android/releases)
- Added managementURL to PurchaserInfo
- Added setProxyURL
- Added originalPurchaseDate to PurchaserInfo
- Adds new headers for platformFlavor and platformFlavorVersion
- Adds userDefaultsSuiteName as an option when setting up the SDK
- Linked TS Types (https://github.com/RevenueCat/cordova-plugin-purchases/pull/42)
- Moved iOS common files to use pod dependencies (https://github.com/RevenueCat/cordova-plugin-purchases/pull/39)
- Moved Android common files to use gradle maven dependency (https://github.com/RevenueCat/cordova-plugin-purchases/pull/39)

## 1.1.0

- Adds an example project that shows how to set up an app with RevenueCat
    https://github.com/RevenueCat/cordova-plugin-purchases/pull/29
- Adds Subscriber Attributes, which allow developers to store additional, structured information
for a user in RevenueCat. More info: https://docs.revenuecat.com/docs/user-attributes.
- Adds new method to invalidate the purchaser info cache, useful when promotional purchases are granted from outside the app.
    https://github.com/RevenueCat/cordova-plugin-purchases/pull/32

## 1.0.5

- Adds `shouldPurchasePromoProduct`, which allows the app to decide how and when to handle promotional purchases made by users directly through the App Store (https://github.com/RevenueCat/cordova-plugin-purchases/pull/25).
- Fixes some JSDocs and export types https://github.com/RevenueCat/cordova-plugin-purchases/pull/26.

## 1.0.4

- Adds missing types

## 1.0.3

- Renames `introEligibilityStatus` to `status` in `IntroEligibility`

## 1.0.2

- Adds `checkTrialOrIntroductoryPriceEligibility`. Note that Android always returns INTRO_ELIGIBILITY_STATUS_UNKNOWN.
- Updates iOS to 3.0.1 and Android to 3.0.4

## 1.0.1

- Updates Android to 3.0.3

## 1.0.0

- Support for new Offerings system.
- Deprecates `makePurchase` methods. Replaces with `purchasePackage`
- Deprecates `getEntitlements` method. Replaces with `getOfferings`
- See our migration guide for more info: https://docs.revenuecat.com/v3.0/docs/offerings-migration
- Updates to BillingClient 2.0.3. If finishTransactions is set to false (or observerMode is true when configuring the SDK),
this SDK won't acknowledge any purchase and you have to do it yourself.
- Adds proration mode support on upgrades/downgrades
- Adds more PurchaserInfo missing properties. `activeEntitlements`, `expirationsForActiveEntitlements`
and `purchaseDatesForActiveEntitlements` have been removed from PurchaserInfo
- `intro_price`, `intro_price_period_number_of_units` and `intro_price_cycles` are a number now or null instead of empty
 strings, `intro_price_period_unit` can also be null.
- Added Typescript types
- New identity changes:
  - The .createAlias() method is no longer required, use .identify() instead
  - .identify() will create an alias if being called from an anonymous ID generated by RevenueCat
  - Added an isAnonymous property to Purchases.sharedInstance
  - Improved offline use

## 0.3.2

- Fixes EntitlementInfo's `expirationDate` in iOS.

## 0.3.1

- Fixes crash when there's a trial period and not an introductory price on Android.

## 0.3.0

- Deprecates activeEntitlements in PurchaserInfo and adds entitlements object to RCPurchaserInfo. For more info check out https://docs.revenuecat.com/docs/purchaserinfo
- Fixes trial info being lost in Android. Access intro_price in the product information to get information around the trial period.
- Fixes exception when trying to purchase a product that doesn't exist.

## 0.2.1

- Fixes a bug when normalizing intro_price_period.
- **BREAKING_CHANGE** All `intro_price` related fields in the product are strings, or empty strings if inexistent, in both iOS and Android. There were some discrepancies between platforms released in https://github.com/RevenueCat/cordova-plugin-purchases/releases/tag/0.2.0.

## 0.2.0

- Upgrades iOS SDK to https://github.com/RevenueCat/purchases-ios/releases/tag/2.5.0 and Android to https://github.com/RevenueCat/purchases-android/releases/tag/2.3.0.
- Adds Facebook as supported attribution network.
- DEPRECATION: automaticAttributionCollection is now deprecated in favor of automaticAppleSearchAdsAttributionCollection since it's a more clear name.
- Adds introductory pricing to the iOS product.

## 0.1.2

- Compile javascript down to ES5 for better support

## 0.1.1

- Fixes Android `makePurchase` errors
- Fixes `readable_error_code` in iOS

## 0.1.0

- Updates iOS SDK to 2.3.0. Check out the changelog for a full list of changes https://github.com/RevenueCat/purchases-ios/releases/tag/2.3.0
- Updates Android SDK to 2.2.2. Check out the changelog for a full list of changes https://github.com/RevenueCat/purchases-android/releases/tag/2.2.2
- ** BREAKING CHANGE ** makePurchase parameter oldSKUs is not an array anymore, it only accepts a string now. This is due to changes in the BillingClient.
- AddAttributionData can be called before the SDK has been setup. A network user identifier can be send to the addAttribution function, replacing the previous rc_appsflyer_id parameter.
- Adds an optional configuration boolean observerMode. This will set the value of finishTransactions at configuration time.

### Android only:

- addAttribution will automatically add the rc_gps_adid parameter.
- ** ANDROID BREAKING CHANGE ** Call syncTransactions to send purchases information to RevenueCat after any restore or purchase if you are using the SDK in observerMode. See our guide on Migrating Subscriptions for more information on syncTransactions: https://docs.revenuecat.com/docs/migrating-existing-subscriptions

### iOS only

- addAttribution will automatically add the rc_idfa and rc_idfv parameters if the AdSupport and UIKit frameworks are included, respectively.
- Apple Search Ad attribution can be automatically collected by setting the automaticAttributionCollection boolean to true before the SDK is configured.
- Other bugfixes

## 0.0.8

- Updates iOS SDK to 2.1.1

## 0.0.7

- Fixes exception on iOS when sending an error

## 0.0.6

- Fixes errors in Android not being sent as int
- Fixes crash when underlyingErrorMessage is missing

## 0.0.5

- Updates versions to 2.1.0 with the new error handling.
- **Breaking** change, the errors have changed and now return an underlyingErrorMessage instead of the domain.
- Removes the preinstall hook that was causing errors in Windows. 0.0.4 version was broken for some. The iOS framework will be included in the repo from now on.
- **Breaking** the error callback of makePurchase now returns an error and a boolean indicating if the user cancelled.

## 0.0.4

- Fixes windows by skipping installation of iOS download script if not building for iOS.

## 0.0.3

- Removes `onDestroy` Android's Activity lifecycle hook since it was closing the instance.
