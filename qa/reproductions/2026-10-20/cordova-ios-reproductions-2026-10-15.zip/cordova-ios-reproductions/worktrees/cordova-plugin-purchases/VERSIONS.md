| Version       | iOS version | Android version | Common files version | Play Billing Library version |
|---------------|-------------|-----------------|----------------------|------------------------------|
| 8.2.4 | [5.94.0](https://github.com/RevenueCat/purchases-ios/releases/tag/5.94.0) | [10.26.0](https://github.com/RevenueCat/purchases-android/releases/tag/10.26.0) | [19.10.0](https://github.com/RevenueCat/purchases-hybrid-common/releases/tag/19.10.0) | [8.3.0](https://developer.android.com/google/play/billing/release-notes) |
| 8.2.3 | [5.90.2](https://github.com/RevenueCat/purchases-ios/releases/tag/5.90.2) | [10.22.1](https://github.com/RevenueCat/purchases-android/releases/tag/10.22.1) | [19.3.1](https://github.com/RevenueCat/purchases-hybrid-common/releases/tag/19.3.1) | [8.3.0](https://developer.android.com/google/play/billing/release-notes) |
| 8.2.2 | [5.89.0](https://github.com/RevenueCat/purchases-ios/releases/tag/5.89.0) | [10.21.1](https://github.com/RevenueCat/purchases-android/releases/tag/10.21.1) | [19.0.0](https://github.com/RevenueCat/purchases-hybrid-common/releases/tag/19.0.0) | [8.3.0](https://developer.android.com/google/play/billing/release-notes) |
| 8.2.1 | [5.88.0](https://github.com/RevenueCat/purchases-ios/releases/tag/5.88.0) | [10.20.0](https://github.com/RevenueCat/purchases-android/releases/tag/10.20.0) | [18.36.1](https://github.com/RevenueCat/purchases-hybrid-common/releases/tag/18.36.1) | [8.3.0](https://developer.android.com/google/play/billing/release-notes) |
| 8.2.0 | [5.87.1](https://github.com/RevenueCat/purchases-ios/releases/tag/5.87.1) | [10.19.1](https://github.com/RevenueCat/purchases-android/releases/tag/10.19.1) | [18.33.1](https://github.com/RevenueCat/purchases-hybrid-common/releases/tag/18.33.1) | [8.3.0](https://developer.android.com/google/play/billing/release-notes) |
| 8.1.0 | [5.85.0](https://github.com/RevenueCat/purchases-ios/releases/tag/5.85.0) | [10.18.1](https://github.com/RevenueCat/purchases-android/releases/tag/10.18.1) | [18.32.1](https://github.com/RevenueCat/purchases-hybrid-common/releases/tag/18.32.1) | [8.3.0](https://developer.android.com/google/play/billing/release-notes) |
| 8.0.14 | [5.82.0](https://github.com/RevenueCat/purchases-ios/releases/tag/5.82.0) | [10.15.1](https://github.com/RevenueCat/purchases-android/releases/tag/10.15.1) | [18.27.0](https://github.com/RevenueCat/purchases-hybrid-common/releases/tag/18.27.0) | [8.3.0](https://developer.android.com/google/play/billing/release-notes) |
| 8.0.13 | [5.81.3](https://github.com/RevenueCat/purchases-ios/releases/tag/5.81.3) | [10.15.1](https://github.com/RevenueCat/purchases-android/releases/tag/10.15.1) | [18.26.0](https://github.com/RevenueCat/purchases-hybrid-common/releases/tag/18.26.0) | [8.3.0](https://developer.android.com/google/play/billing/release-notes) |
| 8.0.12 | [5.81.1](https://github.com/RevenueCat/purchases-ios/releases/tag/5.81.1) | [10.14.1](https://github.com/RevenueCat/purchases-android/releases/tag/10.14.1) | [18.22.2](https://github.com/RevenueCat/purchases-hybrid-common/releases/tag/18.22.2) | [8.3.0](https://developer.android.com/google/play/billing/release-notes) |
| 8.0.10 | [5.80.2](https://github.com/RevenueCat/purchases-ios/releases/tag/5.80.2) | [10.12.0](https://github.com/RevenueCat/purchases-android/releases/tag/10.12.0) | [18.19.0](https://github.com/RevenueCat/purchases-hybrid-common/releases/tag/18.19.0) | [8.3.0](https://developer.android.com/google/play/billing/release-notes) |
| 8.0.9 | [5.80.0](https://github.com/RevenueCat/purchases-ios/releases/tag/5.80.0) | [10.11.0](https://github.com/RevenueCat/purchases-android/releases/tag/10.11.0) | [18.17.0](https://github.com/RevenueCat/purchases-hybrid-common/releases/tag/18.17.0) | [8.3.0](https://developer.android.com/google/play/billing/release-notes) |
| 8.0.8 | [5.78.0](https://github.com/RevenueCat/purchases-ios/releases/tag/5.78.0) | [10.9.1](https://github.com/RevenueCat/purchases-android/releases/tag/10.9.1) | [18.15.1](https://github.com/RevenueCat/purchases-hybrid-common/releases/tag/18.15.1) | [8.3.0](https://developer.android.com/google/play/billing/release-notes) |
| 8.0.7 | [5.76.0](https://github.com/RevenueCat/purchases-ios/releases/tag/5.76.0) | [10.8.0](https://github.com/RevenueCat/purchases-android/releases/tag/10.8.0) | [18.10.0](https://github.com/RevenueCat/purchases-hybrid-common/releases/tag/18.10.0) | [8.3.0](https://developer.android.com/google/play/billing/release-notes) |
| 8.0.6 | [5.75.0](https://github.com/RevenueCat/purchases-ios/releases/tag/5.75.0) | [10.7.0](https://github.com/RevenueCat/purchases-android/releases/tag/10.7.0) | [18.9.1](https://github.com/RevenueCat/purchases-hybrid-common/releases/tag/18.9.1) | [8.3.0](https://developer.android.com/google/play/billing/release-notes) |
| 8.0.5 | [5.74.0](https://github.com/RevenueCat/purchases-ios/releases/tag/5.74.0) | [10.6.1](https://github.com/RevenueCat/purchases-android/releases/tag/10.6.1) | [18.8.0](https://github.com/RevenueCat/purchases-hybrid-common/releases/tag/18.8.0) | [8.3.0](https://developer.android.com/google/play/billing/release-notes) |
| 8.0.4 | [5.73.0](https://github.com/RevenueCat/purchases-ios/releases/tag/5.73.0) | [10.6.0](https://github.com/RevenueCat/purchases-android/releases/tag/10.6.0) | [18.7.0](https://github.com/RevenueCat/purchases-hybrid-common/releases/tag/18.7.0) | [8.3.0](https://developer.android.com/google/play/billing/release-notes) |
| 8.0.3 | [5.72.0](https://github.com/RevenueCat/purchases-ios/releases/tag/5.72.0) | [10.5.0](https://github.com/RevenueCat/purchases-android/releases/tag/10.5.0) | [18.6.0](https://github.com/RevenueCat/purchases-hybrid-common/releases/tag/18.6.0) | [8.3.0](https://developer.android.com/google/play/billing/release-notes) |
| 8.0.2 | [5.70.0](https://github.com/RevenueCat/purchases-ios/releases/tag/5.70.0) | [10.3.1](https://github.com/RevenueCat/purchases-android/releases/tag/10.3.1) | [18.3.0](https://github.com/RevenueCat/purchases-hybrid-common/releases/tag/18.3.0) | [8.3.0](https://developer.android.com/google/play/billing/release-notes) |
| 8.0.1 | [5.68.0](https://github.com/RevenueCat/purchases-ios/releases/tag/5.68.0) | [10.2.0](https://github.com/RevenueCat/purchases-android/releases/tag/10.2.0) | [18.1.0](https://github.com/RevenueCat/purchases-hybrid-common/releases/tag/18.1.0) | [8.3.0](https://developer.android.com/google/play/billing/release-notes) |
| 8.0.0 | [5.67.2](https://github.com/RevenueCat/purchases-ios/releases/tag/5.67.2) | [10.1.2](https://github.com/RevenueCat/purchases-android/releases/tag/10.1.2) | [18.0.0](https://github.com/RevenueCat/purchases-hybrid-common/releases/tag/18.0.0) | [8.3.0](https://developer.android.com/google/play/billing/release-notes) |
| 7.3.6 | [5.67.1](https://github.com/RevenueCat/purchases-ios/releases/tag/5.67.1) | [9.29.0](https://github.com/RevenueCat/purchases-android/releases/tag/9.29.0) | [17.55.1](https://github.com/RevenueCat/purchases-hybrid-common/releases/tag/17.55.1) | [8.0.0](https://developer.android.com/google/play/billing/release-notes) |
| 7.3.5 | [5.67.1](https://github.com/RevenueCat/purchases-ios/releases/tag/5.67.1) | [9.29.0](https://github.com/RevenueCat/purchases-android/releases/tag/9.29.0) | [17.55.1](https://github.com/RevenueCat/purchases-hybrid-common/releases/tag/17.55.1) | [8.0.0](https://developer.android.com/google/play/billing/release-notes) |
| 7.3.4 | [5.67.0](https://github.com/RevenueCat/purchases-ios/releases/tag/5.67.0) | [9.28.1](https://github.com/RevenueCat/purchases-android/releases/tag/9.28.1) | [17.54.0](https://github.com/RevenueCat/purchases-hybrid-common/releases/tag/17.54.0) | [8.0.0](https://developer.android.com/google/play/billing/release-notes) |
| 7.3.3 | [5.61.0](https://github.com/RevenueCat/purchases-ios/releases/tag/5.61.0) | [9.23.1](https://github.com/RevenueCat/purchases-android/releases/tag/9.23.1) | [17.46.1](https://github.com/RevenueCat/purchases-hybrid-common/releases/tag/17.46.1) | [8.0.0](https://developer.android.com/google/play/billing/release-notes) |
| 7.3.2 | [5.60.0](https://github.com/RevenueCat/purchases-ios/releases/tag/5.60.0) | [9.22.2](https://github.com/RevenueCat/purchases-android/releases/tag/9.22.2) | [17.42.0](https://github.com/RevenueCat/purchases-hybrid-common/releases/tag/17.42.0) | [8.0.0](https://developer.android.com/google/play/billing/release-notes) |
| 7.3.1 | [5.59.2](https://github.com/RevenueCat/purchases-ios/releases/tag/5.59.2) | [9.22.1](https://github.com/RevenueCat/purchases-android/releases/tag/9.22.1) | [17.41.1](https://github.com/RevenueCat/purchases-hybrid-common/releases/tag/17.41.1) | [8.0.0](https://developer.android.com/google/play/billing/release-notes) |
| 7.3.0 | [5.59.0](https://github.com/RevenueCat/purchases-ios/releases/tag/5.59.0) | [9.22.0](https://github.com/RevenueCat/purchases-android/releases/tag/9.22.0) | [17.40.0](https://github.com/RevenueCat/purchases-hybrid-common/releases/tag/17.40.0) | [8.0.0](https://developer.android.com/google/play/billing/release-notes) |
| 7.2.17 | [5.57.2](https://github.com/RevenueCat/purchases-ios/releases/tag/5.57.2) | [9.20.2](https://github.com/RevenueCat/purchases-android/releases/tag/9.20.2) | [17.33.1](https://github.com/RevenueCat/purchases-hybrid-common/releases/tag/17.33.1) | [8.0.0](https://developer.android.com/google/play/billing/release-notes) |
| 7.2.16 | [5.57.0](https://github.com/RevenueCat/purchases-ios/releases/tag/5.57.0) | [9.20.0](https://github.com/RevenueCat/purchases-android/releases/tag/9.20.0) | [17.31.0](https://github.com/RevenueCat/purchases-hybrid-common/releases/tag/17.31.0) | [8.0.0](https://developer.android.com/google/play/billing/release-notes) |
| 7.2.15 | [5.56.0](https://github.com/RevenueCat/purchases-ios/releases/tag/5.56.0) | [9.19.3](https://github.com/RevenueCat/purchases-android/releases/tag/9.19.3) | [17.30.0](https://github.com/RevenueCat/purchases-hybrid-common/releases/tag/17.30.0) | [8.0.0](https://developer.android.com/google/play/billing/release-notes) |
| 7.2.14 | [5.55.2](https://github.com/RevenueCat/purchases-ios/releases/tag/5.55.2) | [9.19.1](https://github.com/RevenueCat/purchases-android/releases/tag/9.19.1) | [17.28.1](https://github.com/RevenueCat/purchases-hybrid-common/releases/tag/17.28.1) | [8.0.0](https://developer.android.com/google/play/billing/release-notes) |
| 7.2.13 | [5.52.1](https://github.com/RevenueCat/purchases-ios/releases/tag/5.52.1) | [9.18.1](https://github.com/RevenueCat/purchases-android/releases/tag/9.18.1) | [17.26.1](https://github.com/RevenueCat/purchases-hybrid-common/releases/tag/17.26.1) | [8.0.0](https://developer.android.com/google/play/billing/release-notes) |
| 7.2.12 | [5.52.0](https://github.com/RevenueCat/purchases-ios/releases/tag/5.52.0) | [9.18.0](https://github.com/RevenueCat/purchases-android/releases/tag/9.18.0) | [17.26.0](https://github.com/RevenueCat/purchases-hybrid-common/releases/tag/17.26.0) | [8.0.0](https://developer.android.com/google/play/billing/release-notes) |
| 7.2.11 | [5.51.1](https://github.com/RevenueCat/purchases-ios/releases/tag/5.51.1) | [9.18.0](https://github.com/RevenueCat/purchases-android/releases/tag/9.18.0) | [17.25.0](https://github.com/RevenueCat/purchases-hybrid-common/releases/tag/17.25.0) | [8.0.0](https://developer.android.com/google/play/billing/release-notes) |
| 7.2.10 | [5.50.1](https://github.com/RevenueCat/purchases-ios/releases/tag/5.50.1) | [9.15.5](https://github.com/RevenueCat/purchases-android/releases/tag/9.15.5) | [17.24.0](https://github.com/RevenueCat/purchases-hybrid-common/releases/tag/17.24.0) | [8.0.0](https://developer.android.com/google/play/billing/release-notes) |
| 7.2.9 | [5.50.0](https://github.com/RevenueCat/purchases-ios/releases/tag/5.50.0) | [9.15.3](https://github.com/RevenueCat/purchases-android/releases/tag/9.15.3) | [17.23.0](https://github.com/RevenueCat/purchases-hybrid-common/releases/tag/17.23.0) | [8.0.0](https://developer.android.com/google/play/billing/release-notes) |
| 7.2.8 | [5.49.1](https://github.com/RevenueCat/purchases-ios/releases/tag/5.49.1) | [9.15.1](https://github.com/RevenueCat/purchases-android/releases/tag/9.15.1) | [17.21.1](https://github.com/RevenueCat/purchases-hybrid-common/releases/tag/17.21.1) | [8.0.0](https://developer.android.com/google/play/billing/release-notes) |
| 7.2.7 | [5.49.0](https://github.com/RevenueCat/purchases-ios/releases/tag/5.49.0) | [9.15.0](https://github.com/RevenueCat/purchases-android/releases/tag/9.15.0) | [17.21.0](https://github.com/RevenueCat/purchases-hybrid-common/releases/tag/17.21.0) | [8.0.0](https://developer.android.com/google/play/billing/release-notes) |
| 7.2.6 | [5.48.0](https://github.com/RevenueCat/purchases-ios/releases/tag/5.48.0) | [9.14.0](https://github.com/RevenueCat/purchases-android/releases/tag/9.14.0) | [17.19.1](https://github.com/RevenueCat/purchases-hybrid-common/releases/tag/17.19.1) | [8.0.0](https://developer.android.com/google/play/billing/release-notes) |
| 7.2.4 | [5.47.0](https://github.com/RevenueCat/purchases-ios/releases/tag/5.47.0) | [9.13.0](https://github.com/RevenueCat/purchases-android/releases/tag/9.13.0) | [17.17.0](https://github.com/RevenueCat/purchases-hybrid-common/releases/tag/17.17.0) | [8.0.0](https://developer.android.com/google/play/billing/release-notes) |
| 7.2.3 | [5.46.1](https://github.com/RevenueCat/purchases-ios/releases/tag/5.46.1) | [9.12.2](https://github.com/RevenueCat/purchases-android/releases/tag/9.12.2) | [17.16.0](https://github.com/RevenueCat/purchases-hybrid-common/releases/tag/17.16.0) | [8.0.0](https://developer.android.com/google/play/billing/release-notes) |
| 7.2.2 | [5.46.0](https://github.com/RevenueCat/purchases-ios/releases/tag/5.46.0) | [9.12.1](https://github.com/RevenueCat/purchases-android/releases/tag/9.12.1) | [17.13.0](https://github.com/RevenueCat/purchases-hybrid-common/releases/tag/17.13.0) | [8.0.0](https://developer.android.com/google/play/billing/release-notes) |
| 7.2.1 | [5.44.1](https://github.com/RevenueCat/purchases-ios/releases/tag/5.44.1) | [9.11.0](https://github.com/RevenueCat/purchases-android/releases/tag/9.11.0) | [17.11.0](https://github.com/RevenueCat/purchases-hybrid-common/releases/tag/17.11.0) | [8.0.0](https://developer.android.com/google/play/billing/release-notes) |
| 7.2.0 | [5.43.0](https://github.com/RevenueCat/purchases-ios/releases/tag/5.43.0) | [9.9.0](https://github.com/RevenueCat/purchases-android/releases/tag/9.9.0) | [17.10.0](https://github.com/RevenueCat/purchases-hybrid-common/releases/tag/17.10.0) | [8.0.0](https://developer.android.com/google/play/billing/release-notes) |
| 7.1.5 | [5.41.0](https://github.com/RevenueCat/purchases-ios/releases/tag/5.41.0) | [9.8.0](https://github.com/RevenueCat/purchases-android/releases/tag/9.8.0) | [17.9.0](https://github.com/RevenueCat/purchases-hybrid-common/releases/tag/17.9.0) | [8.0.0](https://developer.android.com/google/play/billing/release-notes) |
| 7.1.4 | [5.40.0](https://github.com/RevenueCat/purchases-ios/releases/tag/5.40.0) | [9.7.2](https://github.com/RevenueCat/purchases-android/releases/tag/9.7.2) | [17.8.0](https://github.com/RevenueCat/purchases-hybrid-common/releases/tag/17.8.0) | [8.0.0](https://developer.android.com/google/play/billing/release-notes) |
| 7.1.3 | [5.39.0](https://github.com/RevenueCat/purchases-ios/releases/tag/5.39.0) | [9.7.0](https://github.com/RevenueCat/purchases-android/releases/tag/9.7.0) | [17.7.0](https://github.com/RevenueCat/purchases-hybrid-common/releases/tag/17.7.0) | [8.0.0](https://developer.android.com/google/play/billing/release-notes) |
| 7.1.2 | [5.38.2](https://github.com/RevenueCat/purchases-ios/releases/tag/5.38.2) | [9.6.0](https://github.com/RevenueCat/purchases-android/releases/tag/9.6.0) | [17.6.0](https://github.com/RevenueCat/purchases-hybrid-common/releases/tag/17.6.0) | [8.0.0](https://developer.android.com/google/play/billing/release-notes) |
| 7.1.1 | [5.35.1](https://github.com/RevenueCat/purchases-ios/releases/tag/5.35.1) | [9.3.2](https://github.com/RevenueCat/purchases-android/releases/tag/9.3.2) | [17.0.0](https://github.com/RevenueCat/purchases-hybrid-common/releases/tag/17.0.0) | [8.0.0](https://developer.android.com/google/play/billing/release-notes) |
| 7.1.0 | [5.34.0](https://github.com/RevenueCat/purchases-ios/releases/tag/5.34.0) | [9.2.0](https://github.com/RevenueCat/purchases-android/releases/tag/9.2.0) | [16.2.0](https://github.com/RevenueCat/purchases-hybrid-common/releases/tag/16.2.0) | [8.0.0](https://developer.android.com/google/play/billing/release-notes) |
| 7.0.1 | [5.34.0](https://github.com/RevenueCat/purchases-ios/releases/tag/5.34.0) | [9.2.0](https://github.com/RevenueCat/purchases-android/releases/tag/9.2.0) | [16.2.0](https://github.com/RevenueCat/purchases-hybrid-common/releases/tag/16.2.0) | [8.0.0](https://developer.android.com/google/play/billing/release-notes) |
| 7.0.0 | [5.33.0](https://github.com/RevenueCat/purchases-ios/releases/tag/5.33.0) | [9.1.0](https://github.com/RevenueCat/purchases-android/releases/tag/9.1.0) | [15.0.0](https://github.com/RevenueCat/purchases-hybrid-common/releases/tag/15.0.0) | [8.0.0](https://developer.android.com/google/play/billing/release-notes) |
| 6.2.13 | [5.32.0](https://github.com/RevenueCat/purchases-ios/releases/tag/5.32.0) | [8.22.0](https://github.com/RevenueCat/purchases-android/releases/tag/8.22.0) | [14.2.0](https://github.com/RevenueCat/purchases-hybrid-common/releases/tag/14.2.0) | [7.1.1](https://developer.android.com/google/play/billing/release-notes) |
| 6.2.12 | [5.30.0](https://github.com/RevenueCat/purchases-ios/releases/tag/5.30.0) | [8.20.0](https://github.com/RevenueCat/purchases-android/releases/tag/8.20.0) | [14.0.2](https://github.com/RevenueCat/purchases-hybrid-common/releases/tag/14.0.2) | [7.1.1](https://developer.android.com/google/play/billing/release-notes) |
| 6.2.11 | [5.29.0](https://github.com/RevenueCat/purchases-ios/releases/tag/5.29.0) | [8.20.0](https://github.com/RevenueCat/purchases-android/releases/tag/8.20.0) | [13.38.1](https://github.com/RevenueCat/purchases-hybrid-common/releases/tag/13.38.1) | [7.1.1](https://developer.android.com/google/play/billing/release-notes) |
| 6.2.10 | [5.28.1](https://github.com/RevenueCat/purchases-ios/releases/tag/5.28.1) | [8.19.2](https://github.com/RevenueCat/purchases-android/releases/tag/8.19.2) | [13.36.0](https://github.com/RevenueCat/purchases-hybrid-common/releases/tag/13.36.0) | [7.1.1](https://developer.android.com/google/play/billing/release-notes) |
| 6.2.9 | [5.26.0](https://github.com/RevenueCat/purchases-ios/releases/tag/5.26.0) | [8.19.0](https://github.com/RevenueCat/purchases-android/releases/tag/8.19.0) | [13.33.0](https://github.com/RevenueCat/purchases-hybrid-common/releases/tag/13.33.0) | [7.1.1](https://developer.android.com/google/play/billing/release-notes) |
| 6.2.8 | [5.24.0](https://github.com/RevenueCat/purchases-ios/releases/tag/5.24.0) | [8.17.1](https://github.com/RevenueCat/purchases-android/releases/tag/8.17.1) | [13.32.0](https://github.com/RevenueCat/purchases-hybrid-common/releases/tag/13.32.0) | [7.1.1](https://developer.android.com/google/play/billing/release-notes) |
| 6.2.7 | [5.21.0](https://github.com/RevenueCat/purchases-ios/releases/tag/5.21.0) | [8.16.0](https://github.com/RevenueCat/purchases-android/releases/tag/8.16.0) | [13.28.0](https://github.com/RevenueCat/purchases-hybrid-common/releases/tag/13.28.0) | [7.1.1](https://developer.android.com/google/play/billing/release-notes) |
| 6.2.6 | [5.19.0](https://github.com/RevenueCat/purchases-ios/releases/tag/5.19.0) | [8.14.1](https://github.com/RevenueCat/purchases-android/releases/tag/8.14.1) | [13.25.0](https://github.com/RevenueCat/purchases-hybrid-common/releases/tag/13.25.0) | [7.1.1](https://developer.android.com/google/play/billing/release-notes) |
| 6.2.5 | [5.19.0](https://github.com/RevenueCat/purchases-ios/releases/tag/5.19.0) | [8.13.0](https://github.com/RevenueCat/purchases-android/releases/tag/8.13.0) | [13.24.0](https://github.com/RevenueCat/purchases-hybrid-common/releases/tag/13.24.0) | [7.1.1](https://developer.android.com/google/play/billing/release-notes) |
| 6.2.4 | [5.18.0](https://github.com/RevenueCat/purchases-ios/releases/tag/5.18.0) | [8.12.2](https://github.com/RevenueCat/purchases-android/releases/tag/8.12.2) | [13.19.0](https://github.com/RevenueCat/purchases-hybrid-common/releases/tag/13.19.0) | [7.1.1](https://developer.android.com/google/play/billing/release-notes) |
| 6.2.3 | [5.16.1](https://github.com/RevenueCat/purchases-ios/releases/tag/5.16.1) | [8.11.0](https://github.com/RevenueCat/purchases-android/releases/tag/8.11.0) | [13.17.1](https://github.com/RevenueCat/purchases-hybrid-common/releases/tag/13.17.1) | [7.1.1](https://developer.android.com/google/play/billing/release-notes) |
| 6.2.1 | [5.14.5](https://github.com/RevenueCat/purchases-ios/releases/tag/5.14.5) | [8.10.8](https://github.com/RevenueCat/purchases-android/releases/tag/8.10.8) | [13.15.2](https://github.com/RevenueCat/purchases-hybrid-common/releases/tag/13.15.2) | [7.1.1](https://developer.android.com/google/play/billing/release-notes) |
| 6.2.0 | [5.14.0](https://github.com/RevenueCat/purchases-ios/releases/tag/5.14.0) | [8.10.5](https://github.com/RevenueCat/purchases-android/releases/tag/8.10.5) | [13.13.0](https://github.com/RevenueCat/purchases-hybrid-common/releases/tag/13.13.0) | [7.0.0](https://developer.android.com/google/play/billing/release-notes) |
| 6.1.4 | [5.14.0](https://github.com/RevenueCat/purchases-ios/releases/tag/5.14.0) | [8.10.5](https://github.com/RevenueCat/purchases-android/releases/tag/8.10.5) | [13.13.0](https://github.com/RevenueCat/purchases-hybrid-common/releases/tag/13.13.0) | [7.0.0](https://developer.android.com/google/play/billing/release-notes) |
| 6.1.3 | [5.12.0](https://github.com/RevenueCat/purchases-ios/releases/tag/5.12.0) | [8.10.3](https://github.com/RevenueCat/purchases-android/releases/tag/8.10.3) | [13.12.0](https://github.com/RevenueCat/purchases-hybrid-common/releases/tag/13.12.0) | [7.0.0](https://developer.android.com/google/play/billing/release-notes) |
| 6.1.2 | [5.8.0](https://github.com/RevenueCat/purchases-ios/releases/tag/5.8.0) | [8.10.2](https://github.com/RevenueCat/purchases-android/releases/tag/8.10.2) | [13.9.0](https://github.com/RevenueCat/purchases-hybrid-common/releases/tag/13.9.0) | [7.0.0](https://developer.android.com/google/play/billing/release-notes) |
| 6.1.1 | [5.7.1](https://github.com/RevenueCat/purchases-ios/releases/tag/5.7.1) | [8.9.0](https://github.com/RevenueCat/purchases-android/releases/tag/8.9.0) | [13.8.0](https://github.com/RevenueCat/purchases-hybrid-common/releases/tag/13.8.0) | [7.0.0](https://developer.android.com/google/play/billing/release-notes) |
| 6.1.0 | [5.7.0](https://github.com/RevenueCat/purchases-ios/releases/tag/5.7.0) | [8.8.1](https://github.com/RevenueCat/purchases-android/releases/tag/8.8.1) | [13.7.0](https://github.com/RevenueCat/purchases-hybrid-common/releases/tag/13.7.0) | [7.0.0](https://developer.android.com/google/play/billing/release-notes) |
| 6.0.2 | [5.3.4](https://github.com/RevenueCat/purchases-ios/releases/tag/5.3.4) | [8.7.2](https://github.com/RevenueCat/purchases-android/releases/tag/8.7.2) | [13.3.0](https://github.com/RevenueCat/purchases-hybrid-common/releases/tag/13.3.0) | [7.0.0](https://developer.android.com/google/play/billing/release-notes) |
| 6.0.1 | [5.3.3](https://github.com/RevenueCat/purchases-ios/releases/tag/5.3.3) | [8.7.2](https://github.com/RevenueCat/purchases-android/releases/tag/8.7.2) | [13.2.1](https://github.com/RevenueCat/purchases-hybrid-common/releases/tag/13.2.1) | [7.0.0](https://developer.android.com/google/play/billing/release-notes) |
| 6.0.0 | 5.2.3 | 8.4.0 | 13.0.1 | |
| 5.7.8 | 4.43.0 | 7.11.1 | 10.9.0 | |
| 5.7.7 | 4.42.0 | 7.11.0 | 10.8.0 | |
| 5.7.6 | 4.40.1 | 7.8.2 | 10.4.1 | |
| 5.7.5 | 4.40.0 | 7.8.1 | 10.4.0 | |
| 5.7.4 | 4.39.1 | 7.8.1 | 10.3.2 | |
| 5.7.3         | 4.37.0      | 7.7.1           | 9.9.0                | |
| 5.7.2         | 4.36.1      | 7.5.1           | 9.7.0                | |
| 5.7.1         | 4.35.0      | 7.5.0           | 9.6.0                | |
| 5.7.0         | 4.33.0      | 7.4.1           | 9.3.0                | |
| 5.6.1         | 4.31.7      | 7.3.2           | 8.2.2                | |
| 5.6.0         | 4.31.6      | 7.3.1           | 8.2.1                | |
| 5.5.1         | 4.31.2      | 7.2.7           | 8.1.1                | |
| 5.5.0         | 4.31.1      | 7.2.6           | 8.1.0                | |
| 5.4.1         | 4.30.5      | 7.2.4           | 8.0.0                | |
| 5.4.0         | 4.30.5      | 7.2.4           | 8.0.0                | |
| 5.3.1         | 4.30.5      | 7.2.3           | 7.3.3                | |
| 5.3.0         | 4.30.2      | 7.2.0           | 7.3.0                | |
| 5.2.0         | 4.29.0      | 7.0.1           | 7.2.0                | |
| 5.1.0         | 4.28.0      | 7.0.1           | 7.1.0                | |
| 5.0.0         | 4.27.0      | 7.0.0           | 7.0.0                | |
| 4.9.1         | 4.26.1      | 6.9.7           | 6.3.2                | |
| 4.9.0         | 4.26.1      | 6.9.5           | 6.3.0                | |
| 4.8.0         | 4.26.0      | 6.9.4           | 6.2.0                | |
| 4.7.1         | 4.25.9      | 6.9.4           | 6.1.2                | |
| 4.7.0         | 4.25.7      | 6.9.3           | 6.1.0                | |
| 4.6.1         | 4.25.6      | 6.9.2           | 5.6.3                | |
| 4.6.0         | 4.25.2      | 6.9.0           | 5.6.0                | |
| 4.5.0         | 4.25.2      | 6.8.0           | 5.5.0                | |
| 4.4.1         | 4.25.1      | 6.7.0           | 5.4.1                | |
| 4.4.0         | 4.25.0      | 6.7.0           | 5.4.0                | |
| 4.3.0         | 4.24.1      | 6.5.2           | 5.3.0                | |
| 4.2.3         | 4.23.1      | 6.5.2           | 5.2.4                | |
| 4.2.2         | 4.23.1      | 6.5.2           | 5.2.3                | |
| 4.2.1         | 4.23.1      | 6.5.2           | 5.2.2                | |
| 4.2.0         | 4.23.0      | 6.5.1           | 5.2.0                | |
| 4.1.0         | 4.22.0      | 6.5.0           | 5.1.0                | |
| 4.0.0         | 4.21.0      | 6.4.0           | 5.0.0                | |
| 4.0.0-rc.1    | 4.21.0      | 6.4.0           | 5.0.0-rc.1           | |
| 4.0.0-alpha.1 | 4.17.8      | 6.1.1           | 5.0.0-beta.6         | |
| 3.15.0        | 4.21.0      | 5.8.2           | 4.18.0               | |
| 3.14.0        | 4.19.0      | 5.8.2           | 4.16.0               | |
| 3.13.0        | 4.18.0      | 5.8.2           | 4.15.0               | |
| 3.12.3        | 4.17.11     | 5.8.2           | 4.14.3               | |
| 3.12.2        | 4.17.9      | 5.8.2           | 4.14.2               | |
| 3.12.1        | 4.17.8      | 5.8.2           | 4.14.1               | |
| 3.12.0        | 4.17.7      | 5.8.2           | 4.14.0               | |
| 3.11.1        | 4.17.7      | 5.7.1           | 4.13.5               | |
| 3.11.0        | 4.17.7      | 5.7.1           | 4.13.4               | |
| 3.10.0        | 4.17.6      | 5.7.1           | 4.13.2               | |
| 3.9.1         | 4.17.5      | 5.7.1           | 4.13.1               | |
| 3.9.0         | 4.17.4      | 5.7.0           | 4.13.0               | |
| 3.8.0         | 4.17.3      | 5.7.0           | 4.12.0               | |
| 3.7.0         | 4.17.2      | 5.6.7           | 4.10.0               | |
| 3.6.0         | 4.16.0      | 5.6.6           | 4.8.0                | |
| 3.5.0         | 4.16.0      | 5.6.6           | 4.7.0                | |
| 3.4.4         | 4.15.5      | 5.6.6           | 4.5.4                | |
| 3.4.3         | 4.15.3      | 5.6.6           | 4.5.2                | |
| 3.4.2         | 4.15.3      | 5.6.6           | 4.5.2                | |
| 3.4.1         | 4.15.2      | 5.6.5           | 4.5.1                | |
| 3.4.0         | 4.15.0      | 5.6.5           | 4.5.0                | |
| 3.3.3         | 4.14.3      | 5.6.5           | 4.4.4                | |
| 3.3.2         | 4.14.2      | 5.6.5           | 4.4.3                | |
| 3.3.1         | 4.14.1      | 5.6.4           | 4.4.1                | |
| 3.3.0         | 4.14.0      | 5.6.3           | 4.4.0                | |
| 3.2.1         | 4.13.4      | 5.6.3           | 4.3.6                | |
| 3.2.0         | 4.13.2      | 5.6.2           | 4.3.2                | |
| 3.1.0         | 4.10.2      | 5.6.0           | 4.2.0                | |
| 3.0.0         | 4.10.2      | 5.6.0           | 4.2.0                | |
| 3.0.0-rc.8    | 4.10.2      | 5.6.0           | 4.2.0                | |
| 3.0.0-rc.7    | 4.10.2      | 5.4.1           | 4.1.4                | |
| 3.0.0-rc.6    | 4.10.1      | 5.4.1           | 4.1.2                | |
| 3.0.0-rc.5    | 4.10.0      | 5.3.0           | 4.1.0                | |
| 3.0.0-rc.4    | 4.9.1       | 5.3.0           | 4.0.0                | |
| 3.0.0-rc.3    | 4.9.0       | 5.3.0           | 3.3.0                | |
| 3.0.0-rc.2    | 4.9.0       | 5.3.0           | 3.3.0                | |
| 3.0.0-rc.1    | 4.9.0       | 5.2.1           | 3.2.4                | |
| 2.4.3         | 3.14.4      | 4.6.1           | 2.0.2                | |
| 2.4.2         | 3.14.1      | 4.6.1           | 2.0.1                | |
| 2.4.1         | 3.14.1      | 4.6.1           | 2.0.1                | |
| 2.4.0         | 3.13.0      | 4.4.0           | 1.10.0               | |
| 2.3.2         | 3.12.8      | 4.3.3           | 1.9.3                | |
| 2.3.1         | 3.12.3      | 4.3.1           | 1.9.1                | |
| 2.3.0         | 3.12.2      | 4.3.0           | 1.8.0                | |
| 2.2.0         | 3.11.1      | 4.2.1           | 1.7.1                | |
| 2.1.1         | 3.10.7      | 4.0.5           | 1.6.2                | |
| 2.1.0         | 3.10.6      | 4.0.4           | 1.6.1                | |
| 2.0.0         | 3.9.2       | 4.0.1           | 1.5.0                | |
| 1.3.2         | 3.7.5       | 3.5.2           | 1.4.5                | |
| 1.3.1         | 3.7.2       | 3.5.2           | 1.4.4                | |
| 1.3.0         | 3.7.2       | 3.5.0           | 1.4.3                | |
| 1.2.2         | 3.4.0       | 3.2.0           | 1.2.0                | |
| 1.2.1         | 3.4.0       | 3.2.0           | 1.2.0                | |
| 1.2.0         | 3.4.0       | 3.2.0           | 1.2.0                | |
| 1.1.0         | 3.2.2       | 3.1.0           | 1.0.11               | |
| 1.0.5         | 3.0.2       | 3.0.4           | 1.0.5                | |
| 1.0.4         | 3.0.1       | 3.0.4           | 1.0.5                | |
| 1.0.3         | 3.0.1       | 3.0.4           | 1.0.5                | |
| 1.0.2         | 3.0.1       | 3.0.4           | 1.0.4                | |
| 1.0.1         | 3.0.0       | 3.0.2           | 1.0.1                | |
| 1.0.0         | 3.0.0       | 3.0.2           | 1.0.1                | |
| 0.3.2         | 2.6.0       | 2.4.0           | 0.1.4                | |
| 0.3.1         | 2.6.0       | 2.4.0           | 0.1.3                | |
| 0.3.0         | 2.6.0       | 2.4.0           | 0.1.3                | |
| 0.2.0         | 2.5.0       | 2.3.0           | 0.1.1                | |
