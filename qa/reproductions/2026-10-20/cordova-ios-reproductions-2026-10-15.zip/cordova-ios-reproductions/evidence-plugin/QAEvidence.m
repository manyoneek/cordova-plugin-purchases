#import <Cordova/CDVPlugin.h>
@interface QAEvidence : CDVPlugin
@end
@implementation QAEvidence
- (void)snapshot:(CDVInvokedUrlCommand*)command {
    NSString *user = command.arguments[0];
    NSMutableDictionary *values = [NSMutableDictionary dictionary];
    NSDictionary *defaults = [[[NSUserDefaults alloc] initWithSuiteName:@"com.revenuecat.user_defaults"] dictionaryRepresentation];
    for (NSString *key in defaults) {
        if ([key containsString:@"subscriberAttributes"] && [defaults[key] isKindOfClass:[NSDictionary class]]) {
            NSDictionary *attributes = defaults[key][user];
            if ([attributes isKindOfClass:[NSDictionary class]]) {
                for (NSString *name in attributes) {
                    if ([attributes[name] isKindOfClass:[NSDictionary class]]) values[name] = attributes[name][@"value"] ?: [NSNull null];
                }
            }
        }
    }
    [self.commandDelegate sendPluginResult:[CDVPluginResult resultWithStatus:CDVCommandStatus_OK messageAsDictionary:values] callbackId:command.callbackId];
}
- (void)save:(CDVInvokedUrlCommand*)command {
    NSString *path = [NSSearchPathForDirectoriesInDomains(NSDocumentDirectory, NSUserDomainMask, YES)[0] stringByAppendingPathComponent:@"results.json"];
    NSError *error = nil;
    [command.arguments[0] writeToFile:path atomically:YES encoding:NSUTF8StringEncoding error:&error];
    [self.commandDelegate sendPluginResult:[CDVPluginResult resultWithStatus:error ? CDVCommandStatus_ERROR : CDVCommandStatus_OK messageAsString:error ? error.description : path] callbackId:command.callbackId];
}
@end
