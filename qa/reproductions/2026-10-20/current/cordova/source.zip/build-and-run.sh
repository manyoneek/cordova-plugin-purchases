#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")"
variant="${1:-before}"
export LANG=en_US.UTF-8 LC_ALL=en_US.UTF-8
mkdir -p sdk
tar -xzf sdk-source.tar.gz -C sdk
if [ "$variant" = fixed ]; then (cd sdk && patch -p1 < ../fixes/cordova-cache.patch && patch -p1 < ../fixes/cordova-attributes.patch); fi
cp sdk/src/ios/*.swift app/platforms/ios/App/Plugins/cordova-plugin-purchases/
(cd app/platforms/ios && pod install && xcodebuild build -workspace App.xcworkspace -scheme App -destination "platform=iOS Simulator,id=${QA_SIMULATOR:?Set QA_SIMULATOR}" -derivedDataPath ../../../derived IPHONEOS_DEPLOYMENT_TARGET=27.0 CODE_SIGNING_ALLOWED=NO)
python3 run-native-regression.py "$variant"
