/* Real SDK calls; no transport overrides or injected callbacks. */
const pause = ms => new Promise(resolve => setTimeout(resolve, ms));
const native = (action, args) => new Promise((resolve,reject) => cordova.exec(resolve,reject,'QAEvidence',action,args));
const call = (method, ...args) => new Promise((resolve,reject) => Purchases[method](...args,resolve,reject));
const el = id => document.getElementById(id);
let running = false;
async function run() {
 if(running) return; running=true; el('run').disabled=true;
 const user='sdk-bug-reporter-cordova-'+Date.now();
 const result={repository:'RevenueCat/cordova-plugin-purchases',commit:'f83961e065b9bf09684c2fda0156ce4564173881',platform:'iOS simulator',projectId:'proj602cc762',appId:'app4ca00b430f',user,checks:[],observations:{}};
 const check=(name,pass,actual)=>{result.checks.push({name,pass,actual}); console.log('QA_CHECK '+JSON.stringify(result.checks.at(-1)));};
 const save=()=>native('save',[JSON.stringify(result,null,2)]);
 try {
   Purchases.setLogLevel(Purchases.LOG_LEVEL.DEBUG);
   Purchases.configureWith({apiKey:QA_CONFIG.apiKey,appUserID:user});
   await pause(900);
   const info=await call('getCustomerInfo');
   check('Test Store synthetic user initialized',info.originalAppUserId===user,info.originalAppUserId);
   const first=await call('getCachedVirtualCurrencies'); result.observations.initialCache=first;
   check('Unfetched cache is null',first===null,first);
   el('cache').textContent='Before fetch: '+JSON.stringify(first); el('cache').className='result '+(first===null?'ok':'bad');
   el('status').textContent='Fetching actual Test Store virtual currencies…'; await save(); await pause(2500);
   const fetched=await call('getVirtualCurrencies'); const cached=await call('getCachedVirtualCurrencies');
   result.observations.fetched=fetched; result.observations.cached=cached;
   check('Fetched currencies round-trip through cache',JSON.stringify(fetched)===JSON.stringify(cached) && !!cached.all,cached);
   el('cache').textContent+='\nFetched: '+JSON.stringify(cached);
   Purchases.invalidateVirtualCurrenciesCache(); await pause(150);
   const invalidated=await call('getCachedVirtualCurrencies'); result.observations.invalidatedCache=invalidated;
   check('Invalidated cache is null',invalidated===null,invalidated);
   el('cache').textContent+='\nAfter invalidation: '+JSON.stringify(invalidated);
   el('status').textContent='Setting synthetic subscriber attributes…'; await save(); await pause(2200);
   Purchases.setDisplayName('QA original name'); Purchases.setAttributes({qa_null_delete:'original',qa_keep:'control'}); await pause(250);
   const before=await native('snapshot',[user]); result.observations.attributesBefore=before;
   check('String setter reaches real SDK storage',before.$displayName==='QA original name' && before.qa_null_delete==='original',before);
   el('attributes').textContent='Before: '+JSON.stringify(before.$displayName); await pause(2200);
   Purchases.setDisplayName(null); Purchases.setAttributes({qa_null_delete:null,qa_keep:'updated'}); await pause(250);
   const after=await native('snapshot',[user]); result.observations.attributesAfterNull=after;
   check('Null display name queues deletion',after.$displayName==='',after.$displayName);
   check('Null custom attribute queues deletion',after.qa_null_delete==='',after.qa_null_delete);
   check('Sibling string update survives null map value',after.qa_keep==='updated',after.qa_keep);
   el('attributes').textContent+='\nAfter null: '+JSON.stringify(after.$displayName)+'\nCustom: '+JSON.stringify(after.qa_null_delete);
   el('attributes').className='result '+(after.$displayName==='' && after.qa_null_delete===''?'ok':'bad');
   el('status').textContent='Checking the documented empty-string alternative…'; await save(); await pause(3200);
   Purchases.setDisplayName(''); Purchases.setAttributes({qa_null_delete:''}); await pause(250);
   const empty=await native('snapshot',[user]); result.observations.attributesAfterEmpty=empty;
   check('Empty-string deletion works as control',empty.$displayName==='' && empty.qa_null_delete==='',empty);
   el('attributes').textContent+='\nEmpty-string control: '+JSON.stringify(empty.$displayName);
   result.finished=true; result.passed=result.checks.filter(x=>x.pass).length; result.failed=result.checks.filter(x=>!x.pass).length;
   el('status').textContent=result.passed+' passed · '+result.failed+' failed — '+(result.failed?'bugs reproduced':'all assertions pass');
 } catch(error) {result.error=String(error?.message||JSON.stringify(error)); el('status').textContent='Flow error: '+result.error; console.error(error);}
 await save(); running=false; el('run').disabled=false;
}
document.addEventListener('deviceready',()=>{el('run').onclick=run; setTimeout(run,1800);});
