# Current reproduction source

RevenueCat/cordova-plugin-purchases at `f83961e065b9bf09684c2fda0156ce4564173881`. App/client verification performed on October 20, 2026 against this upstream revision and its current pinned SDK dependencies.

Run `bash build-and-run.sh before` and `bash build-and-run.sh fixed` from separate extracted copies. See the linked issue for expected results and reproduction steps. Replace `test_REPLACE_WITH_YOUR_PUBLIC_TEST_STORE_KEY` in the configuration with your dedicated public Test Store SDK key. Native runs require Xcode 27, CocoaPods (except Capacitor/SPM) and a booted iOS simulator; set `QA_SIMULATOR` to its UDID. 
